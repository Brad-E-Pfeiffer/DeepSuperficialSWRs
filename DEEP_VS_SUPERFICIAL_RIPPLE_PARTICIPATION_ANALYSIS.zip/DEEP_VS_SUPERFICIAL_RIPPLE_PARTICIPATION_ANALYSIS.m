function DEEP_VS_SUPERFICIAL_RIPPLE_PARTICIPATION_ANALYSIS

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function is the main function that does nearly all of the analysis
% for this paper.  It requires five files to already be in existence: 
% Spike_Data.mat, L_Ratios.mat, Epochs.mat, Position_Data.mat,
% and Experiment_Information.mat.  It further requires the
% raw local field potential data to be available for processing (this is
% typically stored in a separate location due to its size).
% 
% This function uses the following data sets:
% 
% Rat-SessionType-Day (Recording Day)
% 
% Janni-Linear-1 (Recorded on 20100413, Reward/BigReward/Reward, SameRun)
% Janni-Linear-2 (Recorded on 20100412, Reward/NoReward/Reward, SameRun)
% Janni-Linear-3 (Recorded on 20100410, Reward/BigReward/Reward, DifferentRuns)
% Janni-Linear-4 (Recorded on 20100408, Reward,NoReward,Reward, DifferentRuns)
% Harpy-Linear-1 (Recorded on 20100115, Reward/BigReward/Reward, SameRun)
% Harpy-Linear-2 (Recorded on 20100114, Reward/NoReward/Reward, SameRun)
% Harpy-Linear-3 (Recorded on 20100119, Reward/BigReward/Reward, DifferentRuns)
% Harpy-Linear-4 (Recorded on 20100120, Reward/NoReward/Reward, DifferentRuns)
% Ettin-Linear-1 (Recorded on 20090616, Reward/NoReward/Reward, DifferentRuns)
% Ettin-Linear-2 (Recorded on 20090618, Reward/BigReward/Reward, DifferentRuns) 
% For all of these sessions, the track is not novel, but has been
% experienced at least once previously (typically during training).
% 
% (Linear track sessions are organized by session type, not order of
% recording.)
%
% This function assumes that the only pre-processed data is Spike_Data,
% L_Ratios, Position_Data, and Epochs.  Spike_Data comes
% with additional information, including Excitatory_Neurons (cell ID list
% of all putative excitatory neurons), Inhibitory_Neurons (cell ID list of
% all putative inhibitory neurons), and Tetrode_Cell_ID (list of which
% tetrode each cell was recorded on.
% 
% Spike_Data (a chronological list of all spikes)
% |         1         |    2    |
% | Time (in seconds) | Cell ID |
% 
% Position_Data (a chronological list of the rat's behavior from the overhead camera)
% |         1         |           2        |           3        |                    4                       | 
% | Time (in seconds) | X Position (in cm) | Y Position (in cm) |  Head Direction (for open field sessions)  | 
% |                   |                    |                    |                   or                       |
% |                   |                    |                    | Linearized Bin (for linear track sessions) | 
% 
% L_Ratios is the L-ratio (a measure of cluster quality) calculated for
% each neuron from the clustered data (using the CALCULATE_L_RATIO
% function).  Index 1 corresponds to cell ID 1, index 2 corresponds to cell
% ID 2, and so on.
% 
% Epochs is the start (column 1) and end (column 2) times for Run_Times
% (start and end of behavioral sessions), Sleep_Times (start and end of
% identified periods of sleep, measured as complete immobility lasting for
% at least 60 seconds, excluding the first 20 seconds of such periods),
% Sleep_Box_Immobile_Times (start and end of periods of general immobility
% which may or may not overlap with actual sleep), and REM_Times (which is
% empty at first, but will be the start and end of identified REM epochs
% within sleep epochs).  Epochs was generated via the script
% SGC_CALCULATE_PERIODS_OF_SLEEP, which requires considerable manual input
% and isn't included in this series of functions.
% 
% Finally, there is one additional file, Experiment_Information.mat, which
% contains useful info regarding the experimental conditions.
% 
% For each step, the data is saved so that future runs don't need to run
% that step.  To start from scratch, just copy Spike_Data.mat, L_Ratios.mat,
% Position_Data.mat, Epochs.mat, and Experiment_Information.mat into a new
% folder and start over from there. 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% First, I define a few variables that can be changed
Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference=inf;   %If there is not position information found within this timeframe (in seconds) from a given spike, that spike is removed from analysis
Initial_Variables.Bin_Size=2;                                               %Size of spatial bins (in cm) used to make place fields
Initial_Variables.Velocity_Cutoff=5;                                        %The rat must be moving this fast (in cm/s) or faster for those spikes and position information to be used in calculating place fields
Initial_Variables.Velocity_Cutoff_For_Phase_Lock_Analysis=10;               %The rat must be moving this fast (in cm/s) or faster for those spikes and position information to be used in quantifying phase-locking during running
Initial_Variables.Duration_To_Remove_Around_Bad_LFP=0.1;                    %This is the amount (in seconds, on either side) of LFP data to ignore if the value of the raw LFP data was unreadable.
Initial_Variables.Ripple_Power_Threshold_Multiplier=3;                      %Ripple power must be this many standard deviations above the mean of all immobile times to be considered a ripple
Initial_Variables.Ripple_Concatenation_Distance=0.05;                       %Ripples with this distance or less between them are concatenated together
Initial_Variables.Ripple_Minimum_Duration=0.05;                             %Ripples shorter than this (in sec) are thrown out
Initial_Variables.Ripple_Maximum_Duration=0.5;                              %Ripples longer than this (in sec) are thrown out
Initial_Variables.Place_Field_Firing_Rate_Cutoff=1;                         %Neurons that don't fire at least this must (in Hz) in at least one bin are excluded from analysis.
Initial_Variables.Raw_LFP_Root_Directory='F:\';                             %The root directory where the raw LFP files can be found
Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction=0.2;             %A spatial bin must have a firing rate of the maximum firing rate times this fraction to be considered part of a true place field.
Initial_Variables.Minimum_Contiguous_Place_Field_Bins=20;                   %A place field must have this number of contiguous bin at or above Minimum_Place_Field_Firing_Rate_Fraction x the max firing rate to be considered a true place field.
Initial_Variables.Phase_Bin=20;                                             %The size (in degrees) of the bins to use for quantifying phase-locked firing to gamma/theta oscillations
Initial_Variables.Gaussian_Smoothing_Sigma=12;                              %Sigma of the Gaussian smoothing filter (in degrees) that turns the firing rate or spike histogram into a smoothed line (which is what is actually used for quantification)
Initial_Variables.Minimum_Spike_Count_For_Phase_Correlation=100;            %The minimum number of spikes for a given cell within a given epoch to quantify phase correlated firing      
Initial_Variables.Number_Of_Shuffles=1000;                                  %The number of shuffles to run for position sequences from Bayesian decoding
Initial_Variables.Behavior_Decoding_Window_Size=0.25;                       %Size (in seconds) of the Bayesian decoding window and advancement for quantifying decoding accuracy (during periods of active movement)
Initial_Variables.Decoding_Time_Window=0.02;                                %Size (in seconds) of the Bayesian decoding time window
Initial_Variables.Decoding_Time_Advance=0.01;                               %Size (in seconds) of the advancement between adjacent Bayesian decoding window frames
Initial_Variables.Use_Maximum_Posterior_Probability=0;                      %If set to 1, use the maximum posterior probability for identifying the single point for each frame during ripples (a value of 0 means use the weighted mean)
Initial_Variables.Replay_Smooth_Step_Size=1;                                %If set to 1, the step sizes across consecutive decoding windows are smoothed; if set to 0, they are not.
Initial_Variables.Replay_Maximum_Step_Size=20;                              %The maximum distance (in cm) the posterior probability can move between consecutive decoding windows and still be considered part of the same spatial trajectory
Initial_Variables.Replay_Minimum_Step_Number=10;                            %The minimum number of consecutive decoding steps with less than Replay_Maximum_Step_Size between each consecutive bin necessary to be considered for a meaningful virtual trajectory sequence; note that a step is two consecutive frames, so the number of consecutive frames is [Replay_Minimum_Step_Number+1]
Initial_Variables.Replay_Start_To_End_Distance=40;                          %The minimum start-to-end distance (in cm) that a virtual spatial path needs to traverse to be considered a meaningful spatial trajectory; this measurement is the largest single step between ANY two points of a single trajectory, not just the actual start or end
Initial_Variables.Replay_Total_Distance=80;                                 %The minimum total distance sum across all steps (in cm) that a virtual spatial path needs to traverse to be considered a meaningful spatial trajectory
Initial_Variables.Replay_Number_Of_Shuffles=1000;                           %The number of shuffles to perform for each ripple to quantify whether the encoded trajectory was signficant
Initial_Variables.Burst_Window=6;                                           %The delay (in ms) between two consecutive spikes to count as being part of a burst (Royer et al, 2012)
Initial_Variables.Spike_Amplitude_Cutoff=200;                               %The minimum size (in uV) of the mean waveform of a neuron's spikes necessary for that neuron to be considered "Large" (close to the recording site)
Initial_Variables.Early_Late_Fraction=[100 0];                              %Before or after this percent of the epoch is considered "early" or "late" in that epoch.

DSRP_PROCESS_RAW_DATA(Initial_Variables);

% Firing_Properties_Per_Cell_During_Behavior
% |    1    |              2                  |                    3                     |              4             |              5            |         6        |                 7                 |                   8                 |              9            |             10            |                 11                 |                  12                  |              13            |           14         ||
% | Cell ID | Peak Firing Rate of Place Field | Mean non-SWR Firing Rate During Behavior | Number Of Spikes In Bursts | Spikes Per On-Task Bursts | Burstiness Index | Pre-Task Rest Non-SWR Firing Rate | Number of Spikes in Pre-Task Bursts | Spikes Per Pre-Task Burst | Pre-Task Burstiness Index | Post-Task Rest Non-SWR Firing Rate | Number of Spikes in Post-Task Bursts | Spikes Per Post-Task Burst | Post-Task Burstiness ||
DSRP_QUANTIFY_FIRING_PROPERTIES_DURING_BEHAVIOR(Initial_Variables);

DSRP_COMPARE_DEEP_AND_SUPERFICIAL_CELLS(Initial_Variables);

DSRP_IDENTIFY_REPLAY_EVENTS(Initial_Variables);

DSRP_DEFINE_RIPPLE_CATEGORIES(Initial_Variables);

DSRP_QUANTIFY_ACTIVITY_PER_RIPPLE_AND_PER_PLACE_CELL(Initial_Variables);
DSRP_COMBINE_ACTIVITY_PER_RIPPLE_AND_PER_PLACE_CELL(Initial_Variables);

DSRP_QUANTIFY_ACTIVITY_PER_RIPPLE_AND_PER_CELL(Initial_Variables);
DSRP_COMBINE_ACTIVITY_PER_RIPPLE_AND_PER_CELL(Initial_Variables);

DSRP_QUANTIFY_FIRING_PRECISION_IN_REPLAY(Initial_Variables);
DSRP_QUANTIFY_FIRING_PRECISION_IN_REPLAY_MINUS_CURRENT_CELL(Initial_Variables);

DSRP_CREATE_PLOTS(Initial_Variables);

DSRP_EXAMINE_CORRELATION_IN_FIRING_AND_RIPPLE_MODULATION(Initial_Variables);


end

