function DSRP_PLOT_PLACE_FIELD_PROPERTIES

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        load Place_Field_Properties

        % All_Deep/Superficial_Place_Field_Properties (Large_Deep/Large_Superficial are for neurons with large spikes that are closer to the deep/superficial recording sites)
        % |              1               |              2         |        3         |         4        |              5              |            6              |        7       |    8   |     9      |
        % | Mean Place Field Size (bins) | Number Of Place Fields | Peak Firing Rate | Mean Firing Rate | Informaton Per Spike (bits) | Mean In-Field Firing Rate | Bursting Index | Rat ID | Session ID |
        
        Deep_Place_Field_Properties(:,8)=Rat;
        Deep_Place_Field_Properties(:,9)=Experiment;
        Large_Deep_Place_Field_Properties(:,8)=Rat;
        Large_Deep_Place_Field_Properties(:,9)=Experiment;
        Superficial_Place_Field_Properties(:,8)=Rat;
        Superficial_Place_Field_Properties(:,9)=Experiment;
        Large_Superficial_Place_Field_Properties(:,8)=Rat;
        Large_Superficial_Place_Field_Properties(:,9)=Experiment;

        if exist('All_Deep_Place_Field_Properties','var')
            All_Deep_Place_Field_Properties=[All_Deep_Place_Field_Properties;Deep_Place_Field_Properties];
            All_Large_Deep_Place_Field_Properties=[All_Large_Deep_Place_Field_Properties;Large_Deep_Place_Field_Properties];
            All_Superficial_Place_Field_Properties=[All_Superficial_Place_Field_Properties;Superficial_Place_Field_Properties];
            All_Large_Superficial_Place_Field_Properties=[All_Large_Superficial_Place_Field_Properties;Large_Superficial_Place_Field_Properties];
        else
            All_Deep_Place_Field_Properties=Deep_Place_Field_Properties;
            All_Large_Deep_Place_Field_Properties=Large_Deep_Place_Field_Properties;
            All_Superficial_Place_Field_Properties=Superficial_Place_Field_Properties;
            All_Large_Superficial_Place_Field_Properties=Large_Superficial_Place_Field_Properties;
        end

        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats

Column=7;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))+std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))-std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))+std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))-std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],[std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column))),std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=3;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))+std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))-std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))+std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))-std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],[std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column))),std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=4;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))+std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))-std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))+std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))-std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],[std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column))),std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=6;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))+std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))-std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))+std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))-std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],[std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column))),std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=5;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))+std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Large_Deep_Place_Field_Properties(:,Column)) mean(All_Large_Deep_Place_Field_Properties(:,Column))-std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))+std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Large_Superficial_Place_Field_Properties(:,Column)) mean(All_Large_Superficial_Place_Field_Properties(:,Column))-std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Large_Deep_Place_Field_Properties(:,Column)),mean(All_Large_Superficial_Place_Field_Properties(:,Column))],[std(All_Large_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Deep_Place_Field_Properties(:,Column))),std(All_Large_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Large_Superficial_Place_Field_Properties(:,Column)))],'.k')


figure;
hold on;
boxplot(All_Large_Deep_Place_Field_Properties(:,5));
set(gca,'YLim',[0 40]);

figure;
hold on;
boxplot(All_Large_Superficial_Place_Field_Properties(:,5));
set(gca,'YLim',[0 40]);

[p,h]=ranksum(All_Large_Deep_Place_Field_Properties(:,5),All_Large_Superficial_Place_Field_Properties(:,5));










Column=4;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Edges=10.^(-2:0.2:1);
plot(histcounts(All_Deep_Place_Field_Properties(:,Column),Edges),'r','LineWidth',3);
plot(histcounts(All_Superficial_Place_Field_Properties(:,Column),Edges),'b','LineWidth',3);

Column=7;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(histcounts(All_Deep_Place_Field_Properties(:,Column),0:0.05:1),'r','LineWidth',3);
plot(histcounts(All_Superficial_Place_Field_Properties(:,Column),0:0.05:1),'b','LineWidth',3);


Column=7;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))+std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))-std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))+std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))-std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],[std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column))),std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=3;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))+std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))-std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))+std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))-std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],[std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column))),std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=4;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))+std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))-std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))+std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))-std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],[std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column))),std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=6;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))+std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))-std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))+std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))-std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],[std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column))),std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'.k')

Column=5;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))+std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'k');
plot([1,1],[mean(All_Deep_Place_Field_Properties(:,Column)) mean(All_Deep_Place_Field_Properties(:,Column))-std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column)))],'w');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))+std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'k');
plot([2,2],[mean(All_Superficial_Place_Field_Properties(:,Column)) mean(All_Superficial_Place_Field_Properties(:,Column))-std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'w');

errorbar([1,2],[mean(All_Deep_Place_Field_Properties(:,Column)),mean(All_Superficial_Place_Field_Properties(:,Column))],[std(All_Deep_Place_Field_Properties(:,Column))/sqrt(length(All_Deep_Place_Field_Properties(:,Column))),std(All_Superficial_Place_Field_Properties(:,Column))/sqrt(length(All_Superficial_Place_Field_Properties(:,Column)))],'.k')










end