function DSRP_CREATE_RAW_PER_CELL_PARTICIPATION_AND_FIRING_RATE_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot Per Cell Raw Firing Rate and Participation
%
%==========================================================================
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
    mkdir('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
end
cd 'Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis'

if ~isfolder('Large Cell Raw Values')
    mkdir('Large Cell Raw Values')
end
cd('Large Cell Raw Values')

%==========================================================================
%
% Plot Cell Participation For Large-Amplitude-Spike Cells
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

%==========================================================================
%
% Plot Firing Rate (Only for Participating Cells)
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

%==========================================================================
%
% Plot Mean Spike Count (For All Cells)
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

cd ..
cd ..
cd ..


end

