function DSRP_QUANTIFY_REPLAY_EVENT_SIGNIFICANCE(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the decoded ripple data, performs shuffles, and finds
% the events that encode statistically unlikely trajectories
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Max_Step_Size=15; %bins
Min_Probability=0.05;

Min_Step_Size=20; %bins
Max_Probability=0.05;

load Decoded_Linear_Ripple_Events
load Ripple_Events
load Spike_Data
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end

for Current_Ripple=1:size(Ripple_Events,1)
    eval(sprintf('Decoded_Data=Decoded_Linear_Ripple_Events.Ripple_%d_Linear_Data;',Current_Ripple));
    Event_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
    Spike_Start=min(Event_Spike_Data(:,1));
    Spike_End=max(Event_Spike_Data(:,1));
    Decoding_Window_Times=[Spike_Start:Initial_Variables.Decoding_Time_Advance:Spike_End]';
    Decoding_Window_Times(:,2)=Decoding_Window_Times(:,1)+Initial_Variables.Decoding_Time_Window;
    [Max_Posterior_Probability,Peak_Location]=max(Decoded_Data);
    Step_Sizes=abs(diff(Peak_Location(:)));
    Max_Posterior_Probability=Max_Posterior_Probability(:);
    Step_Probabilities=mean([Max_Posterior_Probability(1:end-1),Max_Posterior_Probability(2:end)],2); %mean probability across both frames of each step
    Coherent_Parts=(Step_Sizes<=Max_Step_Size & Step_Probabilities>=Min_Probability);
    Consecutive_Coherent_Step_Starts_And_Ends=find(diff([0;Coherent_Parts;0]));
    Consecutive_Coherent_Steps_Starts=Consecutive_Coherent_Step_Starts_And_Ends(1:2:end-1);
    Consecutive_Coherent_Steps_Ends=Consecutive_Coherent_Step_Starts_And_Ends(2:2:end);
    Largest_Consecutive_Coherent_Step_Count=max(Consecutive_Coherent_Steps_Ends-Consecutive_Coherent_Steps_Starts);
    if Largest_Consecutive_Coherent_Step_Count>=5
        for Consecutive_Segment=1:length(Consecutive_Coherent_Steps_Starts)
            if Consecutive_Coherent_Steps_Ends(Consecutive_Segment)-Consecutive_Coherent_Steps_Starts(Consecutive_Segment)>=5.
                Start=Consecutive_Coherent_Steps_Starts(Consecutive_Segment);
                End=Consecutive_Coherent_Steps_Ends(Consecutive_Segment);
                Segment_Spike_Data=Event_Spike_Data(Event_Spike_Data(:,1)>=Decoding_Window_Times(Start,1) & Event_Spike_Data(:,2)<=Decoding_Window_Times(End,2),:);





    Fragmented_Parts=(Step_Sizes>=Min_Step_Size | Step_Probabilities<Max_Probability);
    Consecutive_Fragmented_Step_Starts_And_Ends=find(diff([0;Fragmented_Parts;0]));
    Consecutive_Fragmented_Steps_Starts=Consecutive_Fragmented_Step_Starts_And_Ends(1:2:end-1);
    Consecutive_Fragmented_Steps_Ends=Consecutive_Fragmented_Step_Starts_And_Ends(2:2:end);
    Largest_Consecutive_Fragmented_Step_Count=max(Consecutive_Fragmented_Steps_Ends-Consecutive_Fragmented_Steps_Starts);
    if Largest_Consecutive_Fragmented_Step_Count>=5



    Maximum_Consecutive_Coherent_Steps=max(diff(find(diff([-1;Coherent_Parts;2]))));
    Maximum_Consecutive_Fragmented_Steps=max(diff(find(diff([-1;Fragmented_Parts;2]))));




    



end