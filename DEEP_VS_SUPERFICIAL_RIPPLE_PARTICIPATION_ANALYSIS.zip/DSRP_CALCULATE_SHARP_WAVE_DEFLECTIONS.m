function DSRP_CALCULATE_SHARP_WAVE_DEFLECTIONS(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function looks at the LFP for every electrode and calculates the
% mean phase offset for the slow gamma oscillation.  For any session with
% more than one behavior period (including some linear track experiments),
% this program only analyses the first run and the first post-behavior
% period.  It is assumed that things won't change meaningfully across the
% subsequent sessions.  Only sharp waves with SD peak amplitude of 5 S.D.
% above the mean and longer than 150 ms are used for this to ensure a
% strong, measurable sharp-wave component.
%
% The raw LFP is normalized by subtracting the mean LFP 100-200 ms prior to
% ripple onset.  The deflection is measured as the mean 50-150 ms after
% ripple onset.  The dataset that this program was written to analyze was
% recorded with the values inverted, so this program flips them.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Ripple_Events_Sharp_Wave_Deflections (each page is a tetrode)
% |       1       |                   2                  |                      3                   |                   4                |                         5                      |                           6                        |                       7                      ||
% | Ripple Number | Sharp-Wave Amplitude at Ripple Start | Sharp-Wave Amplitude at Max Ripple Power | Sharp-Wave Amplitude at Ripple End | Mean LFP Amplitude (+/- 10 ms) at Ripple Start | Mean LFP Amplitude (+/- 10 ms) at Max Ripple Power | Mean LFP Amplitude (+/- 10 ms) at Ripple End ||

if ~isfile('Combined_Ripple_LFP_Data.mat')

    load('Spike_Data','Tetrode_Cell_IDs')
    load('Epochs','Run_Times','SWS_Times','Sleep_Box_Awake_Immobile_Times')
    load('Ripple_Events','Ripple_Events')
    Ripple_Events(:,7)=Ripple_Events(:,2)-Ripple_Events(:,1);
    % Ripple_Events
    % |     1      |    2     |     3     |        4       |              5             |                    6                     |
    % | Start Time | End Time | Peak Time | Peak Raw Power | Peak Global Z-Scored Power | Peak Z-Scored Power From That Epoch Only |

    % Find ripples that occur during defined epochs in the experiment
    PreSleep_SWS_Times=SWS_Times(SWS_Times(:,2)<Run_Times(1,1),:);
    PreSleep_Awake_Times=Sleep_Box_Awake_Immobile_Times(Sleep_Box_Awake_Immobile_Times(:,2)<Run_Times(1,1),:);
    if size(Run_Times,1)==1
        PostSleep_SWS_Times=SWS_Times(SWS_Times(:,1)>Run_Times(1,2),:);
        PostSleep_Awake_Times=Sleep_Box_Awake_Immobile_Times(Sleep_Box_Awake_Immobile_Times(:,1)>Run_Times(1,2),:);
    else
        PostSleep_SWS_Times=SWS_Times(SWS_Times(:,1)>Run_Times(1,2) & SWS_Times(:,2)<Run_Times(2,1),:);
        PostSleep_Awake_Times=Sleep_Box_Awake_Immobile_Times(Sleep_Box_Awake_Immobile_Times(:,2)<Run_Times(2,1),:);
    end        

    Run_Ripple_Events_Index=find(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2));
    PreSleep_SWS_Ripple_Events_Index=0;
    for N=1:size(PreSleep_SWS_Times,1)
        PreSleep_SWS_Ripple_Events_Index=[PreSleep_SWS_Ripple_Events_Index;find(Ripple_Events(:,1)>=PreSleep_SWS_Times(N,1) & Ripple_Events(:,2)<=PreSleep_SWS_Times(N,2))];
    end
    PreSleep_SWS_Ripple_Events_Index=PreSleep_SWS_Ripple_Events_Index(2:end);
    PreSleep_Awake_Ripple_Events_Index=0;
    for N=1:size(PreSleep_Awake_Times,1)
        PreSleep_Awake_Ripple_Events_Index=[PreSleep_Awake_Ripple_Events_Index;find(Ripple_Events(:,1)>=PreSleep_Awake_Times(N,1) & Ripple_Events(:,2)<=PreSleep_Awake_Times(N,2))];
    end
    PreSleep_Awake_Ripple_Events_Index=PreSleep_Awake_Ripple_Events_Index(2:end);
    PostSleep_SWS_Ripple_Events_Index=0;
    for N=1:size(PostSleep_SWS_Times,1)
        PostSleep_SWS_Ripple_Events_Index=[PostSleep_SWS_Ripple_Events_Index;find(Ripple_Events(:,1)>=PostSleep_SWS_Times(N,1) & Ripple_Events(:,2)<=PostSleep_SWS_Times(N,2))];
    end
    PostSleep_SWS_Ripple_Events_Index=PostSleep_SWS_Ripple_Events_Index(2:end);
    PostSleep_Awake_Ripple_Events_Index=0;
    for N=1:size(PostSleep_Awake_Times,1)
        PostSleep_Awake_Ripple_Events_Index=[PostSleep_Awake_Ripple_Events_Index;find(Ripple_Events(:,1)>=PostSleep_Awake_Times(N,1) & Ripple_Events(:,2)<=PostSleep_Awake_Times(N,2))];
    end
    PostSleep_Awake_Ripple_Events_Index=PostSleep_Awake_Ripple_Events_Index(2:end);

    Run_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
    PreSleep_Ripple_Events=Ripple_Events(Ripple_Events(:,1)<Run_Times(1,1),:);
    if size(Run_Times,1)==1
        PostSleep_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
    else
        PostSleep_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,2) & Ripple_Events(:,2)<=Run_Times(2,1),:);
    end
    % Separate pre- and post-sleep ripples into SWS vs. awake ripples
    PreSleep_SWS_Ripple_Events=PreSleep_Ripple_Events(1,:);
    PostSleep_SWS_Ripple_Events=PostSleep_Ripple_Events(1,:);
    PreSleep_Awake_Ripple_Events=Ripple_Events(Ripple_Events(:,2)<Run_Times(1,1),:);
    if size(Run_Times,1)==1
        PostSleep_Awake_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
    else
        PostSleep_Awake_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:);
    end
    if ~isempty(SWS_Times)
        for N=1:size(SWS_Times,1)
            PreSleep_SWS_Ripple_Events=[PreSleep_SWS_Ripple_Events;PreSleep_Ripple_Events(PreSleep_Ripple_Events(:,1)>=SWS_Times(N,1) & PreSleep_Ripple_Events(:,2)<=SWS_Times(N,2),:)];
            PreSleep_Awake_Ripple_Events=PreSleep_Awake_Ripple_Events(PreSleep_Awake_Ripple_Events(:,2)<SWS_Times(N,1) | PreSleep_Awake_Ripple_Events(:,1)>SWS_Times(N,2),:);
            PostSleep_SWS_Ripple_Events=[PostSleep_SWS_Ripple_Events;PostSleep_Ripple_Events(PostSleep_Ripple_Events(:,1)>=SWS_Times(N,1) & PostSleep_Ripple_Events(:,1)<=SWS_Times(N,2),:)];
            PostSleep_Awake_Ripple_Events=PostSleep_Awake_Ripple_Events(PostSleep_Awake_Ripple_Events(:,2)<SWS_Times(N,1) | PostSleep_Awake_Ripple_Events(:,1)>SWS_Times(N,2),:);
        end
    end
    PreSleep_SWS_Ripple_Events=PreSleep_SWS_Ripple_Events(2:end,:);
    PostSleep_SWS_Ripple_Events=PostSleep_SWS_Ripple_Events(2:end,:);

    % Move to folder with raw LFP Data
    Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
    disp('Calculating Sharp-Wave Deflections For Each Electrode.')
    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    Directory_List=dir;
    for N=1:size(Directory_List,1)
        for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if there are more channels, increase this number accordingly
            Comparison_String=sprintf('CSC%d.ncs',M);
            if strcmp(Directory_List(N).name,Comparison_String)
                if exist('LFP_Electrodes','var')
                    LFP_Electrodes=[LFP_Electrodes,M];
                else
                    LFP_Electrodes=M;
                end
            end
            clear Comparison_String;
        end
    end
    if ~exist('LFP_Electrodes','var')
        error('ERROR! No CSC files were identified in the listed load directory.')
    end
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
    clear M;
    clear N;
    clear Directory_List;
    clear LFP_Electrodes;
    clear LFP_Filename;

    Ripple_Stop_Low=130;
    Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
    Ripple_Pass_High=250;
    Ripple_Stop_High=275;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

    Sharp_Wave_Stop_Low=4;
    Sharp_Wave_Pass_Low=5;
    Sharp_Wave_Pass_High=15;
    Sharp_Wave_Stop_High=20;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Sharp_Wave=fdesign.bandpass(Sharp_Wave_Stop_Low, Sharp_Wave_Pass_Low, Sharp_Wave_Pass_High, Sharp_Wave_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Sharp_Wave_Filter=design(Filter_Design_For_Sharp_Wave,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

    Tetrode_List=unique(Tetrode_Cell_IDs(:,1));

    Ripple_Events_Sharp_Wave_Deflections=zeros(size(Ripple_Events,1),7,length(Tetrode_List));

    for TT=1:length(Tetrode_List)
        Current_Tetrode=Tetrode_List(TT,1);
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2); %Only processes tetrodes with recorded cells on them
        if ~isempty(Cells_On_This_Tetrode)
            Found_Electrode=0;
            for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
                Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
                if isfile(Electrode_Name) && Found_Electrode==0
                    Found_Electrode=1;
                    LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                    for Header_Line=1:length(LFP_Header)
                        Header_Info=cell2mat(LFP_Header(Header_Line));
                        if length(Header_Info)>12
                            if strcmp(Header_Info(1:11),'-ADMaxValue')
                                Max_Value=str2num(Header_Info(13:end));
                            end
                            if strcmp(Header_Info(1:11),'-InputRange')
                                Max_Range=str2num(Header_Info(13:end));
                            end
                        end
                    end
                    % Load raw LFP data
                    LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                    Times=zeros(512,size(LFP_Times,2));
                    for B=1:length(LFP_Times)-1
                        Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                    end
                    Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                    clear B;
                    clear LFP_Times;
                    Times=Times(:);
                    LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                    LFP_Samples=(-LFP_Samples(:))*(Max_Range/Max_Value); %The value is made negative to flip the signal back to the correct raw values as the recording was inverted (see Header info in the raw data file)
                    LFP_Data=[Times,LFP_Samples];
                    clear Times;
                    clear LFP_Samples;
                    clear Max_Value;

                    Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                    Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
                    Ripple_Filtered_LFP_Data(:,3)=abs(hilbert(Ripple_Filtered_LFP_Data(:,2)));
                    Ripple_Gaussian_Filter=fspecial('gaussian',[round(7*(12.5/((1/LFP_Frequency)*1000))),1],round(12.5/((1/LFP_Frequency)*1000)));  %sigma of 12.5 ms

                    Sharp_Wave_Filtered_LFP_Data=zeros(size(LFP_Data,1),2);
                    Sharp_Wave_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Sharp_Wave_Filtered_LFP_Data(:,2)=filter(Sharp_Wave_Filter,LFP_Data(:,2));
                    Sharp_Wave_Filtered_LFP_Data(:,2)=Sharp_Wave_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Sharp_Wave_Filtered_LFP_Data(:,2)=filter(Sharp_Wave_Filter,Sharp_Wave_Filtered_LFP_Data(:,2));
                    Sharp_Wave_Filtered_LFP_Data(:,2)=Sharp_Wave_Filtered_LFP_Data(end:-1:1,2);

                    % The program seperately analyzes pre-sleep, the first behavior session, and the first post-sleep session.
                    Run_LFP_Data=LFP_Data(LFP_Data(:,1)>=Run_Times(1,1) & LFP_Data(:,1)<=Run_Times(1,2),:);
                    Run_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)>=Run_Times(1,1) & Sharp_Wave_Filtered_LFP_Data(:,1)<=Run_Times(1,2),:);
                    Run_Ripple_Filtered_LFP_Data=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)>=Run_Times(1,1) & Ripple_Filtered_LFP_Data(:,1)<=Run_Times(1,2),:);
                    PreSleep_LFP_Data=LFP_Data(LFP_Data(:,1)<Run_Times(1,1),:);
                    PreSleep_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)<Run_Times(1,1),:);
                    PreSleep_Ripple_Filtered_LFP_Data=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)<Run_Times(1,1),:);
                    if size(Run_Times,1)==1
                        PostSleep_LFP_Data=LFP_Data(LFP_Data(:,1)>Run_Times(1,2),:);
                        PostSleep_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)>Run_Times(1,2),:);
                        PostSleep_Ripple_Filtered_LFP_Data=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)>Run_Times(1,2),:);
                    else
                        PostSleep_LFP_Data=LFP_Data(LFP_Data(:,1)>Run_Times(1,2) & LFP_Data(:,1)<Run_Times(2,1),:);
                        PostSleep_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)>Run_Times(1,2) & Sharp_Wave_Filtered_LFP_Data(:,1)<Run_Times(2,1),:);
                        PostSleep_Ripple_Filtered_LFP_Data=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)>Run_Times(1,2) & Ripple_Filtered_LFP_Data(:,1)<Run_Times(2,1),:);
                    end

                    clear Average_All_Ripple_LFP_Data;
                    clear Average_All_Ripple_Sharp_Wave_LFP_Data;
                    clear Average_Run_Ripple_Sharp_Wave_LFP_Data;
                    clear Average_Run_Ripple_LFP_Data;
                    clear Average_PreSleep_Ripple_LFP_Data;
                    clear Average_PostSleep_Ripple_LFP_Data;
                    clear Average_PreWake_Ripple_LFP_Data;
                    clear Average_PostWake_Ripple_LFP_Data;
                    clear All_Run_Ripple_LFP_Data;
                    clear All_PreSleep_Ripple_LFP_Data;
                    clear All_PostSleep_Ripple_LFP_Data;
                    clear All_PreWake_Ripple_LFP_Data;
                    clear All_PostWake_Ripple_LFP_Data;
                    clear Run_Ripple_Amplitudes;
                    clear PreSleep_Ripple_Amplitudes;
                    clear PreWake_Ripple_Amplitudes;
                    clear PostSleep_Ripple_Amplitudes;
                    clear PostWake_Ripple_Amplitudes;

                    %Find and average the raw LFP across all ripples (rather than use the actual ripple duration, we just grab 400 ms before the ripple starts and 400 ms after the peak ripple power
                    Average_All_Ripple_LFP_Data=(-0.25:1/3200:0.25)';
                    Average_All_Ripple_LFP_Data(:,2:(size(Ripple_Events,1)+1))=NaN;
                    Average_All_Ripple_Sharp_Wave_LFP_Data=Average_All_Ripple_LFP_Data;
                    for Current_Ripple=1:size(Ripple_Events,1)
                        if min(LFP_Data(:,1))<(Ripple_Events(Current_Ripple,1)-1) && max(LFP_Data(:,1))>(Ripple_Events(Current_Ripple,2)+1) %only use ripple events more than 1 second from the start/end of the recording to avoid truncation artifacts
                            Start=Ripple_Events(Current_Ripple,1);
                            End=Ripple_Events(Current_Ripple,2);
                            Peak=Ripple_Events(Current_Ripple,3);
                            if 1%Ripple_Events(Current_Ripple,6)>=5 && Ripple_Events(Current_Ripple,7)>=0.15 %limit analysis by ripple criteria (z-score power >= 5; duration >= 150 ms)
                                Current_Ripple_LFP_Data=LFP_Data(LFP_Data(:,1)>=(Start-1) & LFP_Data(:,1)<=(End+1),:); %grab raw LFP 1000 ms before start and 1000 ms after end of each ripple
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data=Sharp_Wave_Filtered_LFP_Data(Sharp_Wave_Filtered_LFP_Data(:,1)>=(Start-1) & Sharp_Wave_Filtered_LFP_Data(:,1)<=(End+1),:); %grab sharp-wave filtered LFP 1000 ms before start and 1000 ms after end of each ripple
                                Ripple_Events_Sharp_Wave_Deflections(Current_Ripple,:,Current_Tetrode)=[Current_Ripple,Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=Start,1,'first'),2),Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=Peak,1,'first'),2),Current_Ripple_Sharp_Wave_Filtered_LFP_Data(find(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=End,1,'first'),2),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(Start-0.005) & Current_Ripple_LFP_Data(:,1)<=(Start+0.005),2),'omitnan'),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(Peak-0.005) & Current_Ripple_LFP_Data(:,1)<=(Peak+0.005),2),'omitnan'),mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=(End-0.005) & Current_Ripple_LFP_Data(:,1)<=(End+0.005),2),'omitnan')];
                                Peak_Index=find(Current_Ripple_LFP_Data(:,1)>=Peak,1,'first');
                                % Re-assign times based on ripple peak power timepoint and normalize by baseline 400-500 ms before ripple start
                                Current_Ripple_LFP_Data(:,1)=Current_Ripple_LFP_Data(:,1)-Current_Ripple_LFP_Data(Peak_Index,1);
                                Current_Ripple_LFP_Data(:,2)=Current_Ripple_LFP_Data(:,2)-mean(Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=-0.5 & Current_Ripple_LFP_Data(:,1)<=-0.4,2),'omitnan');
                                Current_Ripple_LFP_Data=Current_Ripple_LFP_Data(Current_Ripple_LFP_Data(:,1)>=-0.25 & Current_Ripple_LFP_Data(:,1)<=0.25,:);
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)-Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Peak_Index,1);
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,2)=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,2)-mean(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=-0.5 & Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)<=-0.4,2),'omitnan');
                                Current_Ripple_Sharp_Wave_Filtered_LFP_Data=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)>=-0.25 & Current_Ripple_Sharp_Wave_Filtered_LFP_Data(:,1)<=0.25,:);
                                % Combine into a single average trace
                                Integration_Index=round(interp1(Current_Ripple_LFP_Data(:,1),1:size(Current_Ripple_LFP_Data,1),Average_All_Ripple_LFP_Data(:,1),'nearest'));
                                Integration_Index(Integration_Index==0)=1;
                                Integration_Index(Integration_Index>size(Current_Ripple_LFP_Data,1))=size(Current_Ripple_LFP_Data,1);
                                Average_All_Ripple_LFP_Data(~isnan(Integration_Index),(Current_Ripple+1))=Current_Ripple_LFP_Data(Integration_Index(~isnan(Integration_Index)),2);
                                Average_All_Ripple_Sharp_Wave_LFP_Data(~isnan(Integration_Index),(Current_Ripple+1))=Current_Ripple_Sharp_Wave_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),2);
                                clear Integration_Index;
                            end
                        end
                    end
                    % Average across all ripples for this tetrode
                    if exist('Combined_All_Ripple_LFP_Data','var')
                        Combined_All_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,2:end)'),'omitnan')');
                        Combined_All_Ripple_Sharp_Wave_Filtered_LFP_Data(:,end+1)=(mean((Average_All_Ripple_Sharp_Wave_LFP_Data(:,2:end)'),'omitnan')');
                        Combined_Run_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,(Run_Ripple_Events_Index+1))'),'omitnan')');
                        Combined_PreSleep_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,(PreSleep_SWS_Ripple_Events_Index+1))'),'omitnan')');
                        Combined_PreWake_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,(PreSleep_Awake_Ripple_Events_Index+1))'),'omitnan')');
                        Combined_PostSleep_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,(PostSleep_SWS_Ripple_Events_Index+1))'),'omitnan')');
                        Combined_PostWake_Ripple_LFP_Data(:,end+1)=(mean((Average_All_Ripple_LFP_Data(:,(PostSleep_Awake_Ripple_Events_Index+1))'),'omitnan')');
                    else
                        Combined_All_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,2:end)'),'omitnan')')];
                        Combined_All_Ripple_Sharp_Wave_Filtered_LFP_Data=[Average_All_Ripple_Sharp_Wave_LFP_Data(:,1),(mean((Average_All_Ripple_Sharp_Wave_LFP_Data(:,2:end)'),'omitnan')')];
                        Combined_Run_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,(Run_Ripple_Events_Index+1))'),'omitnan')')];
                        Combined_PreSleep_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,(PreSleep_SWS_Ripple_Events_Index+1))'),'omitnan')')];
                        Combined_PreWake_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,(PreSleep_Awake_Ripple_Events_Index+1))'),'omitnan')')];
                        Combined_PostSleep_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,(PostSleep_SWS_Ripple_Events_Index+1))'),'omitnan')')];
                        Combined_PostWake_Ripple_LFP_Data=[Average_All_Ripple_LFP_Data(:,1),(mean((Average_All_Ripple_LFP_Data(:,(PostSleep_Awake_Ripple_Events_Index+1))'),'omitnan')')];
                    end
                end
            end
        end
        disp(sprintf('Finished quantifying sharp-wave deflection for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    cd(Current_Working_Directory);

    clear Raw_LFP_Directory;
    clear Current_Directory;

    save('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections');
    save('Combined_Ripple_LFP_Data','Combined_*','-v7.3');

end


end

