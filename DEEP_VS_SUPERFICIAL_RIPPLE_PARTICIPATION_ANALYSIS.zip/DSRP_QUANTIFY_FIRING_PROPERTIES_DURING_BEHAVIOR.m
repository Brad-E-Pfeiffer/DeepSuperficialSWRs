function DSRP_QUANTIFY_FIRING_PROPERTIES_DURING_BEHAVIOR(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function analyzes the firing properties of each cell during the
% experience and quantifies total firing rate and burst firing
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Firing_Properties_Per_Cell_During_Behavior
% |    1    |              2                  |                    3                     |              4             |              5            |         6        |                 7                 |                   8                 |              9            |             10            |                 11                 |                  12                  |              13            |           14         |            15             ||
% | Cell ID | Peak Firing Rate of Place Field | Mean non-SWR Firing Rate During Behavior | Number Of Spikes In Bursts | Spikes Per On-Task Bursts | Burstiness Index | Pre-Task Rest Non-SWR Firing Rate | Number of Spikes in Pre-Task Bursts | Spikes Per Pre-Task Burst | Pre-Task Burstiness Index | Post-Task Rest Non-SWR Firing Rate | Number of Spikes in Post-Task Bursts | Spikes Per Post-Task Burst | Post-Task Burstiness | Mean In-Field Firing Rate ||

Burst_Window=Initial_Variables.Burst_Window/1000; %convert to seconds
Use_Running_Only=0;  %0 to use all data; 1 to use only periods of active movement for on-task analysis

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Firing Properties for Each Cell for %s Day %d.'')',Rat_Name,Experiment)); 

        if 1%~isfile('Firing_Properties_Per_Cell_During_Behavior.mat')

            load Spike_Data
            load Field_Data
            load Epochs
            load Ripple_Events
            load Position_Data
            Position_Data=Position_Data(Position_Data(:,1)>=Run_Times(1,1) & Position_Data(:,1)<=Run_Times(1,2),:);
            Position_Data(:,5)=DSRP_CALCULATE_VELOCITY(Position_Data);
            Position_Data(1:(end-1),6)=diff(Position_Data(:,1));
            Position_Data(end,6)=Position_Data(end-1,6);
            Pre_Ripple_Events=Ripple_Events(Ripple_Events(:,2)<Run_Times(1,1),:);
            Pre_Ripple_Event_Duration=sum(Pre_Ripple_Events(:,2)-Pre_Ripple_Events(:,1));
            Post_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
            if size(Run_Times,1)>1
                Post_Ripple_Events=Post_Ripple_Events(Post_Ripple_Events(:,2)<Run_Times(2,1),:);
            end
            Post_Ripple_Event_Duration=sum(Post_Ripple_Events(:,2)-Post_Ripple_Events(:,1));
            Run_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            Run_Ripple_Event_Duration=sum(Run_Ripple_Events(:,2)-Run_Ripple_Events(:,1));

            for N=1:length(Inhibitory_Neurons)
                Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
            end

            %Find spikes only in ripples (not currently used in analysis, but saved in case I think of a use for it)
            Ripple_Spike_Data=Spike_Data(1,:);
            for N=1:size(Ripple_Events,1)
                Ripple_Spike_Data=[Ripple_Spike_Data;Spike_Data(Spike_Data(:,1)>=Ripple_Events(N,1) & Spike_Data(:,1)<=Ripple_Events(N,2),:)];
            end
            Ripple_Spike_Data=Ripple_Spike_Data(2:end,:);

            %Remove spikes during ripples from the analysis
            for N=1:size(Ripple_Events,1)
                Spike_Data=Spike_Data(Spike_Data(:,1)<Ripple_Events(N,1) | Spike_Data(:,1)>Ripple_Events(N,2),:);
            end

            Pre_Spike_Data=Spike_Data(Spike_Data(:,1)<Run_Times(1,1),:);
            Post_Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Times(1,2),:);
            if size(Run_Times,1)>1
                Post_Spike_Data=Post_Spike_Data(Post_Spike_Data(:,1)<Run_Times(2,1),:);
            end
            Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Times(1,1) & Spike_Data(:,1)<=Run_Times(1,2),:);

            Pre_Duration=(max(Pre_Spike_Data(:,1))-min(Pre_Spike_Data(:,1)))-Pre_Ripple_Event_Duration;
            Run_Duration=(max(Spike_Data(:,1))-min(Spike_Data(:,1)))-Run_Ripple_Event_Duration;
            Post_Duration=(max(Post_Spike_Data(:,1))-min(Post_Spike_Data(:,1)))-Post_Ripple_Event_Duration;

            if Use_Running_Only
                Spike_Data(:,3)=interp1(Position_Data(:,1),Position_Data(:,5),Spike_Data(:,1),'nearest');
                Spike_Data=Spike_Data(Spike_Data(:,3)>=Initial_Variables.Velocity_Cutoff,:); %Restrict on-task analysis to periods of movement, similar to photolabeling conditions
                Run_Duration=sum(Position_Data(Position_Data(:,5)>=Initial_Variables.Velocity_Cutoff,6));
            end

            Firing_Properties_Per_Cell_During_Behavior=zeros(length(Excitatory_Neurons),15);

            for Cell=1:length(Excitatory_Neurons)
                Current_Cell=Excitatory_Neurons(Cell);

                %Place Field Info
                Place_Field=Field_Data(:,:,Current_Cell);
                Max_Firing_Rate=max(max(Place_Field));
                Number_Of_Fields=0;
                if max(max(Place_Field))>0
                    Contiguous_Place_Fields=zeros(size(Place_Field,1),size(Place_Field,2));
                    Place_Field=double(Place_Field>=Max_Firing_Rate*0.2);
                    Place_Field_Sizes=0;
                    [Y_Index,X_Index]=find(Place_Field==1);
                    for M=1:length(Y_Index)
                        if Contiguous_Place_Fields(Y_Index(M),X_Index(M))==0 && Place_Field(Y_Index(M),X_Index(M))==1
                            This_Place_Field=grayconnected(Place_Field,Y_Index(M),X_Index(M),0);
                            if sum(sum(This_Place_Field))>=10 %10 contiguous bins
                                Number_Of_Fields=Number_Of_Fields+1;
                                Contiguous_Place_Fields(This_Place_Field)=Number_Of_Fields;
                                Place_Field_Sizes=[Place_Field_Sizes;sum(sum(This_Place_Field))];
                            end
                        end
                        clear This_Place_Field;
                    end
                    [Y,X]=find(Contiguous_Place_Fields>0);
                    Mean_InField_Firing_Rate=mean(mean(Field_Data(Y,X,Current_Cell)));
                else
                    Mean_InField_Firing_Rate=0;
                end

                %Firing Rate Info
                Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Current_Cell,:);
                Pre_Cell_Spike_Data=Pre_Spike_Data(Pre_Spike_Data(:,2)==Current_Cell,:);
                Post_Cell_Spike_Data=Post_Spike_Data(Post_Spike_Data(:,2)==Current_Cell,:);
                Mean_Firing_Rate=size(Cell_Spike_Data,1)/Run_Duration;
                Pre_Firing_Rate=size(Pre_Cell_Spike_Data,1)/Pre_Duration;
                Post_Firing_Rate=size(Post_Cell_Spike_Data,1)/Post_Duration;
                if size(Cell_Spike_Data,1)>3
                    Cell_Spike_Data(:,3)=0;
                    Cell_Spike_Data(1,3)=Cell_Spike_Data(2,1)-Cell_Spike_Data(1,1);
                    Cell_Spike_Data(end,3)=Cell_Spike_Data(end,1)-Cell_Spike_Data((end-1),1);
                    for N=2:(size(Cell_Spike_Data,1)-1)
                        Cell_Spike_Data(N,3)=min([Cell_Spike_Data(N,1)-Cell_Spike_Data((N-1),1),Cell_Spike_Data((N+1),1)-Cell_Spike_Data(N,1)]);
                    end
                    Cell_Spike_Data(:,4)=Cell_Spike_Data(:,3)<=Burst_Window;
                    Number_Of_Spikes_In_Bursts=sum(Cell_Spike_Data(:,4));
                    Number_Of_Bursts=sum(diff(Cell_Spike_Data(:,4))==1);
                    if Number_Of_Spikes_In_Bursts>0
                        Mean_Spikes_Per_Burst=Number_Of_Spikes_In_Bursts/Number_Of_Bursts;
                    else
                        Mean_Spikes_Per_Burst=0;
                    end
                    Firing_Rate_Of_Bursts=Number_Of_Spikes_In_Bursts/Run_Duration;
                    Burstiness_Index=Number_Of_Spikes_In_Bursts/size(Cell_Spike_Data,1);
                else
                    Number_Of_Spikes_In_Bursts=0;
                    Firing_Rate_Of_Bursts=0;
                    Burstiness_Index=0;
                    Mean_Spikes_Per_Burst=0;
                    Number_Of_Bursts=0;
                end                    
                if size(Pre_Cell_Spike_Data,1)>3
                    Pre_Cell_Spike_Data(:,3)=0;
                    Pre_Cell_Spike_Data(1,3)=Pre_Cell_Spike_Data(2,1)-Pre_Cell_Spike_Data(1,1);
                    Pre_Cell_Spike_Data(end,3)=Pre_Cell_Spike_Data(end,1)-Pre_Cell_Spike_Data((end-1),1);
                    for N=2:(size(Pre_Cell_Spike_Data,1)-1)
                        Pre_Cell_Spike_Data(N,3)=min([Pre_Cell_Spike_Data(N,1)-Pre_Cell_Spike_Data((N-1),1),Pre_Cell_Spike_Data((N+1),1)-Pre_Cell_Spike_Data(N,1)]);
                    end
                    Pre_Cell_Spike_Data(:,4)=Pre_Cell_Spike_Data(:,3)<=Burst_Window;
                    Number_Of_Spikes_In_Pre_Bursts=sum(Pre_Cell_Spike_Data(:,4));
                    Number_Of_Pre_Bursts=sum(diff(Pre_Cell_Spike_Data(:,4))==1);
                    if Number_Of_Spikes_In_Pre_Bursts>0
                        Mean_Spikes_Per_Pre_Burst=Number_Of_Spikes_In_Pre_Bursts/max([1,Number_Of_Pre_Bursts]);
                    else
                        Mean_Spikes_Per_Pre_Burst=0;
                    end
                    Firing_Rate_Of_Pre_Bursts=Number_Of_Spikes_In_Pre_Bursts/Pre_Duration;
                    Pre_Burstiness_Index=Number_Of_Spikes_In_Pre_Bursts/size(Pre_Cell_Spike_Data,1);
                else
                    Number_Of_Spikes_In_Pre_Bursts=0;
                    Firing_Rate_Of_Pre_Bursts=0;
                    Pre_Burstiness_Index=0;
                    Mean_Spikes_Per_Pre_Burst=0;
                    Number_Of_Pre_Bursts=0;
                end                    
                if size(Post_Cell_Spike_Data,1)>3
                    Post_Cell_Spike_Data(:,3)=0;
                    Post_Cell_Spike_Data(1,3)=Post_Cell_Spike_Data(2,1)-Post_Cell_Spike_Data(1,1);
                    Post_Cell_Spike_Data(end,3)=Post_Cell_Spike_Data(end,1)-Post_Cell_Spike_Data((end-1),1);
                    for N=2:(size(Post_Cell_Spike_Data,1)-1)
                        Post_Cell_Spike_Data(N,3)=min([Post_Cell_Spike_Data(N,1)-Post_Cell_Spike_Data((N-1),1),Post_Cell_Spike_Data((N+1),1)-Post_Cell_Spike_Data(N,1)]);
                    end
                    Post_Cell_Spike_Data(:,4)=Post_Cell_Spike_Data(:,3)<=Burst_Window;
                    Number_Of_Spikes_In_Post_Bursts=sum(Post_Cell_Spike_Data(:,4));
                    Number_Of_Post_Bursts=sum(diff(Post_Cell_Spike_Data(:,4))==1);
                    if Number_Of_Spikes_In_Post_Bursts>0
                        Mean_Spikes_Per_Post_Burst=Number_Of_Spikes_In_Post_Bursts/max([1,Number_Of_Post_Bursts]);
                    else
                        Mean_Spikes_Per_Post_Burst=0;
                    end
                    Firing_Rate_Of_Post_Bursts=Number_Of_Spikes_In_Post_Bursts/Post_Duration;
                    Post_Burstiness_Index=Number_Of_Spikes_In_Post_Bursts/size(Post_Cell_Spike_Data,1);
                else
                    Number_Of_Spikes_In_Post_Bursts=0;
                    Firing_Rate_Of_Post_Bursts=0;
                    Post_Burstiness_Index=0;
                    Mean_Spikes_Per_Post_Burst=0;
                    Number_Of_Post_Bursts=0;
                end                    
                Firing_Properties_Per_Cell_During_Behavior(Cell,:)=[Current_Cell,Max_Firing_Rate,Mean_Firing_Rate,Number_Of_Spikes_In_Bursts,Mean_Spikes_Per_Burst,Burstiness_Index,Pre_Firing_Rate,Number_Of_Spikes_In_Pre_Bursts,Mean_Spikes_Per_Pre_Burst,Pre_Burstiness_Index,Post_Firing_Rate,Number_Of_Spikes_In_Post_Bursts,Mean_Spikes_Per_Post_Burst,Post_Burstiness_Index,Mean_InField_Firing_Rate];
            end

            save('Firing_Properties_Per_Cell_During_Behavior','Firing_Properties_Per_Cell_During_Behavior');

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name Burst_Window Use_Running_Only

        end

        cd ..

    end
    
    clear Directory
    cd ..

end



% For all combined data:
% |                    1                     |                       2                    |             3            |                 4                 |                   5                 |             6             |                 7                  |                  8                   |           9          |               10                |            11             ||
% | Mean non-SWR Firing Rate During Behavior | Number Of Spikes In Bursts During Behavior | On-Task Burstiness Index | Pre-Task Rest Non-SWR Firing Rate | Number of Spikes in Pre-Task Bursts | Pre-Task Burstiness Index | Post-Task Rest Non-SWR Firing Rate | Number of Spikes in Post-Task Bursts | Post-Task Burstiness | Peak Firing Rate of Place Field | Mean In-Field Firing Rate ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load Firing_Properties_Per_Cell_During_Behavior
        load Deep_And_Superficial_Cell_Identities

        Deep_Firing_Properties=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Deep_Cells),[3,4,6,7,8,10,11,12,14,2,15]);
        Super_Firing_Properties=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Superficial_Cells),[3,4,6,7,8,10,11,12,14,2,15]);
        Large_Deep_Firing_Properties=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Deep_Cells),[3,4,6,7,8,10,11,12,14,2,15]);
        Large_Super_Firing_Properties=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Superficial_Cells),[3,4,6,7,8,10,11,12,14,2,15]);

        %Combine Across Rats
        if exist('All_Deep_Firing_Properties_During_Behavior','var')

            All_Deep_Firing_Properties_During_Behavior=[All_Deep_Firing_Properties_During_Behavior;Deep_Firing_Properties];
            All_Super_Firing_Properties_During_Behavior=[All_Super_Firing_Properties_During_Behavior;Super_Firing_Properties];
            All_Large_Deep_Firing_Properties_During_Behavior=[All_Large_Deep_Firing_Properties_During_Behavior;Large_Deep_Firing_Properties];
            All_Large_Super_Firing_Properties_During_Behavior=[All_Large_Super_Firing_Properties_During_Behavior;Large_Super_Firing_Properties];

            Per_Session_Mean_All_Deep_Firing_Properties=[Per_Session_Mean_All_Deep_Firing_Properties;mean(Deep_Firing_Properties,1,'omitnan')];
            Per_Session_Mean_All_Super_Firing_Properties=[Per_Session_Mean_All_Super_Firing_Properties;mean(Super_Firing_Properties,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Firing_Properties=[Per_Session_Mean_All_Large_Deep_Firing_Properties;mean(Large_Deep_Firing_Properties,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Firing_Properties=[Per_Session_Mean_All_Large_Super_Firing_Properties;mean(Large_Super_Firing_Properties,1,'omitnan')];
            
        else

            All_Deep_Firing_Properties_During_Behavior=Deep_Firing_Properties;
            All_Super_Firing_Properties_During_Behavior=Super_Firing_Properties;
            All_Large_Deep_Firing_Properties_During_Behavior=Large_Deep_Firing_Properties;
            All_Large_Super_Firing_Properties_During_Behavior=Large_Super_Firing_Properties;

            Per_Session_Mean_All_Deep_Firing_Properties=mean(Deep_Firing_Properties,1,'omitnan');
            Per_Session_Mean_All_Super_Firing_Properties=mean(Super_Firing_Properties,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Firing_Properties=mean(Large_Deep_Firing_Properties,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Firing_Properties=mean(Large_Super_Firing_Properties,1,'omitnan');

        end
        
        cd ..

    end
    
    clear Directory
    cd ..

end

clearvars -except Initial_Variables *All_*

cd AllRatsCombined

save('All_Firing_Properties_During_Behavior','*All_*')

cd ..

  
end



