function DSRP_DECODE_RIPPLE_EVENT_SHUFFLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% Four shuffles are saved: a cell ID shuffle, a field rotation
% shuffle, a spike time shuffle, and a posterior probability shuffle.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Ripple_Events','Ripple_Events')
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
load('Field_Data','Field_Data_Linear','Field_Data_Linear_In','Field_Data_Linear_Out')

% This truncates the Spike_Data to only excitatory neurons
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
Cell_List=unique(Spike_Data(:,2));

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.    
Field_Data_Linear2=Field_Data_Linear;
Field_Data_Linear_In2=Field_Data_Linear_In;
Field_Data_Linear_Out2=Field_Data_Linear_Out;
for N=1:size(Field_Data_Linear,2)
    Field=Field_Data_Linear(:,N);
    Field_In=Field_Data_Linear_In2(:,N);
    Field_Out=Field_Data_Linear_Out2(:,N);
    Minimum=min(Field(Field>0));
    Minimum_In=min(Field_In(Field_In>0));
    Minimum_Out=min(Field_Out(Field_Out>0));
    if ~isempty(Minimum)
        Field(Field<=0)=Minimum/10;
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_In)
        Field_In(Field_In<=0)=Minimum_In/10;
    else
        Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_Out)
        Field_Out(Field_Out<=0)=Minimum_Out/10;
    else
        Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data_Linear2(:,N)=Field;
    Field_Data_Linear_In2(:,N)=Field_In;
    Field_Data_Linear_Out2(:,N)=Field_Out;
    clear Minimum;
    clear Minimum_In;
    clear Minimum_Out;
    clear Field;
    clear Field_In;
    clear Field_Out;
end
clear N;

% Runs and saves the shuffles
if ~isfolder('Decoding_Shuffles')
    mkdir('Decoding_Shuffles')
end
cd Decoding_Shuffles
for Current_Ripple=1:size(Ripple_Events,1)
    Event_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
    if ~isempty(Event_Spike_Data)

        %This decodes the raw data and finds the virtual step size across each pair of consecutive windows
        [Decoded_Data_Total,~,~]=DSRP_BAYESIAN_DECODING_LINEAR(Event_Spike_Data,Field_Data_Linear,Field_Data_Linear_In,Field_Data_Linear_Out,Field_Data_Linear2,Field_Data_Linear_In2,Field_Data_Linear_Out2,Initial_Variables);

        %This runs shuffles
        Spike_Time_Shuffled_Data=zeros(size(Decoded_Data_Total,1),size(Decoded_Data_Total,2),Initial_Variables.Replay_Number_Of_Shuffles);
        Cell_Shuffled_Data=zeros(size(Decoded_Data_Total,1),size(Decoded_Data_Total,2),Initial_Variables.Replay_Number_Of_Shuffles);
        Field_Shuffled_Data=zeros(size(Decoded_Data_Total,1),size(Decoded_Data_Total,2),Initial_Variables.Replay_Number_Of_Shuffles);
        Probability_Shuffled_Data=zeros(size(Decoded_Data_Total,1),size(Decoded_Data_Total,2),Initial_Variables.Replay_Number_Of_Shuffles);
        Shuffle_Sequences=zeros(size(Decoded_Data_Total,2),4,Initial_Variables.Replay_Number_Of_Shuffles);
        for Shuffle=1:Initial_Variables.Replay_Number_Of_Shuffles
            for Step=1:size(Decoded_Data_Total,2)
                Probability_Shuffled_Data(:,Step,Shuffle)=Decoded_Data_Total(randperm(size(Decoded_Data_Total,1)),Step);
            end
            Shuffled_Cell_Data=Event_Spike_Data;
            Shuffled_Cell_IDs=zeros(max(Cell_List),1);
            Shuffled_Cell_IDs(Cell_List,1)=Cell_List(randperm(length(Cell_List)));
            Shuffled_Cell_Data(:,2)=Shuffled_Cell_IDs(Event_Spike_Data(:,2));
            Shuffled_Spike_Data=Event_Spike_Data;
            Shuffled_Spike_Data(:,2)=Event_Spike_Data(randperm(size(Event_Spike_Data,1)),2);
            Shuffled_Field_Data_Linear=Field_Data_Linear;
            Shuffled_Field_Data_Linear2=Field_Data_Linear2;
            Shuffled_Field_Data_Linear_In=Field_Data_Linear_In;
            Shuffled_Field_Data_Linear_In2=Field_Data_Linear_In2;
            Shuffled_Field_Data_Linear_Out=Field_Data_Linear_Out;
            Shuffled_Field_Data_Linear_Out2=Field_Data_Linear_Out2;
            for Cell=1:size(Field_Data_Linear,2)
                Rand=ceil(rand(1,1)*size(Field_Data_Linear,1));
                if Rand>1
                    Shuffled_Field_Data_Linear(:,Cell)=Field_Data_Linear([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                    Shuffled_Field_Data_Linear2(:,Cell)=Field_Data_Linear2([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                    Shuffled_Field_Data_Linear_In(:,Cell)=Field_Data_Linear_In([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                    Shuffled_Field_Data_Linear_In2(:,Cell)=Field_Data_Linear_In2([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                    Shuffled_Field_Data_Linear_Out(:,Cell)=Field_Data_Linear_Out([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                    Shuffled_Field_Data_Linear_Out2(:,Cell)=Field_Data_Linear_Out2([Rand:size(Field_Data_Linear,1),1:(Rand-1)],Cell);
                end
            end
            [Cell_Shuffle_Decoded_Data_Total,~,~]=DSRP_BAYESIAN_DECODING_LINEAR(Shuffled_Cell_Data,Field_Data_Linear,Field_Data_Linear_In,Field_Data_Linear_Out,Field_Data_Linear2,Field_Data_Linear_In2,Field_Data_Linear_Out2,Initial_Variables);
            [Spike_Shuffle_Decoded_Data_Total,~,~]=DSRP_BAYESIAN_DECODING_LINEAR(Shuffled_Spike_Data,Field_Data_Linear,Field_Data_Linear_In,Field_Data_Linear_Out,Field_Data_Linear2,Field_Data_Linear_In2,Field_Data_Linear_Out2,Initial_Variables);
            [Field_Shuffle_Decoded_Data_Total,~,~]=DSRP_BAYESIAN_DECODING_LINEAR(Event_Spike_Data,Shuffled_Field_Data_Linear,Shuffled_Field_Data_Linear_In,Shuffled_Field_Data_Linear_Out,Shuffled_Field_Data_Linear2,Shuffled_Field_Data_Linear_In2,Shuffled_Field_Data_Linear_Out2,Initial_Variables);
            Cell_Shuffled_Data(:,:,Shuffle)=Cell_Shuffle_Decoded_Data_Total;
            Spike_Time_Shuffled_Data(:,:,Shuffle)=Spike_Shuffle_Decoded_Data_Total;
            Field_Shuffled_Data(:,:,Shuffle)=Field_Shuffle_Decoded_Data_Total;
            [Cell_Shuffle_Max,Cell_Shuffle_Location]=max(Spike_Shuffle_Decoded_Data_Total);
            [Field_Shuffle_Max,Field_Shuffle_Location]=max(Field_Shuffle_Decoded_Data_Total);
            %Shuffle_Sequences
            %|            1           |              2        |             3           |              4         ||
            %| Cell_Shuffle Max Value | Cell_Shuffle Location | Field_Shuffle Max Value | Field_Shuffle Location ||
            Shuffle_Sequences(:,:,Shuffle)=[Cell_Shuffle_Max',Cell_Shuffle_Location',Field_Shuffle_Max',Field_Shuffle_Location'];
        end

        eval(sprintf('Decoded_Linear_Ripple_Event_Shuffle_Data.Ripple_%d_Cell_Shuffle=Cell_Shuffled_Data;',Current_Ripple));
        eval(sprintf('Decoded_Linear_Ripple_Event_Shuffle_Data.Ripple_%d_Field_Shuffle=Field_Shuffled_Data;',Current_Ripple));
        eval(sprintf('Decoded_Linear_Ripple_Event_Shuffle_Sequences.Ripple_%d_Shuffle_Sequences=Shuffle_Sequences;',Current_Ripple));
        eval(sprintf('save(''Decoded_Linear_Shuffles_Ripple_%d'',''Cell_Shuffled_Data'',''Field_Shuffled_Data'',''Spike_Time_Shuffled_Data'',''Probability_Shuffled_Data'',''-v7.3'');',Current_Ripple))
        clear Spike_Time_Shuffled_Data;
        clear Cell_Shuffled_Data;
        clear Field_Shuffled_Data;
        clear Probability_Shuffled_Data;
        clear Shuffle_Sequences;
    end
    fprintf('Finished shuffles for ripple %d of %d.\n',Current_Ripple,size(Ripple_Events,1));
end

cd ..

end