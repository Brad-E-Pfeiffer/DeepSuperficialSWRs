function DSRP_SPIKE_POSITION_INTEGRATION(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function loads up the spike data and the position data from previous
% functions (SRS_LOAD_RAW_SPIKE_AND_POSITION_DATA).
% 
% It then integrates these two by finding the nearest position data for
% every single spike. 
%
% Minimum_Time_Difference is the minimum time (in seconds) that a spike can
% be from the closest frame of the position data to be kept.  This can be
% used to eliminate spikes that occur when there is no position data
% available (such as if the video acquisition system suddently stops
% working).  If this value is not entered, the value is assumed to be
% infinity, so all spikes are kept.  A typical value is 0.1 (100
% milliseconds).  At a camera frame rate of 30 Hz, Neuralynx would have to
% miss 3 consecutive frames to lose any spikes.
% 
% These data are stored in a file called Spike_Data, which is a
% two-dimensional matrix in which the first dimension (rows) lists each
% individual spike, and the second dimension (columns) has the following
% form:
%
% Spike_Data
% |    1     |     2   |         3        |         4        |                 5                   |         6       || 
% | Time (s) | Cell ID | X Position (bin) | Y Position (bin) |   Head Direction (for open field)   | Velocity (cm/s) ||
% |          |         |                  |                  |                 or                  |                 ||
% |          |         |                  |                  | Linear Track Bin (for linear track) |                 || 
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Spike_Data','Spike_Data','Tetrode_Cell_IDs','Inhibitory_Neurons','Excitatory_Neurons')
load('Position_Data','Position_Data')
load('Epochs','Run_Times');

Position_Data(:,5)=DSRP_CALCULATE_VELOCITY(Position_Data);
Position_Data(:,2)=ceil(Position_Data(:,2)/Initial_Variables.Bin_Size);
Position_Data(:,3)=ceil(Position_Data(:,3)/Initial_Variables.Bin_Size);

% This section assigns the nearest position info to each spike 
Spike_Data(:,3:6)=[interp1(Position_Data(:,1),Position_Data(:,2),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,3),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,4),Spike_Data(:,1),'nearest'),interp1(Position_Data(:,1),Position_Data(:,5),Spike_Data(:,1),'nearest')];

% This section removes values not included in the Run_Times (i.e., when the rat was in the sleep box) 
Spike_Data(Spike_Data(:,1)<Run_Times(1,1),3:6)=NaN;
if size(Run_Times)==1
    Spike_Data(Spike_Data(:,1)>Run_Times(1,2),3:6)=NaN;
else
    for N=2:size(Run_Times,1)
        Spike_Data(Spike_Data(:,1)>Run_Times(N-1,2) & Spike_Data(:,1)<Run_Times(N,1),3:6)=NaN;
    end
    Spike_Data(Spike_Data(:,1)>Run_Times(end,2),3:6)=NaN;
end

% This section finds when the closest position data was too distant from the spike data
Nearest_Position_Time=interp1(Position_Data(:,1),Position_Data(:,1),Spike_Data(~isnan(Spike_Data(:,3)),1),'nearest');
Time_Difference=abs(Spike_Data(~isnan(Spike_Data(:,3)),1)-Nearest_Position_Time);
Index=find(Time_Difference<=Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference);
fprintf('%d out of %d spikes were within %d seconds of the closest position timepoint. Max time difference was %d seconds.\n',length(Index),length(Time_Difference),Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference,max(Time_Difference)),
Spike_Data(Time_Difference>Initial_Variables.Spike_Position_Integration_Minimum_Time_Difference,3:6)=NaN;
save('Spike_Data_Integrated_With_Position','Spike_Data','Excitatory_Neurons','Inhibitory_Neurons','Tetrode_Cell_IDs')

end