function DSRP_DEFINE_RIPPLE_CATEGORIES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and determines if it is a pre-,
% on-task, or post-experience ripple.  It also determines if the ripple
% encodes coherent or fragmented information and if it occured during SWS
% or wakefulness.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Ripple_Categories
% |        1      |                   2              |                   3                 |                           4                             |                 5             ||
% | Ripple Number | Epoch (1=pre, 2=on-task, 3=post) | Behavioral State (1=awake, 2=sleep) | Information Content (1=coherent, 2=fragmented, 0=other) | Percent Through Current Epoch ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Identifying Ripple Categories for %s Day %d.'')',Rat_Name,Experiment)); 

        if ~isfile('Ripple_Categories.mat')

            load Ripple_Events
            load Epochs
            load Coherent_Fragmented_Ripples
            load Spike_Data

            Ripple_Categories=zeros(size(Ripple_Events,1),4);
            Ripple_Categories(:,1)=1:size(Ripple_Events,1);
            Ripple_Categories(:,2)=NaN;
            Ripple_Categories(:,3)=1;
            Ripple_Categories(Coherent_Fragmented_Ripples(:,2)==1,4)=1;
            Ripple_Categories(Coherent_Fragmented_Ripples(:,3)==1,4)=2;
            for Current_Ripple=1:size(Ripple_Events)
                Start=Ripple_Events(Current_Ripple,1);
                End=Ripple_Events(Current_Ripple,2);
                if End<Run_Times(1,1)
                    Ripple_Categories(Current_Ripple,2)=1;
                    Ripple_Categories(Current_Ripple,5)=((Ripple_Events(Current_Ripple,1)-min(Spike_Data(:,1)))/(Run_Times(1,1)-min(Spike_Data(:,1))))*100;
                elseif Start>=Run_Times(1,1) && End<=Run_Times(1,2)
                    Ripple_Categories(Current_Ripple,2)=2;
                    Ripple_Categories(Current_Ripple,5)=((Ripple_Events(Current_Ripple,1)-Run_Times(1,1))/(Run_Times(1,2)-Run_Times(1,1)))*100;
                elseif size(Run_Times,1)==1 && Start>Run_Times(1,2)
                    Ripple_Categories(Current_Ripple,2)=3;
                    Ripple_Categories(Current_Ripple,5)=((Ripple_Events(Current_Ripple,1)-Run_Times(1,2))/(max(Spike_Data(:,1))-Run_Times(1,2)))*100;
                elseif size(Run_Times,1)>1 && Start>Run_Times(1,2) && End<Run_Times(2,1)
                    Ripple_Categories(Current_Ripple,2)=3;
                    Ripple_Categories(Current_Ripple,5)=((Ripple_Events(Current_Ripple,1)-Run_Times(1,2))/(Run_Times(2,1)-Run_Times(1,2)))*100;
                end
                for Current_Sleep_Epoch=1:size(SWS_Times,1)
                    if Start>SWS_Times(Current_Sleep_Epoch,1) && End<SWS_Times(Current_Sleep_Epoch,2)
                        Ripple_Categories(Current_Ripple,3)=2;
                    end
                end
            end

            save('Ripple_Categories','Ripple_Categories');

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end
    
    clear Directory
    cd ..

end


end