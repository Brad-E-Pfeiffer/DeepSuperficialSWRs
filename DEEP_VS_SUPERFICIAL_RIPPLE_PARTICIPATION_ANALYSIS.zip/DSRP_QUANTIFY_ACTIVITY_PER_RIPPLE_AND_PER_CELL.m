function DSRP_QUANTIFY_ACTIVITY_PER_RIPPLE_AND_PER_CELL(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and quantifies the firing rate of each
% neuron in pre-, on-task, and post-experience ripples and the percent
% change across these measures.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Activity_Per_Ripple_Per_Cell
% Each Row is a Ripple
% Each Column is a Cell
% Page 1 is participation (1 if it fired, 0 if it didn't)
% Page 2 is number of spikes
% Page 3 is firing rate (excluding SWRs in which the cell didn't fire)
% Page 4 is firing rate including zeros

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Per-Ripple, Per-Cell Activity in Ripples for %s Day %d.'')',Rat_Name,Experiment)); 

        if 1%~isfile('Activity_Per_Ripple_Per_Cell.mat')

            load Spike_Data
            load Ripple_Events
            load Epochs
            load Field_Data
            load Coherent_Fragmented_Ripples
            load Deep_And_Superficial_Cell_Identities

            Activity_Per_Ripple_Per_Cell=zeros(size(Ripple_Events,1),max(Spike_Data(:,2)),4);
            Activity_Per_Ripple_Per_Cell(:,:,:)=NaN;

            for N=1:max(Spike_Data(:,2))
                if sum(Inhibitory_Neurons==N)>0 %eliminates inhibitory neurons
                    Spike_Data=Spike_Data(Spike_Data(:,2)~=N,:);
                end
            end
            Cell_List=unique(Spike_Data(:,2));

            for Current_Ripple=1:size(Ripple_Events,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    for Current_Cell=1:length(Cell_List)
                        Cell=Cell_List(Current_Cell);
                        if sum(Ripple_Spike_Data(:,2)==Cell)>0
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,1)=1;
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,2)=sum(Ripple_Spike_Data(:,2)==Cell);
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,3)=sum(Ripple_Spike_Data(:,2)==Cell)/(Ripple_Events(Current_Ripple,2)-Ripple_Events(Current_Ripple,1));
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,4)=sum(Ripple_Spike_Data(:,2)==Cell)/(Ripple_Events(Current_Ripple,2)-Ripple_Events(Current_Ripple,1));
                        else
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,1)=0;
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,2)=0;
                            Activity_Per_Ripple_Per_Cell(Current_Ripple,Cell,4)=0;
                        end
                    end
                end
            end

            save('Activity_Per_Ripple_Per_Cell','Activity_Per_Ripple_Per_Cell');

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end
    
    clear Directory
    cd ..

end

end