function DSRP_PLOT_SHARP_WAVE_DEFLECTION_VS_GAMMA_PHASE_OFFSET(Initial_Variables)

% Slow_Gamma_Phase_Offset_Per_Tetrode
% |                           1                       |                        2                |                               3                       |                        4                    |                                5                           |      6     ||
% | Offset From Local Hemisphere Reference During Run | Offset From Global Reference During Run | Offset From Local Hemisphere Reference During Ripples | Offset From Global Reference During Ripples | Ripple-Induced Offset From Global Reference During Ripples | Tetrode ID ||

Gamma_Column=4;
Gamma_Offset=30;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
        load('Epochs','Run_Times')
        load('Ripple_Events','Ripple_Events')
        Ripple_Events_Sharp_Wave_Deflections=Ripple_Events_Sharp_Wave_Deflections(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
        Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
        load('Slow_Gamma_Phase_Offset_Per_Tetrode','Slow_Gamma_Phase_Offset_Per_Tetrode');
        load('Spike_Data','Tetrode_Cell_IDs');
        Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
        Sharp_Wave_Deflection_Per_Tetrode=Sharp_Wave_Deflection_Per_Tetrode(Tetrode_List,:);
        Slow_Gamma_Phase_Offset_Per_Tetrode=Slow_Gamma_Phase_Offset_Per_Tetrode(Tetrode_List,:);
        if exist('All','var')
            All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode]];
        else
            All=[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode];
        end
        if Rat==1
            if Experiment==1
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'ok','MarkerFaceColor','k','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'ok','MarkerFaceColor','k','MarkerSize',10);
            elseif Experiment==2
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'or','MarkerFaceColor','r','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'or','MarkerFaceColor','r','MarkerSize',10);
            elseif Experiment==3
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'ob','MarkerFaceColor','b','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'ob','MarkerFaceColor','b','MarkerSize',10);
            elseif Experiment==4
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'og','MarkerFaceColor','g','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'og','MarkerFaceColor','g','MarkerSize',10);
            end
        elseif Rat==2
            if Experiment==1
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^k','MarkerFaceColor','k','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^k','MarkerFaceColor','k','MarkerSize',10);
            elseif Experiment==2
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^r','MarkerFaceColor','r','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^r','MarkerFaceColor','r','MarkerSize',10);
            elseif Experiment==3
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^b','MarkerFaceColor','b','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^b','MarkerFaceColor','b','MarkerSize',10);
            elseif Experiment==4
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^g','MarkerFaceColor','g','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'^g','MarkerFaceColor','g','MarkerSize',10);
            end
        elseif Rat==3
            if Experiment==1
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'sk','MarkerFaceColor','k','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'sk','MarkerFaceColor','k','MarkerSize',10);
            elseif Experiment==2
                plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'sr','MarkerFaceColor','r','MarkerSize',10);
                %plot(Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+360+Gamma_Offset,Sharp_Wave_Deflection_Per_Tetrode,'sr','MarkerFaceColor','r','MarkerSize',10);
            end
        end

        cd ..

    end
    clear Directory
    cd ..
end

[All_SWR_Linear_R,All_SWR_Linear_P]=corr(All(:,1),All(:,2));

Coeff=polyfit(All(:,1),All(:,2),1);
Y_Vals=polyval(Coeff,[min(All(:,1)),max(All(:,1))]);
plot([min(All(:,1)),max(All(:,1))],[Y_Vals(1),Y_Vals(2)],'k--','LineWidth',3)

set(gca,'XLim',[-180 180]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'YLim',[-350 350]);

cd _Figures
print('-djpeg','Gamma_Phase_Offset_Vs_Sharp_Wave_Deflection_SWR_Gamma(Y=-350to350,X=-180to180).jpg');
close
cd ..






clearvars -except Initial_Variables

Gamma_Column=2;
Gamma_Offset=0;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
        load('Epochs','Run_Times')
        load('Ripple_Events','Ripple_Events')
        Ripple_Events_Sharp_Wave_Deflections=Ripple_Events_Sharp_Wave_Deflections(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
        Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
        load('Slow_Gamma_Phase_Offset_Per_Tetrode','Slow_Gamma_Phase_Offset_Per_Tetrode');
        Slow_Gamma_Phase_Offset_Per_Tetrode(:,1:2)=Slow_Gamma_Phase_Offset_Per_Tetrode(:,1:2)-180;
        load('Spike_Data','Tetrode_Cell_IDs');
        Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
        Sharp_Wave_Deflection_Per_Tetrode=Sharp_Wave_Deflection_Per_Tetrode(Tetrode_List,:);
        Slow_Gamma_Phase_Offset_Per_Tetrode=Slow_Gamma_Phase_Offset_Per_Tetrode(Tetrode_List,:);
        if Rat==1
            if Experiment==1 %The additions to each are to normalize each recording session
                All=[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+15,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)];
            elseif Experiment==2
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+15,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*2]];
            elseif Experiment==3
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+35,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*3]];
            elseif Experiment==4
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+30,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*4]];
            end
        elseif Rat==2
            if Experiment==1
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+30,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*5]];
            elseif Experiment==2
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+20,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*6]];
            elseif Experiment==3
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+20,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*7]];
            elseif Experiment==4
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+20,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*8]];
            end
        elseif Rat==3
            if Experiment==1
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+35,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*9]];
            elseif Experiment==2
                All=[All;[Slow_Gamma_Phase_Offset_Per_Tetrode(:,Gamma_Column)+35,Sharp_Wave_Deflection_Per_Tetrode,ones(length(Sharp_Wave_Deflection_Per_Tetrode),1)*10]];
            end
        end

        cd ..

    end
    clear Directory
    cd ..
end
All(All(:,1)>-30,1)=All(All(:,1)>-30,1)-360;
All(:,1)=All(:,1)+180;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    if N==1
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'ok','MarkerFaceColor','k','MarkerSize',10);
    elseif N==2
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'or','MarkerFaceColor','r','MarkerSize',10);
    elseif N==3
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'ob','MarkerFaceColor','b','MarkerSize',10);
    elseif N==4
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'og','MarkerFaceColor','g','MarkerSize',10);
    elseif N==5
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'^k','MarkerFaceColor','k','MarkerSize',10);
    elseif N==6
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'^r','MarkerFaceColor','r','MarkerSize',10);
    elseif N==7
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'^b','MarkerFaceColor','b','MarkerSize',10);
    elseif N==8
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'^g','MarkerFaceColor','g','MarkerSize',10);
    elseif N==9
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'sk','MarkerFaceColor','k','MarkerSize',10);
    elseif N==10
        plot(All(All(:,3)==N,1),All(All(:,3)==N,2),'sr','MarkerFaceColor','r','MarkerSize',10);
    end
    [R,P]=corr(All(All(:,3)==N,1),All(All(:,3)==N,2));
    [N,R,P]
end

[All_Run_Linear_R,All_Run_Linear_P]=corr(All(:,1),All(:,2));

Coeff=polyfit(All(:,1),All(:,2),1);
Y_Vals=polyval(Coeff,[min(All(:,1)),max(All(:,1))]);
plot([min(All(:,1)),max(All(:,1))],[Y_Vals(1),Y_Vals(2)],'k--','LineWidth',3)

set(gca,'XLim',[-220 140]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'YLim',[-350 350]);

cd _Figures
print('-djpeg','Gamma_Phase_Offset_Vs_Sharp_Wave_Deflection_Run_Gamma(Y=-350to350,X=-220to140).jpg');
close
cd ..



end