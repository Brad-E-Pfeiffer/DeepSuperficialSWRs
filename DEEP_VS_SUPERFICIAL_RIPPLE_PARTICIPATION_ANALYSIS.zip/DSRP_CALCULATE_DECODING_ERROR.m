function DSRP_CALCULATE_DECODING_ERROR(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% The purpose of this program is to decode the rat's position throughout
% the entire run portion of the experiment and determine the error between
% the peak posterior probability of this decoded position and the rat's 
% actual position.  It does this only for running periods (velocity greater
% than 5 cm/sec) and only for time bins with at least one spike.
% 
% This function calculates Position_Error, which is the distance from the
% rat's actual location and the location of peak posterior probability
% (converted back into cm) for every frame in which the rat was running
% above the velocity threshold.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Position_Data','Position_Data')
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
load('Field_Data','Field_Data')
load('Epochs','Run_Times')

% This truncates the Spike_Data to only those spikes that were during the
% behavioral sessions
Run_Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Times(1,1) & Spike_Data(:,1)<=Run_Times(1,2),:);
if size(Run_Times,1)>1
    for N=2:size(Run_Times,1)
        Run_Spike_Data=[Run_Spike_Data;Spike_Data(Spike_Data(:,1)>=Run_Times(N,1) & Spike_Data(:,1)<=Run_Times(N,2),:)];
    end
end

% This sets up the start and end times and pre-allocates the space for the
% position error measurement
Start_Time=Run_Times(1,1);
End_Time=Run_Times(end,end);
Number_Of_Bins=ceil((End_Time-Start_Time)/Initial_Variables.Behavior_Decoding_Window_Size);
Position_Error=zeros(Number_Of_Bins,2);

% First, because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.
Field_Data2=Field_Data;
for N=1:size(Field_Data2,3)
    Field=Field_Data2(:,:,N);
    Minimum=min(min(Field(Field>0)));
    if ~isempty(Minimum)
        if Minimum/10>0
            Field(Field<=0)=Minimum/10;
        else
            Field(Field<=0)=Minimum;
        end
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data2(:,:,N)=Field;
    clear Minimum;
    clear Field;
end

% This calculates the velocity for the position data
Position_Data(:,5)=DSRP_CALCULATE_VELOCITY(Position_Data);

% This restricts the decoding only to excitatory neurons
for N=1:length(Inhibitory_Neurons)
    Run_Spike_Data=Run_Spike_Data(Run_Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end

% Here, the program decodes the data.
Line=0;
while Start_Time<End_Time
    Subset_Position_Data=Position_Data(Position_Data(:,1)>=Start_Time & Position_Data(:,1)<(Start_Time+Initial_Variables.Behavior_Decoding_Window_Size),:);
    if ~isempty(Subset_Position_Data) && mean(Subset_Position_Data(:,5))>=Initial_Variables.Velocity_Cutoff
        Subset_Spike_Data=Run_Spike_Data(Run_Spike_Data(:,1)>=Start_Time & Run_Spike_Data(:,1)<(Start_Time+Initial_Variables.Behavior_Decoding_Window_Size),:);
        if ~isempty(Subset_Spike_Data)  %Can use this to exclude frames without spikes
            Line=Line+1;
            Actual_X_Position=mean(ceil(Subset_Position_Data(:,2))/Initial_Variables.Bin_Size);
            Actual_Y_Position=mean(ceil(Subset_Position_Data(:,3))/Initial_Variables.Bin_Size);
            Decoded_Matrix=prod(Field_Data2(:,:,Subset_Spike_Data(:,2)),3).*exp(-Initial_Variables.Behavior_Decoding_Window_Size*sum(Field_Data,3));
            if isinf(max(max(Decoded_Matrix)))
                Divider=1;
                while isinf(max(max(Decoded_Matrix)))
                    Decoded_Matrix=prod((Field_Data2(:,:,Subset_Spike_Data(:,2))/(2^Divider)),3).*exp(-Initial_Variables.Behavior_Decoding_Window_Size*sum((Field_Data/(2^Divider)),3));
                    Divider=Divider+1;
                end
                clear Divider;
            end
            Decoded_Matrix=Decoded_Matrix/sum(sum(Decoded_Matrix));
            if max(max(Decoded_Matrix))>0
                [Max_Y_Position,Max_X_Position]=find(Decoded_Matrix==max(max(Decoded_Matrix)),1,'first');
            else
                Max_Y_Position=0;
                Max_X_Position=0;
            end
            Error=sqrt((abs(Max_X_Position-Actual_X_Position)^2)+(abs(Max_Y_Position-Actual_Y_Position)^2))*Initial_Variables.Bin_Size; %This puts the error into cm rather than bins
            Position_Error(Line,:)=[Start_Time,Error];
        end
    end
    Start_Time=Start_Time+Initial_Variables.Behavior_Decoding_Window_Size;
end
Position_Error=Position_Error(1:Line,:);
Mean_Decoding_Error=mean(Position_Error(:,2));

Cumulative_Position_Error=Position_Error(:,2);
Cumulative_Position_Error=sort(Cumulative_Position_Error);
Cumulative_Position_Error(:,2)=0:1/(size(Cumulative_Position_Error,1)-1):1;
save('Position_Decoding_Error','Cumulative_Position_Error','Position_Error','Mean_Decoding_Error')

eval(sprintf('disp(''Mean error of position decoding (during active movement) for this session was %d cm.'')',Mean_Decoding_Error))

end