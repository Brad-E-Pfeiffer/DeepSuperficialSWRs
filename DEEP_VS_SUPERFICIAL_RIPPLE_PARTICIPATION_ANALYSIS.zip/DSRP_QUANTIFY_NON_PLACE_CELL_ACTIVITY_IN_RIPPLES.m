function DSRP_QUANTIFY_NON_PLACE_CELL_ACTIVITY_IN_RIPPLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and quantifies the firing rate of each
% neuron in pre-, on-task, and post-experience ripples and the percent
% change across these measures.  This function specifically analyzes only
% excitatory cells that did NOT have place fields (i.e., those cells that
% fired only minimally during exploration).
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Per_Non_Place_Cell_Firing_Across_Ripples (page 1 is all ripples, page 2 is only coherent ripples, page 3 is only fragmented ripples 
% |    1    |                      2                     |                    3                |                    4                  |               5              |                  6               |                7              |                   8                  |                     9                   |                   10                  ||
% | Cell ID | Mean Firing Rate in Pre-Experience Ripples | Mean Firing Rate In On-Task Ripples | Mean Firing Rate In Post-Task Ripples | Participation In Pre Ripples | Participation in On-Task Ripples | Participation in Post Ripples | Mean Participating FR in Pre Ripples | Mean Participating FR in OnTask Ripples | Mean Participating FR in Post Ripples ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Per-Non-Place-Cell Participation in Ripples for %s Day %d.'')',Rat_Name,Experiment)); 

        if ~isfile('Per_Non_Place_Cell_Firing_Across_Ripples.mat')

            load Spike_Data
            load Ripple_Events
            load Epochs
            load Field_Data
            load Coherent_Fragmented_Ripples
            for N=1:max(Spike_Data(:,2))
                if max(max(Field_Data(:,:,N)))>0 || sum(Inhibitory_Neurons==N)>0 %eliminates cells with place fields and inhibitory neurons
                    Spike_Data=Spike_Data(Spike_Data(:,2)~=N,:);
                end
            end

            Excitatory_Neurons=unique(Spike_Data(:,2));

            Per_Non_Place_Cell_Firing_Across_Ripples=zeros(length(Excitatory_Neurons),10,3);

            Pre_Ripple_Events=Ripple_Events(Ripple_Events(:,2)<Run_Times(1,1),:);
            Pre_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,2)<Run_Times(1,1),:);
            OnTask_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            OnTask_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            Post_Ripple_Events=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
            Post_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,1)>Run_Times(1,2),:);
            if size(Run_Times,1)>1  %Trim data to only first run and first post-sleep session
                Post_Coherent_Fragmented_Ripples=Post_Coherent_Fragmented_Ripples(Post_Ripple_Events(:,2)<Run_Times(2,1),:);
                Post_Ripple_Events=Post_Ripple_Events(Post_Ripple_Events(:,2)<Run_Times(2,1),:);
                Spike_Data=Spike_Data(Spike_Data(:,1)<Run_Times(2,1),:);
            end

            for Cell=1:length(Excitatory_Neurons)
                Current_Cell=Excitatory_Neurons(Cell);
                Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Current_Cell,:);
                Pre_Firing_Rate=zeros(size(Pre_Ripple_Events,1),3);
                OnTask_Firing_Rate=zeros(size(OnTask_Ripple_Events,1),3);
                Post_Firing_Rate=zeros(size(Post_Ripple_Events,1),3);
                Pre_Coherent_Firing_Rate=zeros(1,3);
                OnTask_Coherent_Firing_Rate=zeros(1,3);
                Post_Coherent_Firing_Rate=zeros(1,3);
                Pre_Fragmented_Firing_Rate=zeros(1,3);
                OnTask_Fragmented_Firing_Rate=zeros(1,3);
                Post_Fragmented_Firing_Rate=zeros(1,3);
                for N=1:size(Pre_Ripple_Events,1)
                    Spikes=Cell_Spike_Data(Cell_Spike_Data(:,1)>=Pre_Ripple_Events(N,1) & Cell_Spike_Data(:,1)<=Pre_Ripple_Events(N,2),:);
                    if ~isempty(Spikes)
                        Pre_Firing_Rate(N,:)=[size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1)),1,size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1))];
                        if Pre_Coherent_Fragmented_Ripples(N,2)==1
                            Pre_Coherent_Firing_Rate=[Pre_Coherent_Firing_Rate;[size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1)),1,size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1))]];
                        elseif Pre_Coherent_Fragmented_Ripples(N,3)==1
                            Pre_Fragmented_Firing_Rate=[Pre_Fragmented_Firing_Rate;[size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1)),1,size(Spikes,1)/(Pre_Ripple_Events(N,2)-Pre_Ripple_Events(N,1))]];
                        end
                    else
                        Pre_Firing_Rate(N,:)=[0,0,NaN];
                        if Pre_Coherent_Fragmented_Ripples(N,2)==1
                            Pre_Coherent_Firing_Rate=[Pre_Coherent_Firing_Rate;[0,0,NaN]];
                        elseif Pre_Coherent_Fragmented_Ripples(N,3)==1
                            Pre_Fragmented_Firing_Rate=[Pre_Fragmented_Firing_Rate;[0,0,NaN]];
                        end
                    end
                end
                Pre_Coherent_Firing_Rate=Pre_Coherent_Firing_Rate(2:end,:);
                Pre_Fragmented_Firing_Rate=Pre_Fragmented_Firing_Rate(2:end,:);
                for N=1:size(OnTask_Ripple_Events,1)
                    Spikes=Cell_Spike_Data(Cell_Spike_Data(:,1)>=OnTask_Ripple_Events(N,1) & Cell_Spike_Data(:,1)<=OnTask_Ripple_Events(N,2),:);
                    if ~isempty(Spikes)
                        OnTask_Firing_Rate(N,:)=[size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1)),1,size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1))];
                        if OnTask_Coherent_Fragmented_Ripples(N,2)==1
                            OnTask_Coherent_Firing_Rate=[OnTask_Coherent_Firing_Rate;[size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1)),1,size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1))]];
                        elseif OnTask_Coherent_Fragmented_Ripples(N,3)==1
                            OnTask_Fragmented_Firing_Rate=[OnTask_Fragmented_Firing_Rate;[size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1)),1,size(Spikes,1)/(OnTask_Ripple_Events(N,2)-OnTask_Ripple_Events(N,1))]];
                        end
                    else
                        OnTask_Firing_Rate(N,:)=[0,0,NaN];
                        if OnTask_Coherent_Fragmented_Ripples(N,2)==1
                            OnTask_Coherent_Firing_Rate=[OnTask_Coherent_Firing_Rate;[0,0,NaN]];
                        elseif OnTask_Coherent_Fragmented_Ripples(N,3)==1
                            OnTask_Fragmented_Firing_Rate=[OnTask_Fragmented_Firing_Rate;[0,0,NaN]];
                        end
                    end
                end
                OnTask_Coherent_Firing_Rate=OnTask_Coherent_Firing_Rate(2:end,:);
                OnTask_Fragmented_Firing_Rate=OnTask_Fragmented_Firing_Rate(2:end,:);
                for N=1:size(Post_Ripple_Events,1)
                    Spikes=Cell_Spike_Data(Cell_Spike_Data(:,1)>=Post_Ripple_Events(N,1) & Cell_Spike_Data(:,1)<=Post_Ripple_Events(N,2),:);
                    if ~isempty(Spikes)
                        Post_Firing_Rate(N,:)=[size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1)),1,size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1))];
                        if Post_Coherent_Fragmented_Ripples(N,2)==1
                            Post_Coherent_Firing_Rate=[Post_Coherent_Firing_Rate;[size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1)),1,size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1))]];
                        elseif Post_Coherent_Fragmented_Ripples(N,3)==1
                            Post_Fragmented_Firing_Rate=[Post_Fragmented_Firing_Rate;[size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1)),1,size(Spikes,1)/(Post_Ripple_Events(N,2)-Post_Ripple_Events(N,1))]];
                        end
                    else
                        Post_Firing_Rate(N,:)=[0,0,NaN];
                        if Post_Coherent_Fragmented_Ripples(N,2)==1
                            Post_Coherent_Firing_Rate=[Post_Coherent_Firing_Rate;[0,0,NaN]];
                        elseif Post_Coherent_Fragmented_Ripples(N,3)==1
                            Post_Fragmented_Firing_Rate=[Post_Fragmented_Firing_Rate;[0,0,NaN]];
                        end
                    end
                end
                Post_Coherent_Firing_Rate=Post_Coherent_Firing_Rate(2:end,:);
                Post_Fragmented_Firing_Rate=Post_Fragmented_Firing_Rate(2:end,:);

                Per_Non_Place_Cell_Firing_Across_Ripples(Cell,:,1)=[Current_Cell,mean(Pre_Firing_Rate(:,1),'omitnan'),mean(OnTask_Firing_Rate(:,1),'omitnan'),mean(Post_Firing_Rate(:,1),'omitnan'),mean(Pre_Firing_Rate(:,2),'omitnan'),mean(OnTask_Firing_Rate(:,2),'omitnan'),mean(Post_Firing_Rate(:,2),'omitnan'),mean(Pre_Firing_Rate(:,3),'omitnan'),mean(OnTask_Firing_Rate(:,3),'omitnan'),mean(Post_Firing_Rate(:,3),'omitnan')];
                Per_Non_Place_Cell_Firing_Across_Ripples(Cell,:,2)=[Current_Cell,mean(Pre_Coherent_Firing_Rate(:,1),'omitnan'),mean(OnTask_Coherent_Firing_Rate(:,1),'omitnan'),mean(Post_Coherent_Firing_Rate(:,1),'omitnan'),mean(Pre_Coherent_Firing_Rate(:,2),'omitnan'),mean(OnTask_Coherent_Firing_Rate(:,2),'omitnan'),mean(Post_Coherent_Firing_Rate(:,2),'omitnan'),mean(Pre_Coherent_Firing_Rate(:,3),'omitnan'),mean(OnTask_Coherent_Firing_Rate(:,3),'omitnan'),mean(Post_Coherent_Firing_Rate(:,3),'omitnan')];
                Per_Non_Place_Cell_Firing_Across_Ripples(Cell,:,3)=[Current_Cell,mean(Pre_Fragmented_Firing_Rate(:,1),'omitnan'),mean(OnTask_Fragmented_Firing_Rate(:,1),'omitnan'),mean(Post_Fragmented_Firing_Rate(:,1),'omitnan'),mean(Pre_Fragmented_Firing_Rate(:,2),'omitnan'),mean(OnTask_Fragmented_Firing_Rate(:,2),'omitnan'),mean(Post_Fragmented_Firing_Rate(:,2),'omitnan'),mean(Pre_Fragmented_Firing_Rate(:,3),'omitnan'),mean(OnTask_Fragmented_Firing_Rate(:,3),'omitnan'),mean(Post_Fragmented_Firing_Rate(:,3),'omitnan')];

            end

            save('Per_Non_Place_Cell_Firing_Across_Ripples','Per_Non_Place_Cell_Firing_Across_Ripples')

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end
    
    clear Directory
    cd ..

end

clearvars -except Initial_Variables

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load Per_Non_Place_Cell_Firing_Across_Ripples
        load Deep_And_Superficial_Cell_Identities
        
        Deep_Per_Non_Place_Cell_Firing_Across_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,1),Deep_Cells),:,1);
        Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,1),Large_Deep_Cells),:,1);
        Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,1),Superficial_Cells),:,1);
        Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,1),Large_Superficial_Cells),:,1);
        if exist('All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples','var')
            All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples=[All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples;[Deep_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Deep_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)]]; %adds session number to the end
        else
            All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples=[Deep_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Deep_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples','var')
            All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples=[All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples;[Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples=[Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples','var')
            All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=[All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples;[Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=[Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples','var')
            All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=[All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples;[Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples=[Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,ones(size(Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end


        Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,2),Deep_Cells),:,2);
        Large_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,2),Large_Deep_Cells),:,2);
        Superficial_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,2),Superficial_Cells),:,2);
        Large_Super_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,2),Large_Superficial_Cells),:,2);
        if exist('All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples','var')
            All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=[All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples;[Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples=[Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples','var')
            All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples=[All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples;[Large_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Large_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples=[Large_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Large_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples','var')
            All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples=[All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples;[Superficial_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Superficial_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples=[Superficial_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Superficial_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples','var')
            All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples=[All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples;[Large_Super_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Large_Super_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples=[Large_Super_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,ones(size(Large_Super_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end


        Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,3),Deep_Cells),:,3);
        Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,3),Large_Deep_Cells),:,3);
        Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,3),Superficial_Cells),:,3);
        Large_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples=Per_Non_Place_Cell_Firing_Across_Ripples(ismember(Per_Non_Place_Cell_Firing_Across_Ripples(:,1,3),Large_Superficial_Cells),:,3);
        if exist('All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples','var')
            All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=[All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples;[Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=[Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples','var')
            All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=[All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples;[Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples=[Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples','var')
            All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples=[All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples;[Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples=[Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end
        if exist('All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples','var')
            All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples=[All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples;[Large_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Large_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)]];
        else
            All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples=[Large_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,ones(size(Large_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,1),1)*(((Rat-1)*4)+Experiment)];
        end

        
        cd ..

    end
    
    clear Directory
    cd ..

end

cd _Figures
mkdir NonPlaceCells
cd NonPlaceCells

clearvars -except Initial_Variables All_*

%Calculate Per Session Mean Values
Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples=zeros(max(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)),size(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,2)+3);
Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples=zeros(max(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)),size(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,2)+3);
Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples=zeros(max(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)),size(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples,2)+3);
Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples=zeros(max(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)),size(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples,2)+3);
for Session=1:max(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11))
    Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(Session,:)=[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,4)./All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,2),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,7)./All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,5),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,10)./All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(Session,:)=[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,4)./All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,2),'omitnan'),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,7)./All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,5),'omitnan'),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,10)./All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,8),'omitnan')];
end
for Session=1:max(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11))
    Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(Session,:)=[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,4)./All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,7)./All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,10)./All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(Session,:)=[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,4)./All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,7)./All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,10)./All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,8),'omitnan')];
end

Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples=zeros(max(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)),size(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples,2)+3);
Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples=zeros(max(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)),size(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples,2)+3);
Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples=zeros(max(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)),size(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples,2)+3);
Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples=zeros(max(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)),size(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples,2)+3);
for Session=1:max(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11))
    Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(Session,:)=[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,4)./All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,2),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,7)./All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,5),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,10)./All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(Session,:)=[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,4)./All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,2),'omitnan'),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,7)./All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,5),'omitnan'),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,10)./All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,11)==Session,8),'omitnan')];
end
for Session=1:max(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11))
    Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(Session,:)=[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,4)./All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,7)./All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,10)./All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(Session,:)=[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,4)./All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,7)./All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,10)./All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,11)==Session,8),'omitnan')];
end

Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples=zeros(max(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)),size(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,2)+3);
Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples=zeros(max(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)),size(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples,2)+3);
Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples=zeros(max(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)),size(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples,2)+3);
Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples=zeros(max(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)),size(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples,2)+3);
for Session=1:max(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11))
    Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(Session,:)=[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,4)./All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,2),'omitnan'),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,7)./All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,5),'omitnan'),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,10)./All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(Session,:)=[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,4)./All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,2),'omitnan'),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,7)./All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,5),'omitnan'),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,10)./All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,8),'omitnan')];
end
for Session=1:max(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11))
    Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(Session,:)=[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,4)./All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,7)./All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,10)./All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,11)==Session,8),'omitnan')];
    Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(Session,:)=[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,:),1,'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,4)./All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,2),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,7)./All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,5),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,10)./All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,11)==Session,8),'omitnan')];
end



%==========================================================================
%==========================================================================
%
% Plot All Cells
%
%==========================================================================
%==========================================================================


%Plot Per Session Cell Participation Ratios
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(N,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(N,7)])
    plot([1,2],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(N,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Non_Place_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participation_Fraction_P,Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))
[Per_Session_Superficial_Participation_Fraction_P,Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,5),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,7))


%Plot Per Session Firing Rate Of Participating Cells
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(N,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(N,10)])
    plot([1,2],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(N,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Non_Place_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participating_Firing_Rate_P,Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8),Per_Session_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))
[Per_Session_Superficial_Participating_Firing_Rate_P,Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,8),Per_Session_Superficial_Non_Place_Cell_Firing_Across_Ripples(:,10))


%Plot Per Session Cell Participation Ratios For Only Coherent Ripples
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(N,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(N,7)])
    plot([1,2],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(N,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))+(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))-(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))+(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))-(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5))+(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5))-(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))+(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))-(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Non_Place_Cell_Participation_Fraction_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participation_Fraction_P,Coherent_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))
[Coherent_Per_Session_Superficial_Participation_Fraction_P,Coherent_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,5),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,7))



%Plot Per Session Firing Rate Of Participating Cells For Only Coherent Ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(N,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(N,10)])
    plot([1,2],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(N,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))+(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))-(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))+(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))-(std(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8))+(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8))-(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))+(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))-(std(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Non_Place_Cell_Firing_Rate_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participating_Firing_Rate_P,Coherent_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8),Per_Session_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))
[Coherent_Per_Session_Superficial_Participating_Firing_Rate_P,Coherent_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,8),Per_Session_Superficial_NPCell_Firing_Across_Coherent_Ripples(:,10))


%Plot Per Session Cell Participation Ratios For Only Fragmented Ripples
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,7)])
    plot([1,2],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(N,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Non_Place_Cell_Participation_Fraction_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participation_Fraction_P,Fragmented_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))
[Fragmented_Per_Session_Superficial_Participation_Fraction_P,Fragmented_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,5),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,7))



%Plot Per Session Firing Rate Of Participating Cells For Only Fragmented Ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,10)])
    plot([1,2],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(N,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))+(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))-(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))+(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))-(std(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8))+(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8))-(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))+(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))-(std(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Non_Place_Cell_Firing_Rate_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participating_Firing_Rate_P,Fragmented_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8),Per_Session_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))
[Fragmented_Per_Session_Superficial_Participating_Firing_Rate_P,Fragmented_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,8),Per_Session_Superficial_NPCell_Firing_Across_Fragmented_Ripples(:,10))


%==========================================================================
%==========================================================================
%
% Plot Only Large-Amplitude-Spike Large Cells
%
%==========================================================================
%==========================================================================


%Plot Per Session Cell Participation Ratios
Pre_Bin=5;
Post_Bin=7;
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(N,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(N,7)])
    plot([1,2],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(N,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
Session=1;
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,[Pre_Bin,Post_Bin]),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,[Pre_Bin,Post_Bin]),'omitnan')],'k');
plot([1,1],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin),'omitnan')-std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin),'omitnan')+std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Pre_Bin))))],'k');
plot([2,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin),'omitnan')-std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin),'omitnan')+std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,11)==Session,Post_Bin))))],'k');
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5))+(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5))-(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))+(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))-(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Non_Place_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Large_Deep_Participation_Fraction_P,Per_Session_Large_Deep_Participation_Fraction_H]=signrank(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,5),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,7))
[Per_Session_Large_Superficial_Participation_Fraction_P,Per_Session_Large_Superficial_Participation_Fraction_H]=signrank(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,5),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,7))


%Plot Per Session Firing Rate Of Participating Large Cells
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(N,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(N,10)])
    plot([1,2],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(N,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8))+(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8))-(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))+(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10)),mean(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))-(std(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Non_Place_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Large_Deep_Participating_Firing_Rate_P,Per_Session_Large_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,8),Per_Session_Large_Deep_Non_Place_Cell_Firing_Across_Ripples(:,10))
[Per_Session_Large_Superficial_Participating_Firing_Rate_P,Per_Session_Large_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,8),Per_Session_Large_Superficial_NP_Cell_Firing_Across_Ripples(:,10))


%Plot Per Session Large Cell Participation Ratios For Only Coherent Ripples
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(N,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(N,7)])
    plot([1,2],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(N,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5))+(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5))-(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))+(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))-(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Large_Non_Place_Cell_Participation_Fraction_In_Coherent_Ripples(Large_DeepPre,Large_DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Large_Deep_Participation_Fraction_P,Coherent_Per_Session_Large_Deep_Participation_Fraction_H]=signrank(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,5),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,7))
[Coherent_Per_Session_Large_Superficial_Participation_Fraction_P,Coherent_Per_Session_Large_Superficial_Participation_Fraction_H]=signrank(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,5),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,7))



%Plot Per Session Firing Rate Of Participating Large Cells For Only Coherent Ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(N,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(N,10)])
    plot([1,2],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(N,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8))+(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8))-(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))+(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10)),mean(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))-(std(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Large_Non_Place_Cell_Firing_Rate_In_Coherent_Ripples(Large_DeepPre,Large_DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Large_Deep_Participating_Firing_Rate_P,Coherent_Per_Session_Large_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,8),Per_Session_Large_Deep_NPCell_Firing_Across_Coherent_Ripples(:,10))
[Coherent_Per_Session_Large_Superficial_Participating_Firing_Rate_P,Coherent_Per_Session_Large_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,8),Per_Session_Large_Superficial_NPCell_Firing_Coherent_Ripples(:,10))


%Plot Per Session Large Cell Participation Ratios For Only Fragmented Ripples
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,7)])
    plot([1,2],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(N,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(N,7)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,7)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,7)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,7)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,7)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,7)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,7)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,7)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,7)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,7)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,7)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,7)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,7)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,7)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,7)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,7)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,7)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,7)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,7)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,7)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,7)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,7)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,7)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,7)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,7)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5))+(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5))-(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))+(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))-(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Large_Non_Place_Cell_Participation_Fraction_In_Fragmented_Ripples(Large_DeepPre,Large_DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Large_Deep_Participation_Fraction_P,Fragmented_Per_Session_Large_Deep_Participation_Fraction_H]=signrank(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,5),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,7))
[Fragmented_Per_Session_Large_Superficial_Participation_Fraction_P,Fragmented_Per_Session_Large_Superficial_Participation_Fraction_H]=signrank(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,5),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,7))



%Plot Per Session Firing Rate Of Participating Large Cells For Only Fragmented Ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(N,10)])
    plot([1,2],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(N,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(N,10)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(1,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,10)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(1,10)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(2,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,10)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(2,10)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(3,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,10)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(3,10)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(4,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,10)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(4,10)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(5,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,10)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(5,10)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(6,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,10)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(6,10)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(7,10)],'r--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,10)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(7,10)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(8,10)],'g--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,10)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(8,10)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(9,10)],'k--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,10)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(9,10)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(10,10)],'b--');
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,10)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(10,10)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))+(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10)),mean(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))-(std(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8))+(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8))-(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))+(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10)),mean(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))-(std(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Large_Non_Place_Cell_Firing_Rate_In_Fragmented_Ripples(Large_DeepPre,Large_DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Large_Deep_Participating_Firing_Rate_P,Fragmented_Per_Session_Large_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,8),Per_Session_Large_Deep_NPCell_Firing_Across_Fragmented_Ripples(:,10))
[Fragmented_Per_Session_Large_Superficial_Participating_Firing_Rate_P,Fragmented_Per_Session_Large_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,8),Per_Session_Large_Superficial_NPCell_Firing_Frag_Ripples(:,10))




%==========================================================================
%==========================================================================
%
% Plot Per Cell Means +/- SEM
%
%==========================================================================
%==========================================================================

%Plot Per Cell Participation Ratios In All Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)))),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7)))),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participation_Fraction_P=signrank(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))*3 %Times 3 for Bonferroni correction
Per_Cell_Superficial_Participation_Fraction_P=signrank(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))*3
Per_Cell_Pre_Participation_Fraction_P=ranksum(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))*3


%Plot Per Cell Firing Rate of Participating Cells In All Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)))),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10)))),mean(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participating_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participating_Firing_Rate_P=signrank(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))*3 %Times 3 for Bonferroni correction
Per_Cell_Superficial_Participating_Firing_Rate_P=signrank(All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))*3
Per_Cell_Pre_Participating_Firing_Rate_P=ranksum(All_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))*3


%Plot Per Cell Participation Ratios In Only Coherent Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7)))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))-(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5)))),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))+(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))-(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7)))),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))+(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participation_Fraction_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participation_Fraction_Coherent_P=signrank(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5),All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,7))*3
Per_Cell_Superficial_Participation_Fraction_Coherent_P=signrank(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5),All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,7))*3
Per_Cell_Pre_Participation_Fraction_Coherent_P=ranksum(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,5),All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,5))*3


%Plot Per Cell Firing Rate of Participating Cells In Only Coherent Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8))))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8)))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')-(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10))))),mean(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')+(std(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10)))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')-(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8))))),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')+(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8)))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')-(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10))))),mean(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')+(std(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10)))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participating_Cell_Firing_Rate_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participating_Firing_Rate_Coherent_P=signrank(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10)),8),All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,10)),10))*3
Per_Cell_Superficial_Participating_Firing_Rate_Coherent_P=signrank(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10)),8),All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,10)),10))*3
Per_Cell_Pre_Participating_Firing_Rate_Coherent_P=ranksum(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Deep_Per_Non_Place_Cell_Firing_Across_Coherent_Ripples(:,8)),8),All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(~isnan(All_Superficial_Per_NonPlaceCell_Firing_Across_Coherent_Ripples(:,8)),8))*3


%Plot Per Cell Participation Ratios In Only Fragmented Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)))),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7)))),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)))),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7)))),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participation_Fraction_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participation_Fraction_Fragmented_P=signrank(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5),All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))*3
Per_Cell_Superficial_Participation_Fraction_Fragmented_P=signrank(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5),All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))*3
Per_Cell_Pre_Participation_Fraction_Fragmented_P=ranksum(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5),All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))*3


%Plot Per Cell Firing Rate of Participating Cells In Only Fragmented Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([1 1],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')-(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8))))),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')+(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)))))],'k','LineWidth',3);
plot([2 2],[mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')-(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10))))),mean(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')+(std(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)))))],'k','LineWidth',3);
plot([4,5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([4 4],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')-(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8))))),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')+(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)))))],'k','LineWidth',3);
plot([5 5],[mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')-(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10))))),mean(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')+(std(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Non_Place_Cell_Participating_Cell_Firing_Rate_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Deep_Participating_Firing_Rate_Fragmented_P=signrank(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),8),All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),10))*3
Per_Cell_Superficial_Participating_Firing_Rate_Fragmented_P=signrank(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),8),All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),10))*3
Per_Cell_Pre_Participating_Firing_Rate_Fragmented_P=ranksum(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)),8),All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Superficial_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)),8))*3

%==========================================================================
%==========================================================================
%
% Plot Per-Cell For Only Large Amplitude Spike Cells
%
%==========================================================================
%==========================================================================


%Plot Per Large Cell Participation Ratios
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)))),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7)))),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))-(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5)))),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))+(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))-(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7)))),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))+(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Large_Deep_Participation_Fraction_P=signrank(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))*3
Per_Cell_Large_Superficial_Participation_Fraction_P=signrank(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,7))*3
Per_Cell_Large_Pre_Participation_Fraction_P=ranksum(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,5),All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,5))*3

%Plot Per Large Cell Firing Rate of Participating Cells
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)))),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10)))),mean(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))-(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8)))),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))+(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))-(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10)))),mean(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))+(std(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))/sqrt(length(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participating_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Cell_Large_Deep_Participating_Firing_Rate_P=signrank(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))*3
Per_Cell_Large_Superficial_Participating_Firing_Rate_P=signrank(All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,10))*3
Per_Cell_Large_Pre_Participating_Firing_Rate_P=ranksum(All_Large_Deep_Per_Non_Place_Cell_Firing_Across_Ripples(:,8),All_Large_Superficial_Per_Non_Place_Cell_Firing_Across_Ripples(:,8))*3


%Plot Per Large Cell Participation Ratios In Only Coherent Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5))-(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5)))),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5))+(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))-(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7)))),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))+(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5)),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5)))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7)))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participation_Fraction_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Large_Cell_Deep_Participation_Fraction_Coherent_P=signrank(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5),All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,7))*3
Per_Large_Cell_Superficial_Participation_Fraction_Coherent_P=signrank(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5),All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,7))*3
Per_Large_Cell_Pre_Participation_Fraction_Coherent_P=ranksum(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,5),All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,5))*3


%Plot Per Large Cell Firing Rate of Participating Cells In Only Coherent Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')-(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8))))),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')+(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8)))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')-(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10))))),mean(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')+(std(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10)))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8))))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8)))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10))))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10)))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participating_Cell_Firing_Rate_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Large_Cell_Deep_Participating_Firing_Rate_Coherent_P=signrank(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10)),8),All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,10)),10))*3
Per_Large_Cell_Superficial_Participating_Firing_Rate_Coherent_P=signrank(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10)),8),All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8)) & ~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,10)),10))*3
Per_Large_Cell_Pre_Participating_Firing_Rate_Coherent_P=ranksum(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Deep_Per_NonPlace_Cell_Firing_Across_Coherent_Ripples(:,8)),8),All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Coherent_Ripples(:,8)),8))*3


%Plot Per Large Cell Participation Ratios In Only Fragmented Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))-(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5)))),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))+(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))/sqrt(length(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))-(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7)))),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))+(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))/sqrt(length(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5)),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5)),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5)))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7)))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))/sqrt(length(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participation_Fraction_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Large_Cell_Deep_Participation_Fraction_Fragmented_P=signrank(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5),All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,7))*3
Per_Large_Cell_Superficial_Participation_Fraction_Fragmented_P=signrank(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5),All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,7))*3
Per_Large_Cell_Pre_Participation_Fraction_Fragmented_P=ranksum(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,5),All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,5))*3


%Plot Per Cell Firing Rate of Participating Cells In Only Fragmented Ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([1,2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan'),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([1 1],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')-(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8))))),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')+(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)))))],'k','LineWidth',3);
plot([2 2],[mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')-(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10))))),mean(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')+(std(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)))))],'k','LineWidth',3);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([4,5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan'),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')],'k','LineWidth',3);
plot([4 4],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan')-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8))))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan')+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8)))))],'k','LineWidth',3);
plot([5 5],[mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')-(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10))))),mean(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')+(std(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10),'omitnan')/sqrt(sum(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10)))))],'k','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Non_Place_Cell_Participating_Cell_Firing_Rate_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

Per_Large_Cell_Deep_Participating_Firing_Rate_Fragmented_P=signrank(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),8),All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)) & ~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,10)),10))*3
Per_Large_Cell_Superficial_Participating_Firing_Rate_Fragmented_P=signrank(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8)) & ~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10)),8),All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8)) & ~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,10)),10))*3
Per_Large_Cell_Pre_Participating_Firing_Rate_Fragmented_P=ranksum(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(~isnan(All_Large_Deep_Per_NPCell_Firing_Across_Fragmented_Ripples(:,8)),8),All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(~isnan(All_Large_Superficial_Per_NPCell_Firing_Across_Frag_Ripples(:,8)),8))*3


cd ..
cd ..




end