function DSRP_COMPARE_PLACE_FIELD_PROPERTIES(Initial_Variables)

%==========================================================================
% This function pulls up the quantified deep and superficial neurons and
% their associated linear track place fields and performs comparative
% analyses on the properties of those place fields
%==========================================================================

% Deep/Superficial_Place_Field_Properties (Large_Deep/Large_Superficial are for neurons with large spikes that are closer to the deep/superficial recording sites) 
% |              1               |              2         |        3         |         4        |              5              |            6              |        7       |
% | Mean Place Field Size (bins) | Number Of Place Fields | Peak Firing Rate | Mean Firing Rate | Informaton Per Spike (bits) | Mean In-Field Firing Rate | Bursting Index |

load Position_Data;
load('Epochs','Run_Times')
Position_Data(:,5)=DSRP_CALCULATE_VELOCITY(Position_Data);
Position_Data(2:end,6)=diff(Position_Data(:,1));
Position_Data(1,6)=Position_Data(2,6);
Position_Data(Position_Data(:,6)>60,6)=0; %This makes the program not count large gaps (such as between multiple sessions in the same recording) as counting toward the total experiment duration
Run_Position_Data=Position_Data(1,:);
for N=1:size(Run_Times)
    Run_Position_Data=[Run_Position_Data;Position_Data(Position_Data(:,1)>=Run_Times(N,1) & Position_Data(:,2)<=Run_Times(N,2),:)];
end
Position_Data=Run_Position_Data(2:end,:);
clear Run_Position_Data
load Field_Data;
load Spike_Data_Integrated_With_Position
load Deep_And_Superficial_Cell_Identities

if 1%~isfile('Place_Field_Properties.mat')
    Total_Duration=sum(Position_Data(Position_Data(:,5)>=Initial_Variables.Velocity_Cutoff,6));
    Time_In_Position=zeros(size(Field_Data,1),size(Field_Data,2));
    for N=1:size(Position_Data,1)
        if Position_Data(N,5)>=Initial_Variables.Velocity_Cutoff
            Time_In_Position(ceil(Position_Data(N,3)/Initial_Variables.Bin_Size),ceil(Position_Data(N,2)/Initial_Variables.Bin_Size))=Time_In_Position(ceil(Position_Data(N,3)/Initial_Variables.Bin_Size),ceil(Position_Data(N,2)/Initial_Variables.Bin_Size))+Position_Data(N,6);
        end
    end
    clear N;
    Normalized_Time_In_Position=Time_In_Position/sum(sum(Time_In_Position));
    for N=1:length(Excitatory_Neurons)
        Place_Field=Field_Data(:,:,Excitatory_Neurons(N));
        if max(max(Place_Field))>0
            Peak_Firing_Rate=max(max(Place_Field));
            Mean_Firing_Rate=length(find(Spike_Data(:,2)==Excitatory_Neurons(N) & Spike_Data(:,6)>=Initial_Variables.Velocity_Cutoff))/Total_Duration;
            Information_Field=Normalized_Time_In_Position.*(Place_Field/Mean_Firing_Rate).*log2((Place_Field/Mean_Firing_Rate));
            Information_Field=Information_Field(Normalized_Time_In_Position>0); %Limit analysis only to parts of the track where the rat explored
            Information_Field(isnan(Information_Field))=0;
            Information_Per_Spike=sum(sum(Information_Field));
            Number_Of_Fields=0;
            Contiguous_Place_Fields=zeros(size(Place_Field,1),size(Place_Field,2));
            Place_Field=double(Place_Field>=Peak_Firing_Rate*Initial_Variables.Minimum_Place_Field_Firing_Rate_Fraction);
            Place_Field_Sizes=0;
            [Y_Index,X_Index]=find(Place_Field==1);
            for M=1:length(Y_Index)
                if Contiguous_Place_Fields(Y_Index(M),X_Index(M))==0 && Place_Field(Y_Index(M),X_Index(M))==1
                    This_Place_Field=grayconnected(Place_Field,Y_Index(M),X_Index(M),0);
                    if sum(sum(This_Place_Field))>=Initial_Variables.Minimum_Contiguous_Place_Field_Bins
                        Number_Of_Fields=Number_Of_Fields+1;
                        Contiguous_Place_Fields(This_Place_Field)=Number_Of_Fields;
                        Place_Field_Sizes=[Place_Field_Sizes;sum(sum(This_Place_Field))];
                    end
                end
                clear This_Place_Field;
            end
            [Y,X]=find(Contiguous_Place_Fields>0);
            Mean_InField_Firing_Rate=mean(mean(Field_Data(Y,X,Excitatory_Neurons(N))));
            clear M;
            clear X;
            clear Y;
            clear X_Index;
            clear Y_Index;
            if length(Place_Field_Sizes)>1
                Place_Field_Sizes=Place_Field_Sizes(2:end);
            end
            %Might still need to quantify place fields for place field size and place field number

            Current_Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Excitatory_Neurons(N) & Spike_Data(:,6)>=Initial_Variables.Velocity_Cutoff,:);
            Number_Of_Spikes=size(Current_Cell_Spike_Data,1);
            Closest_Interspike_Intervals=zeros(size(Current_Cell_Spike_Data,1),1);
            if Number_Of_Spikes>2
                Closest_Interspike_Intervals(1,1)=Current_Cell_Spike_Data(2,1)-Current_Cell_Spike_Data(1,1);
                Closest_Interspike_Intervals(end,1)=Current_Cell_Spike_Data(end,1)-Current_Cell_Spike_Data(end-1,1);
                for X=2:(size(Current_Cell_Spike_Data,1)-1)
                    Closest_Interspike_Intervals(X,1)=min([Current_Cell_Spike_Data(X,1)-Current_Cell_Spike_Data(X-1,1),Current_Cell_Spike_Data(X+1,1)-Current_Cell_Spike_Data(X,1)]);
                end
                Number_Of_Bursting_Spikes=sum(Closest_Interspike_Intervals(:,1)<=0.006);
                Bursting_Spike_Index=Number_Of_Bursting_Spikes/Number_Of_Spikes;
            else
                Bursting_Spike_Index=NaN;
            end

            if sum(Large_Deep_Cells==Excitatory_Neurons(N))>0
                if exist('Large_Deep_Place_Field_Properties','var')==1
                    Large_Deep_Place_Field_Properties=[Large_Deep_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index]];
                else
                    Large_Deep_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index];
                end
            elseif sum(Large_Superficial_Cells==Excitatory_Neurons(N))>0
                if exist('Large_Superficial_Place_Field_Properties','var')==1
                    Large_Superficial_Place_Field_Properties=[Large_Superficial_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index]];
                else
                    Large_Superficial_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index];
                end
            end
            if sum(Deep_Cells==Excitatory_Neurons(N))>0
                if exist('Deep_Place_Field_Properties','var')==1
                    Deep_Place_Field_Properties=[Deep_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index]];
                else
                    Deep_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index];
                end
            elseif sum(Superficial_Cells==Excitatory_Neurons(N))>0
                if exist('Superficial_Place_Field_Properties','var')==1
                    Superficial_Place_Field_Properties=[Superficial_Place_Field_Properties;[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index]];
                else
                    Superficial_Place_Field_Properties=[mean(Place_Field_Sizes),Number_Of_Fields,Peak_Firing_Rate,Mean_Firing_Rate,Information_Per_Spike,Mean_InField_Firing_Rate,Bursting_Spike_Index];
                end
            end
            clear L_Ratio
            clear Peak_Firing_Rate;
            clear Mean_Firing_Rate;
            clear Mean_InField_Firing_Rate;
            clear Information_Per_Spike;
            clear Information_Field;
            clear Place_Field_Size;
            clear Number_Of_Fields;
            clear Contiguous_Place_Fields;
            clear Place_Field_Sizes;
        end
        clear Place_Field;
    end
    clear Total_Duration;
    clear Time_In_Position;
    clear Normalized_Time_In_Position;
    clear N;
    save('Place_Field_Properties','Large_Deep_Place_Field_Properties','Large_Superficial_Place_Field_Properties','Deep_Place_Field_Properties','Superficial_Place_Field_Properties');
end


end
