function DSRP_CREATE_ON_TASK_BURSTINESS_VS_EMR_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot On-Task Burstiness Vs. Experience Modulation of Ripple Firing For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Cell_Analysis
load All_Firing_Properties_During_Behavior

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity')
    mkdir('Experience_Modulation_Of_SWR_Activity')
end
cd 'Experience_Modulation_Of_SWR_Activity'

if ~isfolder('Correlation_In_Burstiness_And_Ripple_Modulation')
    mkdir('Correlation_In_Burstiness_And_Ripple_Modulation')
end
cd('Correlation_In_Burstiness_And_Ripple_Modulation')

%--------------------------------------------------------------------------

%Participation for Large Cells for All Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_All(:,1)./All_Large_Deep_Per_Cell_Pre_All(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_All(:,1)./All_Large_Super_Per_Cell_Pre_All(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_All_Corr_R,Large_Deep_Participation_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_All_Corr_R,Large_Super_Participation_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_All_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_All_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_All_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_All_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%--------------------------------------------------------------------------

%Participation for Large Cells for Coherent Ripples

Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Coherent_Corr_R,Large_Deep_Participation_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Coherent_Corr_R,Large_Super_Participation_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_Coherent_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_Coherent_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%--------------------------------------------------------------------------

%Participation for Large Cells for Fragmented Ripples

Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Fragmented_Corr_R,Large_Deep_Participation_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Fragmented_Corr_R,Large_Super_Participation_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_Fragmented_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4


%--------------------------------------------------------------------------
%==========================================================================
%--------------------------------------------------------------------------

%Firing Rate for Large Cells for All Ripples

Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_All_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_All_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_All_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_All_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%--------------------------------------------------------------------------

%Firing Rate for Large Cells for Coherent Ripples

Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Coherent_Corr_R,Large_Deep_Firing_Rate_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Coherent_Corr_R,Large_Super_Firing_Rate_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_Coherent_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_Coherent_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%--------------------------------------------------------------------------

%Firing Rate for Large Cells for Fragmented Ripples

Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Fragmented_Corr_R,Large_Deep_Firing_Rate_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Fragmented_Corr_R,Large_Super_Firing_Rate_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_Fragmented_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

cd ..
cd ..
cd ..


end

