function DSRP_CREATE_PER_CELL_PARTICIPATION_EMR_PLOTS_ALL_CELLS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot Per Cell Experience-Modulation Index Box Plots
%
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Cell Participation (all cells, regardless of spike amplitude)
%
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
    mkdir('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
end
cd 'Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis'

if ~isfolder('All Cell Experience Modulation Index')
    mkdir('All Cell Experience Modulation Index')
end
cd('All Cell Experience Modulation Index')

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_All(:,1)./All_Deep_Per_Cell_Pre_All(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_All(:,1)./All_Super_Per_Cell_Pre_All(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Participation_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Coherent(:,1)./All_Deep_Per_Cell_Pre_Coherent(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Coherent(:,1)./All_Super_Per_Cell_Pre_Coherent(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Coherent_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Coherent_Participation_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Fragmented(:,1)./All_Deep_Per_Cell_Pre_Fragmented(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Fragmented(:,1)./All_Super_Per_Cell_Pre_Fragmented(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Fragmented_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Fragmented_Participation_P=signrank(Super_Index)*2

cd ..
cd ..
cd ..


end

