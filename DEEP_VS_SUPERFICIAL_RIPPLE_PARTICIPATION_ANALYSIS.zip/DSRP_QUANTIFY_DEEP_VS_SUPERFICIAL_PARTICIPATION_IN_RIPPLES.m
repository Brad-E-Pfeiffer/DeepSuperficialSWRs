function DSRP_QUANTIFY_DEEP_VS_SUPERFICIAL_PARTICIPATION_IN_RIPPLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and quantifies the percent of cells
% from deep vs. superficial tetrodes that participate as well as the number
% of spikes emitted from participating cells.  Only excitatory neurons are
% examined here.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Cell_Participation_Per_Ripple (Page 1 is percent cell participation, Page 2 is spikes per participating cell)
% |       1       |                   2-end                 ||
% | Ripple Number | Participation per cell for each tetrode ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Participation of Deep and Superficial Cells in Ripples for %s Day %d.'')',Rat_Name,Experiment)); 

        if ~isfile('Cell_Participation_Per_Ripple.mat')

            Spike_Amplitude_Cutoff=200;
            load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
            load('Combined_Ripple_LFP_Data','Combined_All_Ripple_LFP_Data');
            Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
            load('MUA_Spikes','MUA_Spikes')
            MUA_Spikes=MUA_Spikes(MUA_Spikes(:,3)==1,:);
            MUA_Spikes=sortrows(MUA_Spikes);
            MUA_Spikes(:,4)=0;
            for N=1:max(MUA_Spikes(:,2))
                MUA_Spikes(MUA_Spikes(:,2)==N,4)=Sharp_Wave_Deflection_Per_Tetrode(N);
            end
            load('Spike_Data','Tetrode_Cell_IDs','Spike_Data','Inhibitory_Neurons')
            for N=1:length(Inhibitory_Neurons)
                Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
            end
            load('Tetrode_Cell_Spike_Amplitudes','Tetrode_Cell_Spike_Amplitudes');
            % Spike_Data
            % |         1         |     2   |      3     |                 4                |            5            ||
            % | Time of Spike (s) | Cell ID | Tetrode ID | Sharp-wave Deflection of Tetrode | Largest Spike Amplitude ||
            Spike_Data(:,3:5)=0;
            for N=1:max(Spike_Data(:,2))
                Spike_Data(Spike_Data(:,2)==N,3)=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,2)==N,1);
                Spike_Data(Spike_Data(:,2)==N,4)=Sharp_Wave_Deflection_Per_Tetrode(Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,2)==N,1));
                Spike_Data(Spike_Data(:,2)==N,5)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==N,3);
            end
            Unique_Tetrodes=unique(Tetrode_Cell_IDs(:,1));
            Deep_Tetrodes=find(Sharp_Wave_Deflection_Per_Tetrode>50);
            Deep_Tetrodes(:,2)=0;
            for N=1:size(Deep_Tetrodes,1)
                if min(Combined_All_Ripple_LFP_Data(:,find(Unique_Tetrodes==Deep_Tetrodes(N))+1))>-150
                    Deep_Tetrodes(N,2)=1;
                end
            end
            Deep_Tetrodes=Deep_Tetrodes(Deep_Tetrodes(:,2)==1,1);
            Superficial_Tetrodes=find(Sharp_Wave_Deflection_Per_Tetrode<-50);
            Deep_Cells=0;
            for N=1:length(Deep_Tetrodes)
                Deep_Cells=[Deep_Cells;Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Deep_Tetrodes(N),2)];
            end
            Deep_Cells=Deep_Cells(2:end,:);
            for N=1:length(Inhibitory_Neurons)
                Deep_Cells=Deep_Cells(Deep_Cells~=Inhibitory_Neurons(N));
            end
            Large_Deep_Cells=[Deep_Cells,zeros(length(Deep_Cells),1)];
            for N=1:size(Large_Deep_Cells,1)
                Large_Deep_Cells(N,2)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==Large_Deep_Cells(N,1),3);
            end
            Large_Deep_Cells=Large_Deep_Cells(Large_Deep_Cells(:,2)>Spike_Amplitude_Cutoff,1);
            Superficial_Cells=0;
            for N=1:length(Superficial_Tetrodes)
                Superficial_Cells=[Superficial_Cells;Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Superficial_Tetrodes(N),2)];
            end
            Superficial_Cells=Superficial_Cells(2:end,:);
            for N=1:length(Inhibitory_Neurons)
                Superficial_Cells=Superficial_Cells(Superficial_Cells~=Inhibitory_Neurons(N));
            end
            Large_Superficial_Cells=[Superficial_Cells,zeros(length(Superficial_Cells),1)];
            for N=1:size(Large_Superficial_Cells,1)
                Large_Superficial_Cells(N,2)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==Large_Superficial_Cells(N,1),3);
            end
            Large_Superficial_Cells=Large_Superficial_Cells(Large_Superficial_Cells(:,2)>Spike_Amplitude_Cutoff,1);
            save('Deep_And_Superficial_Cell_Identities','Deep_Cells','Superficial_Cells','Large_Deep_Cells','Large_Superficial_Cells');

            load('Epochs','Run_Times','SWS_Times','Sleep_Box_Awake_Immobile_Times')
            load('Ripple_Events','Ripple_Events')
            Deep_Superficial_Ripple_Participation=zeros(size(Ripple_Events,1),6,2);
            % Deep_Superficial_Ripple_Participation (Page 1 is all cells/spikes; Page 2 is only using cells/spikes with large amplitude spikes (those closest to the recording site)
            % |                 1               |                  2                  |                3                   |                      4                     |                  5                 |                      6                     ||
            % | Mean Sharp Wave Depth of Spikes | Mean Sharp Wave Depth of MUA Spikes | Percent Particpation of Deep Cells | Percent Participation of Superficial Cells | Mean FR of Particpating Deep Cells | Mean FR of Participating Superficial Cells ||

            PreSleep_Ripples=Ripple_Events(Ripple_Events(:,2)<Run_Times(1,1),:);
            PreSleep_Deep_Superficial_Ripple_Participation=Deep_Superficial_Ripple_Participation(Ripple_Events(:,2)<Run_Times(1,1),:,:);
            Run_Ripples=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            Run_Deep_Superficial_Ripple_Participation=Deep_Superficial_Ripple_Participation(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
            if size(Run_Times,1)==1
                PostSleep_Ripples=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
                PostSleep_Deep_Superficial_Ripple_Participation=Deep_Superficial_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2),:,:);
            else
                PostSleep_Ripples=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:);
                PostSleep_Deep_Superficial_Ripple_Participation=Deep_Superficial_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:,:);
            end

            for Current_Ripple=1:size(PreSleep_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=PreSleep_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=PreSleep_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_MUA_Spike_Data=MUA_Spikes(MUA_Spikes(:,1)>=PreSleep_Ripples(Current_Ripple,1) & MUA_Spikes(:,1)<=PreSleep_Ripples(Current_Ripple,2),:);
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,1)=[mean(Ripple_Spike_Data(:,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,2)=[mean(Ripple_Spike_Data(Ripple_Spike_Data(:,5)>Spike_Amplitude_Cutoff,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Deep_Cells)
                        Ripple_Deep_Cell_Spikes=[Ripple_Deep_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Deep_Cells(N),:)];
                    end
                    Ripple_Deep_Cell_Spikes=Ripple_Deep_Cell_Spikes(2:end,:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Superficial_Cells)
                        Ripple_Superficial_Cell_Spikes=[Ripple_Superficial_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Superficial_Cells(N),:)];
                    end
                    Ripple_Superficial_Cell_Spikes=Ripple_Superficial_Cell_Spikes(2:end,:);
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,2)=[length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Superficial_Cells)];
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,2)=[(length(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                else
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,1)=NaN;
                    PreSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,2)=NaN;
                end
            end

            for Current_Ripple=1:size(Run_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=Run_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_MUA_Spike_Data=MUA_Spikes(MUA_Spikes(:,1)>=Run_Ripples(Current_Ripple,1) & MUA_Spikes(:,1)<=Run_Ripples(Current_Ripple,2),:);
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,1)=[mean(Ripple_Spike_Data(:,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,2)=[mean(Ripple_Spike_Data(Ripple_Spike_Data(:,5)>Spike_Amplitude_Cutoff,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Deep_Cells)
                        Ripple_Deep_Cell_Spikes=[Ripple_Deep_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Deep_Cells(N),:)];
                    end
                    Ripple_Deep_Cell_Spikes=Ripple_Deep_Cell_Spikes(2:end,:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Superficial_Cells)
                        Ripple_Superficial_Cell_Spikes=[Ripple_Superficial_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Superficial_Cells(N),:)];
                    end
                    Ripple_Superficial_Cell_Spikes=Ripple_Superficial_Cell_Spikes(2:end,:);
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,2)=[length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Superficial_Cells)];
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,2)=[(length(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                else
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,1)=NaN;
                    Run_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,2)=NaN;
                end
            end

            for Current_Ripple=1:size(PostSleep_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=PostSleep_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=PostSleep_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_MUA_Spike_Data=MUA_Spikes(MUA_Spikes(:,1)>=PostSleep_Ripples(Current_Ripple,1) & MUA_Spikes(:,1)<=PostSleep_Ripples(Current_Ripple,2),:);
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,1)=[mean(Ripple_Spike_Data(:,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:2,2)=[mean(Ripple_Spike_Data(Ripple_Spike_Data(:,5)>Spike_Amplitude_Cutoff,4),'omitnan'),mean(Ripple_MUA_Spike_Data(:,4),'omitnan')];
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Deep_Cells)
                        Ripple_Deep_Cell_Spikes=[Ripple_Deep_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Deep_Cells(N),:)];
                    end
                    Ripple_Deep_Cell_Spikes=Ripple_Deep_Cell_Spikes(2:end,:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(1,:);
                    for N=1:length(Superficial_Cells)
                        Ripple_Superficial_Cell_Spikes=[Ripple_Superficial_Cell_Spikes;Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Superficial_Cells(N),:)];
                    end
                    Ripple_Superficial_Cell_Spikes=Ripple_Superficial_Cell_Spikes(2:end,:);
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,3:4,2)=[length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2)))/length(Large_Superficial_Cells)];
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,5:6,2)=[(length(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Deep_Cell_Spikes(Ripple_Deep_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,1))/length(unique(Ripple_Superficial_Cell_Spikes(Ripple_Superficial_Cell_Spikes(:,5)>Spike_Amplitude_Cutoff,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                else
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,1)=NaN;
                    PostSleep_Deep_Superficial_Ripple_Participation(Current_Ripple,1:6,2)=NaN;
                end
            end

            save('Cell_Participation_Per_Ripple','PreSleep_Deep_Superficial_Ripple_Participation','Run_Deep_Superficial_Ripple_Participation','PostSleep_Deep_Superficial_Ripple_Participation')

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end
    
    clear Directory
    cd ..

end

clearvars -except Initial_Variables.

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load Cell_Participation_Per_Ripple

        Mean_PreSleep_Offset=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_MUA_PreSleep_Offset=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PreSleep_Deep_Participation=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PreSleep_Deep_Firing_Rate=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PreSleep_Superficial_Participation=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PreSleep_Superficial_Firing_Rate=[mean(PreSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(PreSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(PreSleep_Deep_Superficial_Ripple_Participation,1))];

        Mean_Run_Offset=[mean(Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];
        Mean_MUA_Run_Offset=[mean(Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];
        Mean_Run_Deep_Participation=[mean(Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];
        Mean_Run_Deep_Firing_Rate=[mean(Run_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];
        Mean_Run_Superficial_Participation=[mean(Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];
        Mean_Run_Superficial_Firing_Rate=[mean(Run_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(Run_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(Run_Deep_Superficial_Ripple_Participation,1))];

        Mean_PostSleep_Offset=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_MUA_PostSleep_Offset=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PostSleep_Deep_Participation=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PostSleep_Deep_Firing_Rate=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PostSleep_Superficial_Participation=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];
        Mean_PostSleep_Superficial_Firing_Rate=[mean(PostSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(PostSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(PostSleep_Deep_Superficial_Ripple_Participation,1))];

        if exist('All_Run_Deep_Superficial_Ripple_Participation','var')
            All_PreSleep_Deep_Superficial_Ripple_Participation=[All_PreSleep_Deep_Superficial_Ripple_Participation;PreSleep_Deep_Superficial_Ripple_Participation];
            All_Run_Deep_Superficial_Ripple_Participation=[All_Run_Deep_Superficial_Ripple_Participation;Run_Deep_Superficial_Ripple_Participation];
            All_PostSleep_Deep_Superficial_Ripple_Participation=[All_PostSleep_Deep_Superficial_Ripple_Participation;PostSleep_Deep_Superficial_Ripple_Participation];

            All_Mean_PreSleep_Offset=[All_Mean_PreSleep_Offset;Mean_PreSleep_Offset];
            All_Mean_MUA_PreSleep_Offset=[All_Mean_MUA_PreSleep_Offset;Mean_MUA_PreSleep_Offset];
            All_Mean_PreSleep_Deep_Participation=[All_Mean_PreSleep_Deep_Participation;Mean_PreSleep_Deep_Participation];
            All_Mean_PreSleep_Deep_Firing_Rate=[All_Mean_PreSleep_Deep_Firing_Rate;Mean_PreSleep_Deep_Firing_Rate];
            All_Mean_PreSleep_Superficial_Participation=[All_Mean_PreSleep_Superficial_Participation;Mean_PreSleep_Superficial_Participation];
            All_Mean_PreSleep_Superficial_Firing_Rate=[All_Mean_PreSleep_Superficial_Firing_Rate;Mean_PreSleep_Superficial_Firing_Rate];

            All_Mean_Run_Offset=[All_Mean_Run_Offset;Mean_Run_Offset];
            All_Mean_MUA_Run_Offset=[All_Mean_MUA_Run_Offset;Mean_MUA_Run_Offset];
            All_Mean_Run_Deep_Participation=[All_Mean_Run_Deep_Participation;Mean_Run_Deep_Participation];
            All_Mean_Run_Deep_Firing_Rate=[All_Mean_Run_Deep_Firing_Rate;Mean_Run_Deep_Firing_Rate];
            All_Mean_Run_Superficial_Participation=[All_Mean_Run_Superficial_Participation;Mean_Run_Superficial_Participation];
            All_Mean_Run_Superficial_Firing_Rate=[All_Mean_Run_Superficial_Firing_Rate;Mean_Run_Superficial_Firing_Rate];

            All_Mean_PostSleep_Offset=[All_Mean_PostSleep_Offset;Mean_PostSleep_Offset];
            All_Mean_MUA_PostSleep_Offset=[All_Mean_MUA_PostSleep_Offset;Mean_MUA_PostSleep_Offset];
            All_Mean_PostSleep_Deep_Participation=[All_Mean_PostSleep_Deep_Participation;Mean_PostSleep_Deep_Participation];
            All_Mean_PostSleep_Deep_Firing_Rate=[All_Mean_PostSleep_Deep_Firing_Rate;Mean_PostSleep_Deep_Firing_Rate];
            All_Mean_PostSleep_Superficial_Participation=[All_Mean_PostSleep_Superficial_Participation;Mean_PostSleep_Superficial_Participation];
            All_Mean_PostSleep_Superficial_Firing_Rate=[All_Mean_PostSleep_Superficial_Firing_Rate;Mean_PostSleep_Superficial_Firing_Rate];

        else
            All_PreSleep_Deep_Superficial_Ripple_Participation=PreSleep_Deep_Superficial_Ripple_Participation;
            All_Run_Deep_Superficial_Ripple_Participation=Run_Deep_Superficial_Ripple_Participation;
            All_PostSleep_Deep_Superficial_Ripple_Participation=PostSleep_Deep_Superficial_Ripple_Participation;

            All_Mean_PreSleep_Offset=Mean_PreSleep_Offset;
            All_Mean_MUA_PreSleep_Offset=Mean_MUA_PreSleep_Offset;
            All_Mean_PreSleep_Deep_Participation=Mean_PreSleep_Deep_Participation;
            All_Mean_PreSleep_Deep_Firing_Rate=Mean_PreSleep_Deep_Firing_Rate;
            All_Mean_PreSleep_Superficial_Participation=Mean_PreSleep_Superficial_Participation;
            All_Mean_PreSleep_Superficial_Firing_Rate=Mean_PreSleep_Superficial_Firing_Rate;

            All_Mean_Run_Offset=Mean_Run_Offset;
            All_Mean_MUA_Run_Offset=Mean_MUA_Run_Offset;
            All_Mean_Run_Deep_Participation=Mean_Run_Deep_Participation;
            All_Mean_Run_Deep_Firing_Rate=Mean_Run_Deep_Firing_Rate;
            All_Mean_Run_Superficial_Participation=Mean_Run_Superficial_Participation;
            All_Mean_Run_Superficial_Firing_Rate=Mean_Run_Superficial_Firing_Rate;

            All_Mean_PostSleep_Offset=Mean_PostSleep_Offset;
            All_Mean_MUA_PostSleep_Offset=Mean_MUA_PostSleep_Offset;
            All_Mean_PostSleep_Deep_Participation=Mean_PostSleep_Deep_Participation;
            All_Mean_PostSleep_Deep_Firing_Rate=Mean_PostSleep_Deep_Firing_Rate;
            All_Mean_PostSleep_Superficial_Participation=Mean_PostSleep_Superficial_Participation;
            All_Mean_PostSleep_Superficial_Firing_Rate=Mean_PostSleep_Superficial_Firing_Rate;

        end

        cd ..

    end

    clear Directory

    cd ..

end

Per_Ripple_Mean_PreSleep_Offset=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_MUA_PreSleep_Offset=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PreSleep_Deep_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PreSleep_Deep_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PreSleep_Superficial_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(All_PreSleep_Deep_Superficial_Ripple_Participation,1))];

Per_Ripple_Mean_Run_Offset=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_MUA_Run_Offset=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_Run_Deep_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_Run_Deep_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_Run_Superficial_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_Run_Superficial_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(All_Run_Deep_Superficial_Ripple_Participation,1))];

Per_Ripple_Mean_PostSleep_Offset=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_MUA_PostSleep_Offset=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PostSleep_Deep_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PostSleep_Deep_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PostSleep_Superficial_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];
Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2),'omitnan')/sqrt(size(All_PostSleep_Deep_Superficial_Ripple_Participation,1))];

if isfolder('AllRatsCombined')
    cd AllRatsCombined
else
    mkdir('AllRatsCombined')
    cd AllRatsCombined
end

save('All_Cell_Participation_Per_Ripple')

cd ..

if isfolder('_Figures')
    cd _Figures
else
    mkdir('_Figures')
    cd _Figures
end

%Plot the cell participation of deep vs. superficial neurons when averaged across all ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Ripple_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Mean_PostSleep_Deep_Participation(1)],[Per_Ripple_Mean_PreSleep_Deep_Participation(2),Per_Ripple_Mean_PostSleep_Deep_Participation(2)]);
errorbar(1:2,[Per_Ripple_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Mean_PostSleep_Superficial_Participation(1)],[Per_Ripple_Mean_PreSleep_Superficial_Participation(2),Per_Ripple_Mean_PostSleep_Superficial_Participation(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar(1:5,[Per_Ripple_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Mean_PreSleep_Superficial_Participation(1),0,Per_Ripple_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Mean_PostSleep_Superficial_Participation(1)],'k');
plot([1,1],[Per_Ripple_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Mean_PreSleep_Deep_Participation(1)-Per_Ripple_Mean_PreSleep_Deep_Participation(2)],'w','LineWidth',3);
plot([1,1],[Per_Ripple_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Mean_PreSleep_Deep_Participation(1)+Per_Ripple_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Mean_PreSleep_Superficial_Participation(1)-Per_Ripple_Mean_PreSleep_Superficial_Participation(2)],'w','LineWidth',3);
plot([2,2],[Per_Ripple_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Mean_PreSleep_Superficial_Participation(1)+Per_Ripple_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Mean_PostSleep_Deep_Participation(1)-Per_Ripple_Mean_PostSleep_Deep_Participation(2)],'w','LineWidth',3);
plot([4,4],[Per_Ripple_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Mean_PostSleep_Deep_Participation(1)+Per_Ripple_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Mean_PostSleep_Superficial_Participation(1),Per_Ripple_Mean_PostSleep_Superficial_Participation(1)-Per_Ripple_Mean_PostSleep_Superficial_Participation(2)],'w','LineWidth',3);
plot([5,5],[Per_Ripple_Mean_PostSleep_Superficial_Participation(1),Per_Ripple_Mean_PostSleep_Superficial_Participation(1)+Per_Ripple_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close



ANOVA_Matrix=[[All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*3,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*4,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
figure;C1=multcompare(Stats,"Dimension",[1,2]);

%Plot the participating cell firing rate of deep vs. superficial neurons when averaged across all ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1)],[Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(2),Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(2)]);
errorbar(1:2,[Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1)],[Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(2),Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
bar(1:5,[Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1),0,Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1)],'k');
plot([1,1],[Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1)-Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(2)],'w','LineWidth',3);
plot([1,1],[Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(1)+Per_Ripple_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1)-Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(2)],'w','LineWidth',3);
plot([2,2],[Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(1)+Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1)-Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(2)],'w','LineWidth',3);
plot([4,4],[Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(1)+Per_Ripple_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1)-Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(2)],'w','LineWidth',3);
plot([5,5],[Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(1)+Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Firing_Rate_Of_Participating_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=9to13.5).jpg')
close

ANOVA_Matrix=[[All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*1];[All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*2,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*2];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*3,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,5,2)),1)*1];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*4,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,6,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
figure;C1=multcompare(Stats,"Dimension",[1,2]);




end



