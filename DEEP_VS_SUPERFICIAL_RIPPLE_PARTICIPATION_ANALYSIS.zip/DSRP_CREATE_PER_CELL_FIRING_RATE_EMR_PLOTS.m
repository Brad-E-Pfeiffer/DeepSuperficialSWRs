function DSRP_CREATE_PER_CELL_FIRING_RATE_EMR_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot Per Cell Experience-Modulation Index Box Plots
%
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Large Cell Firing Rate (Only for Participating Cells)
%
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
    mkdir('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
end
cd 'Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis'

if ~isfolder('Large Cell Experience Modulation Index')
    mkdir('Large Cell Experience Modulation Index')
end
cd('Large Cell Experience Modulation Index')

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_FR_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Coherent_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Coherent_FR_P=signrank(Super_Index)*2

% Plot for only incoherent ripples (all non-replay SWRs, not just "fragmented")  
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Incoherent(:,3)./All_Large_Deep_Per_Cell_Pre_Incoherent(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Incoherent(:,3)./All_Large_Super_Per_Cell_Pre_Incoherent(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Incoherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Incoherent_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Incoherent_FR_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3));
%Deep_Index=(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)-All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))./(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)+All_Large_Deep_Per_Cell_Pre_Fragmented(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3));
%Super_Index=(All_Large_Super_Per_Cell_Post_Fragmented(:,3)-All_Large_Super_Per_Cell_Pre_Fragmented(:,3))./(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)+All_Large_Super_Per_Cell_Pre_Fragmented(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Fragmented_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Fragmented_FR_P=signrank(Super_Index)*2

% Plot for non SWS periods 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Non_SWS(:,2)./All_Large_Deep_Non_SWS(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Non_SWS(:,2)./All_Large_Super_Non_SWS(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Outside_Of_SWRs(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Non_SWRs_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Non_SWRs_FR_P=signrank(Super_Index)*2

cd ..
cd ..
cd ..


end

