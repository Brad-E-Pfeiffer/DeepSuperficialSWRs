function DSRP_CREATE_PER_SESSION_PARTICIPATION_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
% 
% Plot Per-Session Averages for All Cells
% 
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Cell Participation
%
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
    mkdir('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
end
cd 'Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis'


if ~isfolder('Per_Session')
    mkdir('Per_Session')
end
cd Per_Session

% Plot for all ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participation_Fraction_P,Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))
[Per_Session_Superficial_Participation_Fraction_P,Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))


% Plot for only coherent ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participation_Fraction_P,Coherent_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))
[Coherent_Per_Session_Superficial_Participation_Fraction_P,Coherent_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))


% Plot for only incoherent ripples (all non-replay-encoding SWRs, not only "fragmented" SWRs) 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction_In_Incoherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Incoherent_Per_Session_Deep_Participation_Fraction_P,Incoherent_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,1))
[Incoherent_Per_Session_Superficial_Participation_Fraction_P,Incoherent_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,1))


% Plot for only fragmented ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participation_Fraction_P,Fragmented_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))
[Fragmented_Per_Session_Superficial_Participation_Fraction_P,Fragmented_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))

cd ..
cd ..
cd ..


end

