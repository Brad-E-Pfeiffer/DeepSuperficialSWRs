function DSRP_PROCESS_RAW_DATA(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function processes the raw data (raw spikes, raw position, raw LFP)
% and calculates several analysis-critical variables, like place fields,
% ripple times, sleep/wake times, etc.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if ~isfile('Completed_Process_Raw_Data.mat')
                       
            disp('==========================================================================');
            disp(sprintf('Starting Analysis for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            
            disp('Loading Raw Spike and Position Data.');
            DSRP_LOAD_RAW_SPIKE_AND_POSITION_DATA
            % Position_Data
            %|    1     |          2      |         3       |                  4                      ||
            %| Time (s) | X-Position (cm) | Y-Position (cm) |  Head Direction (deg) for open fields   ||
            %|          |                 |                 |                 or                      || 
            %|          |                 |                 | Linear Location (bin) for linear tracks || 
            
            % Spike_Data
            %|     1    |     2   ||
            %| Time (s) | Cell ID ||
            
            disp('Finding Amplitude Of Action Potentials For Each Cell.')
            DSRP_QUANTIFY_SPIKE_AMPLITUDE_PER_CELL(Initial_Variables,Rat,Experiment)
            
            disp('Finding REM And SWS Epochs Within Sleep Sessions.')
            DSRP_FIND_REM_AND_SWS_EPOCHS(Initial_Variables,Rat,Experiment);
            
            disp('Finding Ripples.')
            % Ripple_Events
            % |     1      |    2     |     3     |        4       |              5             |                    6                     |
            % | Start Time | End Time | Peak Time | Peak Raw Power | Peak Global Z-Scored Power | Peak Z-Scored Power From That Epoch Only |
            if ~isfile('Ripple_Events.mat')
                DSRP_FIND_RIPPLE_EVENTS(Initial_Variables,Rat,Experiment);
            end
            
            % Integrate the spike data and position data to find where the rat was when
            % each spike was fired.
            % Spike_Data
            % |    1     |     2   |         3        |         4        |                 5                   |         6       || 
            % | Time (s) | Cell ID | X Position (bin) | Y Position (bin) |   Head Direction (for open field)   | Velocity (cm/s) ||
            % |          |         |                  |                  |                 or                  |                 ||
            % |          |         |                  |                  | Linear Track Bin (for linear track) |                 || 
            if ~isfile('Spike_Data_Integrated_With_Position.mat')
                disp('Integrating Spike and Position Data.');
                DSRP_SPIKE_POSITION_INTEGRATION(Initial_Variables);
            end
            
            if ~isfile('Field_Data.mat')
                disp('Calculating Place Fields.');
                DSRP_CALCULATE_PLACE_FIELDS(Initial_Variables);
            end
            
            disp('Calculating Mean Decoding Error During Behavior.')
            if ~isfile('Position_Decoding_Error.mat')
                DSRP_CALCULATE_DECODING_ERROR(Initial_Variables);
            end

            disp('Calculating Mean Ripple Power and Sharp-Wave Deflections Across Each Tetrode.')
            DSRP_CALCULATE_SHARP_WAVE_DEFLECTIONS(Initial_Variables,Rat,Experiment);
            
            Completed_Process_Raw_Data=1;
            save('Completed_Process_Raw_Data','Completed_Process_Raw_Data');
            
            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name
            
        end
            
        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables

DSRP_PLOT_DEPTH_MEASUREMENTS;

end

