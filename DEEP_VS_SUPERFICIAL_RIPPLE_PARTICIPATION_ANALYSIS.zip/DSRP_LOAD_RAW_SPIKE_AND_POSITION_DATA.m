%load L_Ratios
load Position_Data
Position_Data(:,2)=Position_Data(:,2)-min(Position_Data(:,2))+0.001;
Position_Data(:,3)=Position_Data(:,3)-min(Position_Data(:,3))+0.001;
save('Position_Data','Position_Data');
load Spike_Data
load Epochs
