function DSRP_CALCULATE_GAMMA_PHASE_OFFSETS(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function looks at the LFP for every electrode and calculates the
% mean phase offset for the slow gamma oscillation.  It first analyzes this
% during active movement periods during the behavior.  Then it analyses
% during ripples
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Spike_Data','Tetrode_Cell_IDs')
load('Ripple_Events','Ripple_Events')
load('Epochs','Run_Times')
load('Position_Data','Position_Data')
load('Experiment_Information','Left_Tetrodes','Right_Tetrodes')
Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;

if ~isfile('Slow_Gamma_Phase_Offset_Per_Tetrode.mat')
    disp('Calculating Slow Gamma Phase Offsets For Each Electrode.')
    if Rat==1
        if Experiment==1
            Left_Reference_Tetrode=9;
            Right_Reference_Tetrode=38;
            Left_Reference_Electrode=36; %Tetrode 9; This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Electrode=149; %Tetrode 38; This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            Left_Reference_Tetrode=9;
            Right_Reference_Tetrode=39;
            Left_Reference_Electrode=36; %Tetrode 9; This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Electrode=153; %Tetrode 39; This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            Left_Reference_Tetrode=9;
            Right_Reference_Tetrode=35;
            Left_Reference_Electrode=36; %Tetrode 9; This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Electrode=137; %Tetrode 35; This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            Left_Reference_Tetrode=9;
            Right_Reference_Tetrode=27;
            Left_Reference_Electrode=36; %Tetrode 9; This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Electrode=105; %Tetrode 27; This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            Left_Reference_Tetrode=8;
            Right_Reference_Tetrode=34;
            Left_Reference_Electrode=30; %Tetrode 8.  This is a tetrode very likely located in the superficial sublayer across all recordings
            Right_Reference_Electrode=133; %Tetrode 34.  This is a tetrode very likely located in the superficial sublayer across all recordings
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            Left_Reference_Tetrode=8;
            Right_Reference_Tetrode=34;
            Left_Reference_Electrode=30; %Tetrode 8.  This is a tetrode very likely located in the superficial sublayer across all recordings
            Right_Reference_Electrode=133; %Tetrode 34.  This is a tetrode very likely located in the superficial sublayer across all recordings
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            Left_Reference_Tetrode=8;
            Right_Reference_Tetrode=34;
            Left_Reference_Electrode=30; %Tetrode 8.  This is a tetrode very likely located in the superficial sublayer across all recordings
            Right_Reference_Electrode=133; %Tetrode 34.  This is a tetrode very likely located in the superficial sublayer across all recordings
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            Left_Reference_Tetrode=8;
            Right_Reference_Tetrode=34;
            Left_Reference_Electrode=30; %Tetrode 8.  This is a tetrode very likely located in the superficial sublayer across all recordings
            Right_Reference_Electrode=133; %Tetrode 34.  This is a tetrode very likely located in the superficial sublayer across all recordings
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            Left_Reference_Tetrode=16;
            Left_Reference_Electrode=61; %Tetrode 16.  This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Tetrode=32;
            Right_Reference_Electrode=126; %Tetrode 32.  This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            Left_Reference_Tetrode=16;
            Left_Reference_Electrode=61; %Tetrode 16.  This is a tetrode very likely located in the superficial sublayer
            Right_Reference_Tetrode=27;
            Right_Reference_Electrode=105; %Tetrode 27.  This is a tetrode very likely located in the superficial sublayer
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    Directory_List=dir;
    for N=1:size(Directory_List,1)
        for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if there are more channels, increase this number accordingly
            Comparison_String=sprintf('CSC%d.ncs',M);
            if strcmp(Directory_List(N).name,Comparison_String)
                if exist('LFP_Electrodes','var')
                    LFP_Electrodes=[LFP_Electrodes,M];
                else
                    LFP_Electrodes=M;
                end
            end
            clear Comparison_String;
        end
    end
    if ~exist('LFP_Electrodes','var')
        error('ERROR! No CSC files were identified in the listed load directory.')
    end
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
    clear M;
    clear N;
    clear Directory_List;
    clear LFP_Electrodes;
    clear LFP_Filename;
    
    Ripple_Stop_Low=130;
    Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
    Ripple_Pass_High=250;
    Ripple_Stop_High=275;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    
    Slow_Gamma_Stop_Low=20;
    Slow_Gamma_Pass_Low=25;                % 25 Hz as the low cutoff
    Slow_Gamma_Pass_High=50;               % 50 Hz as the high cutoff
    Slow_Gamma_Stop_High=55;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Slow_Gamma=fdesign.bandpass(Slow_Gamma_Stop_Low,Slow_Gamma_Pass_Low,Slow_Gamma_Pass_High,Slow_Gamma_Stop_High,Stop_Band_Attenuation_One,Pass_Band,Stop_Band_Attenuation_Two,LFP_Frequency);
    Slow_Gamma_Filter=design(Filter_Design_For_Slow_Gamma,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    Tetrode_List=[];
    
    for Current_Tetrode=1:40
        for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
            Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
            if isfile(Electrode_Name)
                Tetrode_List=[Tetrode_List;Current_Tetrode];
                LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                for Header_Line=1:length(LFP_Header)
                    Header_Info=cell2mat(LFP_Header(Header_Line));
                    if length(Header_Info)>12
                        if strcmp(Header_Info(1:11),'-ADMaxValue')
                            Max_Value=str2num(Header_Info(13:end));
                        end
                        if strcmp(Header_Info(1:11),'-InputRange')
                            Max_Range=str2num(Header_Info(13:end));
                        end
                    end
                end
                LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                Times=zeros(512,size(LFP_Times,2));
                for B=1:length(LFP_Times)-1
                    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                end
                Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                clear B;
                clear LFP_Times;
                Times=Times(:);
                LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                LFP_Samples=LFP_Samples(:)*-(Max_Range/Max_Value);  %Multiply by -1 because the raw LFP was recorded inverted
                LFP_Data=[Times,LFP_Samples];
                clear Times;
                clear LFP_Samples;
                clear Max_Value;
                
                %The program analyzes only the first behavior portion of the experiment.
                Run_LFP_Data=LFP_Data(LFP_Data(:,1)>=Run_Times(1,1) & LFP_Data(:,1)<=Run_Times(1,2),:);
                
                Slow_Gamma_Filtered_Run_LFP_Data=zeros(size(Run_LFP_Data,1),4);
                Slow_Gamma_Filtered_Run_LFP_Data(:,1)=Run_LFP_Data(:,1);
                Slow_Gamma_Filtered_Run_LFP_Data(:,2)=filter(Slow_Gamma_Filter,Run_LFP_Data(:,2));
                Slow_Gamma_Filtered_Run_LFP_Data(:,2)=Slow_Gamma_Filtered_Run_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                Slow_Gamma_Filtered_Run_LFP_Data(:,2)=filter(Slow_Gamma_Filter,Slow_Gamma_Filtered_Run_LFP_Data(:,2));
                Slow_Gamma_Filtered_Run_LFP_Data(:,2)=Slow_Gamma_Filtered_Run_LFP_Data(end:-1:1,2);
                Slow_Gamma_Filtered_Run_LFP_Data(:,3)=hilbert(Slow_Gamma_Filtered_Run_LFP_Data(:,2));
                Slow_Gamma_Filtered_Run_LFP_Data(:,4)=(angle(Slow_Gamma_Filtered_Run_LFP_Data(:,3))*180/pi); %Add 180 because the raw data is inverted.
                Slow_Gamma_Filtered_Run_LFP_Data(Slow_Gamma_Filtered_Run_LFP_Data(:,4)<=0,4)=Slow_Gamma_Filtered_Run_LFP_Data(Slow_Gamma_Filtered_Run_LFP_Data(:,4)<=0,4)+360;
                
                Ripple_Filtered_LFP_Data=zeros(size(Run_LFP_Data,1),4);
                Ripple_Filtered_LFP_Data(:,1)=Run_LFP_Data(:,1);
                Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Run_LFP_Data(:,2));
                Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
                Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
                Ripple_Filtered_LFP_Data(:,3)=abs(hilbert(Ripple_Filtered_LFP_Data(:,2)));

                RI_Slow_Gamma_Filtered_LFP_Data=zeros(size(Ripple_Filtered_LFP_Data,1),5);
                RI_Slow_Gamma_Filtered_LFP_Data(:,1)=Ripple_Filtered_LFP_Data(:,1);
                RI_Slow_Gamma_Filtered_LFP_Data(:,2)=filter(Slow_Gamma_Filter,Ripple_Filtered_LFP_Data(:,3));
                RI_Slow_Gamma_Filtered_LFP_Data(:,2)=RI_Slow_Gamma_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                RI_Slow_Gamma_Filtered_LFP_Data(:,2)=filter(Slow_Gamma_Filter,RI_Slow_Gamma_Filtered_LFP_Data(:,2));
                RI_Slow_Gamma_Filtered_LFP_Data(:,2)=RI_Slow_Gamma_Filtered_LFP_Data(end:-1:1,2);
                RI_Slow_Gamma_Filtered_LFP_Data(:,3)=hilbert(RI_Slow_Gamma_Filtered_LFP_Data(:,2));
                RI_Slow_Gamma_Filtered_LFP_Data(:,4)=(angle(RI_Slow_Gamma_Filtered_LFP_Data(:,3))*180/pi);
                RI_Slow_Gamma_Filtered_LFP_Data(RI_Slow_Gamma_Filtered_LFP_Data(:,4)<=0,4)=RI_Slow_Gamma_Filtered_LFP_Data(RI_Slow_Gamma_Filtered_LFP_Data(:,4)<=0,4)+360;
                clear Ripple_Filtered_LFP_Data;

                %This combines the phase values of the LFP
                if ~exist('Combined_Slow_Gamma_Run_LFP_Data','var')
                    Combined_Slow_Gamma_Run_LFP_Data=Slow_Gamma_Filtered_Run_LFP_Data(:,1);
                    Combined_RI_Slow_Gamma_Run_LFP_Data=RI_Slow_Gamma_Filtered_LFP_Data(:,1);
                end
                Combined_Slow_Gamma_Run_LFP_Data(:,end+1)=NaN;
                Integration_Index=round(interp1(Slow_Gamma_Filtered_Run_LFP_Data(:,1),1:size(Slow_Gamma_Filtered_Run_LFP_Data,1),Combined_Slow_Gamma_Run_LFP_Data(:,1),'nearest'));
                Integration_Index(Integration_Index==0)=1;
                Integration_Index(Integration_Index>size(Slow_Gamma_Filtered_Run_LFP_Data,1))=size(Slow_Gamma_Filtered_Run_LFP_Data,1);
                Combined_Slow_Gamma_Run_LFP_Data(~isnan(Integration_Index),end)=Slow_Gamma_Filtered_Run_LFP_Data(Integration_Index(~isnan(Integration_Index)),4);
                Combined_Slow_Gamma_Run_LFP_Data(isnan(Integration_Index),end)=NaN;
                Combined_RI_Slow_Gamma_Run_LFP_Data(:,end+1)=NaN;
                Integration_Index=round(interp1(RI_Slow_Gamma_Filtered_LFP_Data(:,1),1:size(RI_Slow_Gamma_Filtered_LFP_Data,1),Combined_RI_Slow_Gamma_Run_LFP_Data(:,1),'nearest'));
                Integration_Index(Integration_Index==0)=1;
                Integration_Index(Integration_Index>size(RI_Slow_Gamma_Filtered_LFP_Data,1))=size(RI_Slow_Gamma_Filtered_LFP_Data,1);
                Combined_RI_Slow_Gamma_Run_LFP_Data(~isnan(Integration_Index),end)=RI_Slow_Gamma_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),4);
                Combined_RI_Slow_Gamma_Run_LFP_Data(isnan(Integration_Index),end)=NaN;
                clear Integration_Index;
                clear RI_Slow_Gamma_Filtered_LFP_Data;
                clear Slow_Gamma_Filtered_Run_LFP_Data;
            end
        end
        disp(sprintf('Finished quantifying local slow gamma for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    cd(Current_Working_Directory);
    
    % Slow_Gamma_Phase_Offset_Per_Tetrode
    % |                           1                       |                        2                |                               3                       |                        4                    |                                5                           |      6     ||
    % | Offset From Local Hemisphere Reference During Run | Offset From Global Reference During Run | Offset From Local Hemisphere Reference During Ripples | Offset From Global Reference During Ripples | Ripple-Induced Offset From Global Reference During Ripples | Tetrode ID ||
    Slow_Gamma_Phase_Offset_Per_Tetrode=zeros(40,6);

    %This finds the slow-gamma data during ripples
    Combined_Slow_Gamma_Ripple_LFP_Data=Combined_Slow_Gamma_Run_LFP_Data(1,:);
    Combined_RI_Slow_Gamma_Ripple_LFP_Data=Combined_RI_Slow_Gamma_Run_LFP_Data(1,:);
    for Current_Ripple=1:size(Ripple_Events,1)
        Combined_Slow_Gamma_Ripple_LFP_Data=[Combined_Slow_Gamma_Ripple_LFP_Data;Combined_Slow_Gamma_Run_LFP_Data(Combined_Slow_Gamma_Run_LFP_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Combined_Slow_Gamma_Run_LFP_Data(:,1)<=Ripple_Events(Current_Ripple,2),:)];
        Combined_RI_Slow_Gamma_Ripple_LFP_Data=[Combined_RI_Slow_Gamma_Ripple_LFP_Data;Combined_RI_Slow_Gamma_Run_LFP_Data(Combined_RI_Slow_Gamma_Run_LFP_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Combined_RI_Slow_Gamma_Run_LFP_Data(:,1)<=Ripple_Events(Current_Ripple,2),:)];
    end
    Combined_Slow_Gamma_Ripple_LFP_Data=Combined_Slow_Gamma_Ripple_LFP_Data(2:end,:);
    Combined_RI_Slow_Gamma_Ripple_LFP_Data=Combined_RI_Slow_Gamma_Ripple_LFP_Data(2:end,:);
    
    %This finds the velocity at each time of the LFP
    Position_Data=Position_Data(Position_Data(:,1)>=Run_Times(1,1) & Position_Data(:,1)<=Run_Times(1,2),:);
    Velocity=[Position_Data(:,1),SGC_CALCULATE_VELOCITY(Position_Data)];
    
    %This combines the phase values of the LFP
    Velocity_Per_LFP_Time=zeros(size(Combined_Slow_Gamma_Run_LFP_Data,1),1);
    Velocity_Per_LFP_Time(:,:)=NaN;
    Integration_Index=round(interp1(Velocity(:,1),1:size(Velocity,1),Combined_Slow_Gamma_Run_LFP_Data(:,1),'nearest'));
    Integration_Index(Integration_Index==0)=1;
    Integration_Index(Integration_Index>size(Velocity,1))=size(Velocity,1);
    Velocity_Per_LFP_Time(~isnan(Integration_Index),:)=Velocity(Integration_Index(~isnan(Integration_Index)),2);
    Velocity_Per_LFP_Time(isnan(Integration_Index),2)=NaN;
    clear Integration_Index;
    
    Running_Combined_Slow_Gamma_LFP_Data=Combined_Slow_Gamma_Run_LFP_Data(Velocity_Per_LFP_Time(:,1)>=10,:);
    
    for Current_Tetrode=1:(size(Running_Combined_Slow_Gamma_LFP_Data,2)-1)
        if sum(Left_Tetrodes==Current_Tetrode)==1
            Reference_Index=Left_Reference_Tetrode;
        else
            Reference_Index=Right_Reference_Tetrode;
        end
        Slow_Gamma_Phase_Offset_Per_Tetrode(Tetrode_List(Current_Tetrode),:)=[circ_rad2ang(circ_mean(circ_ang2rad(Running_Combined_Slow_Gamma_LFP_Data(:,(Current_Tetrode+1))-Running_Combined_Slow_Gamma_LFP_Data(:,Reference_Index+1)))),circ_rad2ang(circ_mean(circ_ang2rad(Running_Combined_Slow_Gamma_LFP_Data(:,(Current_Tetrode+1))-Running_Combined_Slow_Gamma_LFP_Data(:,Left_Reference_Tetrode+1)))),circ_rad2ang(circ_mean(circ_ang2rad(Combined_Slow_Gamma_Ripple_LFP_Data(:,(Current_Tetrode+1))-Combined_Slow_Gamma_Ripple_LFP_Data(:,Reference_Index+1)))),circ_rad2ang(circ_mean(circ_ang2rad(Combined_Slow_Gamma_Ripple_LFP_Data(:,(Current_Tetrode+1))-Combined_Slow_Gamma_Ripple_LFP_Data(:,Left_Reference_Tetrode+1)))),circ_rad2ang(circ_mean(circ_ang2rad(Combined_RI_Slow_Gamma_Ripple_LFP_Data(:,(Current_Tetrode+1))-Combined_RI_Slow_Gamma_Ripple_LFP_Data(:,Left_Reference_Tetrode+1)))),Current_Tetrode];
    end
    Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,1)<0,1)=Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,1)<0,1)+360;
    Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,2)<0,2)=Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,2)<0,2)+360;
    clear Raw_LFP_Directory;
    clear Current_Directory;
    save('Slow_Gamma_Phase_Offset_Per_Tetrode','Slow_Gamma_Phase_Offset_Per_Tetrode');
    
    if 0
        if ~isfolder('Slow_Gamma_Phase_Offset_Analysis')
            mkdir('Slow_Gamma_Phase_Offset_Analysis')
            cd('Slow_Gamma_Phase_Offset_Analysis')
        else
            cd('Slow_Gamma_Phase_Offset_Analysis')
        end
        save('Combined_Slow_Gamma_Run_LFP_Data','Combined_Slow_Gamma_Run_LFP_Data','-v7.3');
        for N=1:length(Left_Tetrodes)
            figure;
            hold on;
            subplot('Position',[0 0 1 1]);
            hold on;
            Reference_Data=Combined_Slow_Gamma_Run_LFP_Data(:,Left_Reference_Tetrode+1);
            Tetrode_Data=Combined_Slow_Gamma_Run_LFP_Data(:,Left_Tetrodes(N)+1);
            Offsets=Tetrode_Data-Reference_Data;
            Offsets(Offsets<0)=Offsets(Offsets<0)+360;
            Offset_Histogram=histcounts(Offsets,0:10:360);
            bar(5:10:715,[Offset_Histogram,Offset_Histogram],'k');
            set(gca,'XLim',[0 720]);
            set(gca,'YTick',[]);
            set(gca,'XTick',0:90:720);
            eval(sprintf('print(''-djpeg'',''Histogram_Of_Slow_Gamma_Phase_Offsets_Tetrodes_%d_and_%d_(Mean_Offset=%d).jpg'');',Left_Tetrodes(N),Left_Reference_Tetrode,Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,3)==Left_Tetrodes(N),1)));
            close
        end
        for N=1:length(Right_Tetrodes)
            figure;
            hold on;
            subplot('Position',[0 0 1 1]);
            hold on;
            Reference_Data=Combined_Slow_Gamma_Run_LFP_Data(:,Right_Reference_Tetrode+1);
            Tetrode_Data=Combined_Slow_Gamma_Run_LFP_Data(:,Right_Tetrodes(N)+1);
            Offsets=Tetrode_Data-Reference_Data;
            Offsets(Offsets<0)=Offsets(Offsets<0)+360;
            Offset_Histogram=histcounts(Offsets,0:10:360);
            bar(5:10:715,[Offset_Histogram,Offset_Histogram],'k');
            set(gca,'XLim',[0 720]);
            set(gca,'YTick',[]);
            set(gca,'XTick',0:90:720);
            eval(sprintf('print(''-djpeg'',''Histogram_Of_Slow_Gamma_Phase_Offsets_Tetrodes_%d_and_%d_(Mean_Offset=%d).jpg'');',Right_Tetrodes(N),Right_Reference_Tetrode,Slow_Gamma_Phase_Offset_Per_Tetrode(Slow_Gamma_Phase_Offset_Per_Tetrode(:,3)==Right_Tetrodes(N),1)));
            close
        end
        cd ..
    end
    
end

end

