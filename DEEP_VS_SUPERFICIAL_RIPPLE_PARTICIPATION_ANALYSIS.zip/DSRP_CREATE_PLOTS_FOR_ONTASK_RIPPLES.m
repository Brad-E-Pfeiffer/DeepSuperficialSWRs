function DSRP_CREATE_PLOTS_FOR_ONTASK_RIPPLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function creates many of the figures for Berndt, Trusel et al.
% A few of the panels are plotted by prior functions, including panels A-D,
% which are plotted by the function DSRP_PLOT_DEPTH_MEASUREMENTS.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis
load All_Cell_Precision_In_Replay
load All_Firing_Properties_During_Behavior

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity')
    mkdir('Experience_Modulation_Of_SWR_Activity')
end
cd 'Experience_Modulation_Of_SWR_Activity'


%==========================================================================
%==========================================================================
% 
% Plot Per-Session Averages for All Cells
% 
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Cell Participation
%
%==========================================================================

if ~isfolder('Per_Session')
    mkdir('Per_Session')
end
cd Per_Session

% Plot for all ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participation_Fraction_P,Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,1))
[Per_Session_Superficial_Participation_Fraction_P,Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_All(:,1))


% Plot for only coherent ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participation_Fraction_P,Coherent_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,1))
[Coherent_Per_Session_Superficial_Participation_Fraction_P,Coherent_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,1))


% Plot for only fragmented ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(N,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(N,1)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(N,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(N,1)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,1)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,1)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,1)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,1)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,1)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,1)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,1)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,1)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,1)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,1)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,1)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,1)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,1)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,1)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,1)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,1)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,1)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,1)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,1)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,1)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,1)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,1)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,1)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Cell_Participation_Fraction_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participation_Fraction_P,Fragmented_Per_Session_Deep_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,1),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,1))
[Fragmented_Per_Session_Superficial_Participation_Fraction_P,Fragmented_Per_Session_Superficial_Participation_Fraction_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,1),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,1))

%==========================================================================
%
% Plot Firing Rate (Only for Participating Cells)
%
%==========================================================================

%Plot Per Session Firing Rate Of Participating Cells
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participating_Firing_Rate_P,Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))
[Per_Session_Superficial_Participating_Firing_Rate_P,Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))


% Plot for only coherent ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participating_Firing_Rate_P,Coherent_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))
[Coherent_Per_Session_Superficial_Participating_Firing_Rate_P,Coherent_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))


% Plot for only fragmented ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participating_Firing_Rate_P,Fragmented_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))
[Fragmented_Per_Session_Superficial_Participating_Firing_Rate_P,Fragmented_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))

cd ..


%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================




%==========================================================================
%==========================================================================
%
% Plot Per Cell Experience-Modulation Index Box Plots
%
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Large Cell Participation
%
%==========================================================================
if ~isfolder('Large Cell Experience Modulation Index')
    mkdir('Large Cell Experience Modulation Index')
end
cd('Large Cell Experience Modulation Index')

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_All(:,1)./All_Large_Deep_Per_Cell_Pre_All(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_All(:,1)./All_Large_Super_Per_Cell_Pre_All(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Participation_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Coherent_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Coherent_Participation_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Fragmented_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Fragmented_Participation_P=signrank(Super_Index)*2

%==========================================================================
%
% Plot Large Cell Firing Rate (Only for Participating Cells)
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_FR_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Coherent_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Coherent_FR_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3));
%Deep_Index=(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)-All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))./(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)+All_Large_Deep_Per_Cell_Pre_Fragmented(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3));
%Super_Index=(All_Large_Super_Per_Cell_Post_Fragmented(:,3)-All_Large_Super_Per_Cell_Pre_Fragmented(:,3))./(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)+All_Large_Super_Per_Cell_Pre_Fragmented(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Fragmented_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Fragmented_FR_P=signrank(Super_Index)*2

% Plot for non SWS periods 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Non_SWS(:,2)./All_Large_Deep_Non_SWS(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Non_SWS(:,2)./All_Large_Super_Non_SWS(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Outside_Of_SWRs(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Non_SWRs_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Non_SWRs_FR_P=signrank(Super_Index)*2

cd ..

%==========================================================================
%
% Plot Cell Participation (all cells, regardless of spike amplitude)
%
%==========================================================================
if ~isfolder('All Cell Experience Modulation Index')
    mkdir('All Cell Experience Modulation Index')
end
cd('All Cell Experience Modulation Index')

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_All(:,1)./All_Deep_Per_Cell_Pre_All(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_All(:,1)./All_Super_Per_Cell_Pre_All(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Participation_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Coherent(:,1)./All_Deep_Per_Cell_Pre_Coherent(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Coherent(:,1)./All_Super_Per_Cell_Pre_Coherent(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Coherent_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Coherent_Participation_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Fragmented(:,1)./All_Deep_Per_Cell_Pre_Fragmented(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Fragmented(:,1)./All_Super_Per_Cell_Pre_Fragmented(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Participation_Fraction_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Fragmented_Participation_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Fragmented_Participation_P=signrank(Super_Index)*2

%==========================================================================
%
% Plot Firing Rate (Only for Participating Cells, all cells regardless of spike amplitude) 
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_All(:,3)./All_Deep_Per_Cell_Pre_All(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_All(:,3)./All_Super_Per_Cell_Pre_All(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Firing_Rate(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_FR_P=signrank(Super_Index)*2

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Coherent(:,3)./All_Deep_Per_Cell_Pre_Coherent(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Coherent(:,3)./All_Super_Per_Cell_Pre_Coherent(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Firing_Rate_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Coherent_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Coherent_FR_P=signrank(Super_Index)*2

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Per_Cell_Post_Fragmented(:,3)./All_Deep_Per_Cell_Pre_Fragmented(:,3));
%Deep_Index=(All_Deep_Per_Cell_Post_Fragmented(:,3)-All_Deep_Per_Cell_Pre_Fragmented(:,3))./(All_Deep_Per_Cell_Pre_Fragmented(:,3)+All_Deep_Per_Cell_Pre_Fragmented(:,3));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Per_Cell_Post_Fragmented(:,3)./All_Super_Per_Cell_Pre_Fragmented(:,3));
%Super_Index=(All_Super_Per_Cell_Post_Fragmented(:,3)-All_Super_Per_Cell_Pre_Fragmented(:,3))./(All_Super_Per_Cell_Pre_Fragmented(:,3)+All_Super_Per_Cell_Pre_Fragmented(:,3));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Firing_Rate_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Fragmented_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Fragmented_FR_P=signrank(Super_Index)*2

% Plot for non SWS periods 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Non_SWS(:,2)./All_Deep_Non_SWS(:,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Non_SWS(:,2)./All_Super_Non_SWS(:,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Firing_Rate_Outside_Of_SWRs(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Non_SWRs_FR_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Non_SWRs_FR_P=signrank(Super_Index)*2

cd ..




%==========================================================================
%==========================================================================
%
% Plot Per Cell Raw Firing Rate and Participation
%
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Cell Participation
%
%==========================================================================
if ~isfolder('Large Cell Raw Values')
    mkdir('Large Cell Raw Values')
end
cd('Large Cell Raw Values')

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,1)),1)),1)*1,All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)),1)),1)*2,All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,1)),1)),1)*4,All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,1)),1)),1)*5,All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,1)),1),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Participation_Fraction_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

%==========================================================================
%
% Plot Firing Rate (Only for Participating Cells)
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)),3)),1)*1,All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)),3)),1)*2,All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)),3)),1)*4,All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,3)),3)),1)*5,All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,3)),3),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Firing_Rate_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

%==========================================================================
%
% Plot Mean Spike Count (For All Cells)
%
%==========================================================================

% Plot for all ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_All(~isnan(All_Large_Deep_Per_Cell_Pre_All(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_All(~isnan(All_Large_Deep_Per_Cell_Post_All(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_All(~isnan(All_Large_Super_Per_Cell_Pre_All(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_All(~isnan(All_Large_Super_Per_Cell_Post_All(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only coherent ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_Coherent(~isnan(All_Large_Deep_Per_Cell_Pre_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_Coherent(~isnan(All_Large_Deep_Per_Cell_Post_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_Coherent(~isnan(All_Large_Super_Per_Cell_Pre_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_Coherent(~isnan(All_Large_Super_Per_Cell_Post_Coherent(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

% Plot for only fragmented ripples 
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(length(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,2)),2)),1)*1,log(All_Large_Deep_Per_Cell_Pre_Fragmented(~isnan(All_Large_Deep_Per_Cell_Pre_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,2)),2)),1)*2,log(All_Large_Deep_Per_Cell_Post_Fragmented(~isnan(All_Large_Deep_Per_Cell_Post_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,2)),2)),1)*4,log(All_Large_Super_Per_Cell_Pre_Fragmented(~isnan(All_Large_Super_Per_Cell_Pre_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(length(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,2)),2)),1)*5,log(All_Large_Super_Per_Cell_Post_Fragmented(~isnan(All_Large_Super_Per_Cell_Post_Fragmented(:,2)),2)),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 5.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Large_Cell_Log_Spike_Count_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

cd ..




%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================


%==========================================================================
%==========================================================================
%
% Plot On-Task Firing Rate Index Vs. Experience Modulation of Ripple Firing For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================
cd ..
cd ..
cd AllRatsCombined

load All_Per_Ripple_And_Per_Cell_Analysis
load All_Cell_Precision_In_Replay
load All_Firing_Properties_During_Behavior

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity')
    mkdir('Experience_Modulation_Of_SWR_Activity')
end
cd 'Experience_Modulation_Of_SWR_Activity'

if ~isfolder('Correlation_In_Firing_And_Ripple_Modulation')
    mkdir('Correlation_In_Firing_And_Ripple_Modulation')
end
cd('Correlation_In_Firing_And_Ripple_Modulation')

%Participation for Large Cells for All Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_All(:,1)./All_Large_Deep_Per_Cell_Pre_All(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_All(:,1)./All_Large_Super_Per_Cell_Pre_All(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_All_Corr_R,Large_Deep_Participation_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_All_Corr_R,Large_Super_Participation_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_All_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_All_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Participation_All_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Participation_All_Hi_P=signrank(Super(Super(:,1)>0,2))*4

%Participation for Large Cells for Coherent Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Coherent_Corr_R,Large_Deep_Participation_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Coherent_Corr_R,Large_Super_Participation_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Participation_Coherent_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Participation_Coherent_Hi_P=signrank(Super(Super(:,1)>0,2))*4

%Participation for Large Cells for Fragmented Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Fragmented_Corr_R,Large_Deep_Participation_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Fragmented_Corr_R,Large_Super_Participation_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Participation_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Participation_Fragmented_Hi_P=signrank(Super(Super(:,1)>0,2))*4


%Firing Rate for Large Cells for All Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_All_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_All_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Firing_Rate_All_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Firing_Rate_All_Hi_P=signrank(Super(Super(:,1)>0,2))*4

%Firing Rate for Large Cells for Coherent Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Coherent_Corr_R,Large_Deep_Firing_Rate_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Coherent_Corr_R,Large_Super_Firing_Rate_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Firing_Rate_Coherent_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Firing_Rate_Coherent_Hi_P=signrank(Super(Super(:,1)>0,2))*4

%Firing Rate for Large Cells for Fragmented Ripples
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-1.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Fragmented_Corr_R,Large_Deep_Firing_Rate_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Fragmented_Corr_R,Large_Super_Firing_Rate_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Firing_Rate_Index_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Firing_Rate_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Firing_Rate_Fragmented_Hi_P=signrank(Super(Super(:,1)>0,2))*4

cd ..





%==========================================================================
%==========================================================================
%
% Plot On-Task Burstiness Index Vs. Experience Modulation of Ripple Firing For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================

if ~isfolder('Correlation_In_Burstiness_And_Ripple_Modulation')
    mkdir('Correlation_In_Burstiness_And_Ripple_Modulation')
end
cd('Correlation_In_Burstiness_And_Ripple_Modulation')

%Participation for Large Cells for All Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_All(:,1)./All_Large_Deep_Per_Cell_Pre_All(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_All(:,1)./All_Large_Super_Per_Cell_Pre_All(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_All_Corr_R,Large_Deep_Participation_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_All_Corr_R,Large_Super_Participation_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_All_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_All_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_All_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_All_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%Participation for Large Cells for Coherent Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Coherent_Corr_R,Large_Deep_Participation_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Coherent_Corr_R,Large_Super_Participation_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_Coherent_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_Coherent_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%Participation for Large Cells for Fragmented Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Participation_Fragmented_Corr_R,Large_Deep_Participation_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Participation_Fragmented_Corr_R,Large_Super_Participation_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Participation_Index_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Participation_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Participation_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Participation_Fragmented_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4


%Firing Rate for Large Cells for All Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_All_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_All_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_All_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_All_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%Firing Rate for Large Cells for Coherent Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Coherent_Corr_R,Large_Deep_Firing_Rate_Coherent_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Coherent_Corr_R,Large_Super_Firing_Rate_Coherent_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Coherent_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_Coherent_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_Coherent_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

%Firing Rate for Large Cells for Fragmented Ripples
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',10,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=0.1;
End=0.9;
Step=0.1;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[-0.01 1.01])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
[Large_Deep_Firing_Rate_Fragmented_Corr_R,Large_Deep_Firing_Rate_Fragmented_Corr_P]=corr(Deep(:,1),Deep(:,2))
[Large_Super_Firing_Rate_Fragmented_Corr_R,Large_Super_Firing_Rate_Fragmented_Corr_P]=corr(Super(:,1),Super(:,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*3,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*4,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Burstiness_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Fragmented_Lo_P=signrank(Deep(Deep(:,1)<=0.5,2))*4  %*4 for Bonferroni correction
Large_Deep_Firing_Rate_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>0.5,2))*4
Large_Super_Firing_Rate_Fragmented_Lo_P=signrank(Super(Super(:,1)<=0.5,2))*4
Large_Super_Firing_Rate_Fragmented_Hi_P=signrank(Super(Super(:,1)>0.5,2))*4

cd ..






































%Participation for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))

%Participation for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))



%Firing Rate for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))

%Firing Rate for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))

%Firing Rate for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))





cd ..
















%==========================================================================
%==========================================================================
%
% Plot On-Task Burstiness Index Vs. Experience Modulation of Ripple Firing
%
%==========================================================================
%==========================================================================

%Firing Rate for Large Cells
Deep=[All_Large_Deep_Firing_Properties_During_Behavior(:,3),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[All_Large_Super_Firing_Properties_During_Behavior(:,3),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0.5),1)*1,Deep(Deep(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0.5),1)*2,Deep(Deep(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0.5),1)*4,Super(Super(:,1)<=0.5,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0.5),1)*5,Super(Super(:,1)>0.5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0.5,2))
signrank(Deep(Deep(:,1)>0.5,2))
signrank(Super(Super(:,1)<=0.5,2))
signrank(Super(Super(:,1)>0.5,2))
ranksum(Deep(Deep(:,1)<=0.5,2),Deep(Deep(:,1)>0.5,2))
ranksum(Super(Super(:,1)<=0.5,2),Super(Super(:,1)>0.5,2))






%Participation for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))



%Firing Rate for Large Cells
Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
plot([0 0],[Y_Lim(1) Y_Lim(2)],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/20),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/20),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*5,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
plot([0 6],[0 0],'k--')
signrank(Deep(Deep(:,1)<=0,2))
signrank(Deep(Deep(:,1)>0,2))
signrank(Super(Super(:,1)<=0,2))
signrank(Super(Super(:,1)>0,2))
ranksum(Deep(Deep(:,1)<=0,2),Deep(Deep(:,1)>0,2))
ranksum(Super(Super(:,1)<=0,2),Super(Super(:,1)>0,2))












%Participation for Large Cells
Deep=[log(All_Deep_Firing_Properties_During_Behavior(:,1)./All_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Deep_Per_Cell_Post_Fragmented(:,3)./All_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[log(All_Super_Firing_Properties_During_Behavior(:,1)./All_Super_Firing_Properties_During_Behavior(:,4)),log(All_Super_Per_Cell_Post_Fragmented(:,3)./All_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
Start=min([Deep(:,1);Super(:,1)]);
End=max([Deep(:,1);Super(:,1)]);
Step=(End-Start)/9;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot(N-(Step/10),mean(D,'omitnan'),'o','MarkerFaceColor',[0.7 0 0],'MarkerEdgeColor',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/10),N-(Step/10)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',2,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot(N+(Step/10),mean(S,'omitnan'),'s','MarkerFaceColor',[0 0 0.7],'MarkerEdgeColor',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/10),N+(Step/10)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',2,'Color',[0 0 0.7]);
        end
    end
end













cd ..

%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================
%================================================================================================================================================================================================================================================================================================




%==========================================================================
%==========================================================================
%
% Plot Cell Precision In Replay
%
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Large Cell Precision
%
%==========================================================================
if ~isfolder('Cell_Precision')
    mkdir('Cell_Precision')
end
cd('Cell_Precision')
if ~isfolder('Large_Cell_Precision')
    mkdir('Large_Cell_Precision')
end
cd('Large_Cell_Precision')

% Plot for all ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,8,1)),8,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,8,1)),2,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,2,1)) & ~isnan(All_Large_Super_Cell_Precision(:,8,1)),8,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,2,1)) & ~isnan(All_Large_Super_Cell_Precision(:,8,1)),2,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_All_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_All_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_All_Precision_P=signrank(Super_Index)*2

% Plot for only coherent ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,9,1)),9,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,9,1)),3,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,3,1)) & ~isnan(All_Large_Super_Cell_Precision(:,9,1)),9,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,3,1)) & ~isnan(All_Large_Super_Cell_Precision(:,9,1)),3,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Coherent_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Coherent_Precision_P=signrank(Super_Index)*2

% Plot for only fragmented ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,10,1)),10,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,10,1)),4,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,4,1)) & ~isnan(All_Large_Super_Cell_Precision(:,10,1)),10,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,4,1)) & ~isnan(All_Large_Super_Cell_Precision(:,10,1)),4,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Fragmented_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Fragmented_Precision_P=signrank(Super_Index)*2

cd ..

if ~isfolder('All_Cell_Precision')
    mkdir('All_Cell_Precision')
end
cd('All_Cell_Precision')

% Plot for all ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Deep_Cell_Precision(:,8,1)),8,1)./All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Deep_Cell_Precision(:,8,1)),2,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,2,1)) & ~isnan(All_Super_Cell_Precision(:,8,1)),8,1)./All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,2,1)) & ~isnan(All_Super_Cell_Precision(:,8,1)),2,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_All_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_All_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_All_Precision_P=signrank(Super_Index)*2

% Plot for only coherent ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Deep_Cell_Precision(:,9,1)),9,1)./All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Deep_Cell_Precision(:,9,1)),3,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,3,1)) & ~isnan(All_Super_Cell_Precision(:,9,1)),9,1)./All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,3,1)) & ~isnan(All_Super_Cell_Precision(:,9,1)),3,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Coherent_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Coherent_Precision_P=signrank(Super_Index)*2

% Plot for only fragmented ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Deep_Cell_Precision(:,10,1)),10,1)./All_Deep_Cell_Precision(~isnan(All_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Deep_Cell_Precision(:,10,1)),4,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,4,1)) & ~isnan(All_Super_Cell_Precision(:,10,1)),10,1)./All_Super_Cell_Precision(~isnan(All_Super_Cell_Precision(:,4,1)) & ~isnan(All_Super_Cell_Precision(:,10,1)),4,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Cell_Deep_Fragmented_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Cell_Superficial_Fragmented_Precision_P=signrank(Super_Index)*2

cd ..
cd ..
















Type=1; %0=all, 1=coherent; 2=fragmented
State=1; %1=all, 2=sleep, 3=awake
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
X_Matrix=[ones(size(All_Deep_Cell_Precision,1),1)*1;ones(size(All_Deep_Cell_Precision,1),1)*2;ones(size(All_Super_Cell_Precision,1),1)*3;ones(size(All_Super_Cell_Precision,1),1)*4];
Y_Matrix=[All_Deep_Cell_Precision(:,Type+2,State);All_Deep_Cell_Precision(:,Type+8,State);All_Super_Cell_Precision(:,Type+2,State);All_Super_Cell_Precision(:,Type+8,State)];
boxchart(X_Matrix,Y_Matrix,'Notch','on','BoxFaceColor','k','WhiskerLineColor','k','MarkerColor','k');
Deep_P=signrank(All_Deep_Cell_Precision(:,Type+2,State),All_Deep_Cell_Precision(:,Type+8,State))
Super_P=signrank(All_Super_Cell_Precision(:,Type+2,State),All_Super_Cell_Precision(:,Type+8,State))
Pre_P=ranksum(All_Deep_Cell_Precision(:,Type+2,State),All_Super_Cell_Precision(:,Type+2,State))
Post_P=ranksum(All_Deep_Cell_Precision(:,Type+8,State),All_Super_Cell_Precision(:,Type+8,State))


Type=1; %0=all, 1=coherent; 2=fragmented
State=1; %1=all, 2=sleep, 3=awake
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
X_Matrix=[ones(size(All_Large_Deep_Cell_Precision,1),1)*1;ones(size(All_Large_Deep_Cell_Precision,1),1)*2;ones(size(All_Large_Super_Cell_Precision,1),1)*3;ones(size(All_Large_Super_Cell_Precision,1),1)*4];
Y_Matrix=[All_Large_Deep_Cell_Precision(:,Type+2,State);All_Large_Deep_Cell_Precision(:,Type+8,State);All_Large_Super_Cell_Precision(:,Type+2,State);All_Large_Super_Cell_Precision(:,Type+8,State)];
boxchart(X_Matrix,Y_Matrix,'Notch','on','BoxFaceColor','k','WhiskerLineColor','k','MarkerColor','k');
Deep_P=signrank(All_Large_Deep_Cell_Precision(:,Type+2,State),All_Large_Deep_Cell_Precision(:,Type+8,State))
Super_P=signrank(All_Large_Super_Cell_Precision(:,Type+2,State),All_Large_Super_Cell_Precision(:,Type+8,State))
Pre_P=ranksum(All_Large_Deep_Cell_Precision(:,Type+2,State),All_Large_Super_Cell_Precision(:,Type+2,State))
Post_P=ranksum(All_Large_Deep_Cell_Precision(:,Type+8,State),All_Large_Super_Cell_Precision(:,Type+8,State))






cd ..

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables

end

