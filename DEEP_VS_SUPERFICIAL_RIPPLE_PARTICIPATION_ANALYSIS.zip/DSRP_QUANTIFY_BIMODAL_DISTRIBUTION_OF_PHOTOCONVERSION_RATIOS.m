function DSRP_QUANTIFY_BIMODAL_DISTRIBUTION_OF_PHOTOCONVERSION_RATIOS(Initial_Variables)

%These data are from the Graphpad Prism datafile.

% Photoconversion_Histograms
% |  1  |         2          |      3    ||
% | Bin | Active Exploration | Patch Rig ||

Photoconversion_Histograms=[
    1	8	3
    2	19	6
    3	24	14
    4	14	13
    5	13	5
    6	14	4
    7	18	7
    8	11	4
    9	7	0
    10	7	2
    11	5	3
    12	2	1
    13	2	3
    14	0	0
    15	1	1
    16	0	3
    17	0	0
    18	0	0
    19	0	0
    20	1	1
    21	0	2
    22	0	0
    23	0	0
    24	0	0
    25	0	0
    26	0	0
    27	0	0
    28	0	0
    29	0	0
    30	0	0
    31	0	0
    32	0	1
    33	1	0];

Two_Photon_Values=0;
for N=1:size(Photoconversion_Histograms,1)
    Two_Photon_Values=[Two_Photon_Values;ones(Photoconversion_Histograms(N,2),1)*Photoconversion_Histograms(N,1)];
end
Two_Photon_Values=Two_Photon_Values(2:end,:);

Patch_Rig_Values=0;
for N=1:size(Photoconversion_Histograms,1)
    Patch_Rig_Values=[Patch_Rig_Values;ones(Photoconversion_Histograms(N,3),1)*Photoconversion_Histograms(N,1)];
end
Patch_Rig_Values=Patch_Rig_Values(2:end,:);

[~,Two_Photon_P_Value,~,~]=HartigansDipSignifTest(Two_Photon_Values,1000)
[~,Patch_Rig_P_Value,~,~]=HartigansDipSignifTest(Patch_Rig_Values,1000)

%Minimum p-value for this function is 0.001, so a value of 0 is <0.001.

end