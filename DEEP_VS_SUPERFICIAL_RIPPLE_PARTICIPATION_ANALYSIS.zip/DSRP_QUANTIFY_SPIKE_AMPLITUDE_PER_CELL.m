function DSRP_QUANTIFY_SPIKE_AMPLITUDE_PER_CELL(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up the raw spike waveforms for each cell and
% calculates the average amplitude.  This value is used to estimate which
% cells are the closest to the recording site (those with the largest
% amplitude) so that they can be used to quantify additional recording
% depth features later in the analysis (such as REM-based theta shifting).
% 
% Because each tetrode has a slightly different recording impedence, you
% can't just simply use a flat spike amplitude threshold to find cells
% closest to a given tetrode.  Rather, you need to perform a relative
% comparison, so that you only look at tetrodes with at least three cells
% and then find cells that have a mean spike amplitude greater than half of
% the maximum amplitude.  That should limit you to cells close to that
% tetrode's recording site.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if ~isfile('Tetrode_Cell_Spike_Amplitudes.mat')
    
    load('Spike_Data','Tetrode_Cell_IDs','Spike_Data')
    Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
    
    % Tetrode_Cell_Spike_Amplitudes
    % |      1     |     2   |                               3                           |                   4                 |                   5                |                     6               |                    7                ||
    % | Tetrode ID | Cell ID | Mean Spike Amplitude on Electrode With Largest Spike (uV) | Mean Spike Amplitude on Electrode 1 | Mean Spike Ampitude on Electrode 2 | Mean Spike Amplitude on Electrode 3 | Mean Spike Amplitude on Electrode 4 ||
    Tetrode_Cell_Spike_Amplitudes=zeros(max(Spike_Data(:,2)),7);

    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Raw_LFP_Root_Directory));
        end
    end
    
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    
    Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
    for TT=1:length(Tetrode_List)
        
        Current_Tetrode=Tetrode_List(TT);
        
        % Find clustered cells/spikes from this tetrode
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2);
        Tetrode_Spike_Data=zeros(1,2);
        for N=1:length(Cells_On_This_Tetrode)
            Tetrode_Spike_Data=[Tetrode_Spike_Data;Spike_Data(Spike_Data(:,2)==Cells_On_This_Tetrode(N),1:2)];
        end
        Tetrode_Spike_Data=Tetrode_Spike_Data(2:end,:);
        
        % Load raw spike times and waveform peaks for this tetrode
        Tetrode_Name=sprintf('TT%d.ntt',Current_Tetrode);
        Spike_Times=Nlx2MatSpike(Tetrode_Name,[1 0 0 0 0],0,1)/1000000;
        Spike_Parameters=Nlx2MatSpike(Tetrode_Name,[0 0 0 1 0],0,1)'*(1500/32767); %puts the spike amplitudes into uV based on the recording conditions (see Header info for raw spike files)
        
        % Find waveforms peaks for each clustered spike (using matching spike times), average, and find largest across four recording electrodes 
        for Current_Cell=1:length(Cells_On_This_Tetrode)
            Cell_Spike_Times=Tetrode_Spike_Data(Tetrode_Spike_Data(:,2)==Cells_On_This_Tetrode(Current_Cell),1);
            [~,Index]=ismember(Cell_Spike_Times,Spike_Times);
            Cell_Spike_Parameters=Spike_Parameters(Index,:);
            Spike_Mean_Peaks=mean(Cell_Spike_Parameters(:,1:4),'omitnan'); %First four points are the peak -- this recording inverted the waveforms
            Tetrode_Cell_Spike_Amplitudes(Cells_On_This_Tetrode(Current_Cell),:)=[Current_Tetrode,Cells_On_This_Tetrode(Current_Cell),max(Spike_Mean_Peaks),Spike_Mean_Peaks];
        end
    end
    
    cd(Current_Working_Directory)
    
    save('Tetrode_Cell_Spike_Amplitudes','Tetrode_Cell_Spike_Amplitudes')
end

end

