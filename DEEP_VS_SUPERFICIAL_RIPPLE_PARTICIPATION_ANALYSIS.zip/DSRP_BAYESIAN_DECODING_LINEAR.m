function [Decoded_Data_Total,Decoded_Data_In,Decoded_Data_Out]=DSRP_BAYESIAN_DECODING_LINEAR(Event_Spike_Data,Field_Data_Linear,Field_Data_Linear_In,Field_Data_Linear_Out,Field_Data_Linear2,Field_Data_Linear_In2,Field_Data_Linear_Out2,Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function uses the Bayesian decoding algorithm from [Davidson et al,
% 2009] and decodes the information contained within a spike train.
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Here, I pre-allocate a variable to store the decoded data
Start_Time=min(Event_Spike_Data(:,1));
End_Time=max(Event_Spike_Data(:,1));
Number_Of_Time_Steps=ceil((End_Time-Start_Time)/Initial_Variables.Decoding_Time_Advance);
Temporary_Decoded_Data=zeros(size(Field_Data_Linear,1),Number_Of_Time_Steps,3);
Line=0;

% Here is where the decoding actual happens
while Start_Time<=End_Time
    Subset_Spike_Data=Event_Spike_Data(Event_Spike_Data(:,1)>=Start_Time & Event_Spike_Data(:,1)<(Start_Time+Initial_Variables.Decoding_Time_Window),:);
    if 1%~isempty(Subset_Spike_Data),  %This skips forward one step if there aren't any spikes in the current window of decoding.  To use all time windows, change this line to "if 1,"
        Line=Line+1;
        Decoded_Matrix=prod(Field_Data_Linear2(:,Subset_Spike_Data(:,2)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum(Field_Data_Linear,2));
        Decoded_Matrix_In=prod(Field_Data_Linear_In2(:,Subset_Spike_Data(:,2)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum(Field_Data_Linear_In,2));
        Decoded_Matrix_Out=prod(Field_Data_Linear_Out2(:,Subset_Spike_Data(:,2)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum(Field_Data_Linear_Out,2));
        if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
            Divider=1;
            while isinf(max(max(Decoded_Matrix)))
                Decoded_Matrix=prod((Field_Data_Linear2(:,Subset_Spike_Data(:,2))/(2^Divider)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                Divider=Divider+1;
            end
            clear Divider;
        end
        if isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
            Divider=1;
            while isinf(max(max(Decoded_Matrix_In))) || isinf(max(max(Decoded_Matrix_Out)))
                Decoded_Matrix_In=prod((Field_Data_Linear_In2(:,Subset_Spike_Data(:,2))/(2^Divider)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum((Field_Data_Linear_In/(2^Divider)),2));
                Decoded_Matrix_Out=prod((Field_Data_Linear_Out2(:,Subset_Spike_Data(:,2))/(2^Divider)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum((Field_Data_Linear_Out/(2^Divider)),2));
                Divider=Divider+1;
            end
            clear Divider;
        end
        Decoded_Matrix(Decoded_Matrix<0)=0;
        Decoded_Matrix_In(Decoded_Matrix_In<0)=0;
        Decoded_Matrix_Out(Decoded_Matrix_Out<0)=0;
        if max(max(Decoded_Matrix))>0
            Decoded_Matrix=Decoded_Matrix/sum(Decoded_Matrix);
        end
        if max(max(Decoded_Matrix_In))>0 || max(max(Decoded_Matrix_Out))>0 
            Sum=sum(Decoded_Matrix_In+Decoded_Matrix_Out);
            Decoded_Matrix_In=Decoded_Matrix_In/Sum;
            Decoded_Matrix_Out=Decoded_Matrix_Out/Sum;
        end
        Temporary_Decoded_Data(:,Line,1)=Decoded_Matrix;
        Temporary_Decoded_Data(:,Line,2)=Decoded_Matrix_In;
        Temporary_Decoded_Data(:,Line,3)=Decoded_Matrix_Out;
    end
    Start_Time=Start_Time+Initial_Variables.Decoding_Time_Advance;
end

Decoded_Data_Total=Temporary_Decoded_Data(:,1:Line,1);
Decoded_Data_In=Temporary_Decoded_Data(:,1:Line,2);
Decoded_Data_Out=Temporary_Decoded_Data(:,1:Line,3);

end

