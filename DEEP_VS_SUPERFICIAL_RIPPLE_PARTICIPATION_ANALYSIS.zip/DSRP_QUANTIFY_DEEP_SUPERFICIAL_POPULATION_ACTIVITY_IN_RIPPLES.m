function DSRP_QUANTIFY_DEEP_SUPERFICIAL_POPULATION_ACTIVITY_IN_RIPPLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and quantifies the percent of cells
% from deep vs. superficial tetrodes that participate as well as the number
% of spikes emitted from participating cells.  Only excitatory neurons are
% examined here.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Cell_Participation_Per_All/Coherent/Fragmented_Ripple (Page 1 is percent cell participation, Page 2 is spikes per participating cell)
% |       1       |                   2-end                 ||
% | Ripple Number | Participation per cell for each tetrode ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Participation of Deep and Superficial Cells in Ripples for %s Day %d.'')',Rat_Name,Experiment)); 

        if ~isfile('Cell_Participation_Per_Ripple.mat')
            load('Deep_And_Superficial_Cell_Identities','Deep_Cells','Superficial_Cells','Large_Deep_Cells','Large_Superficial_Cells');
            load('Epochs','Run_Times')
            load('Ripple_Events','Ripple_Events')
            load('Spike_Data','Spike_Data','Inhibitory_Neurons')
            load('Field_Data','Field_Data')
            load('Coherent_Fragmented_Ripples','Coherent_Fragmented_Ripples')
            for N=1:max(Spike_Data(:,2))
                if max(max(Field_Data(:,:,N)))==0 || max(max(Field_Data(:,:,N)))>80 || sum(Inhibitory_Neurons==N)>0 
                    Spike_Data=Spike_Data(Spike_Data(:,2)~=N,:);
                end
            end
            Excitatory_Neurons=unique(Spike_Data(:,2));

            Deep_Superficial_All_Ripple_Participation=zeros(size(Ripple_Events,1),4,2);
            Deep_Superficial_Coherent_Ripple_Participation=zeros(size(Ripple_Events,1),4,2);
            Deep_Superficial_Fragmented_Ripple_Participation=zeros(size(Ripple_Events,1),4,2);
            % Deep_Superficial_All/Coherent/Fragmented_Ripple_Participation (Page 1 is all cells/spikes; Page 2 is only using cells/spikes with large amplitude spikes (those closest to the recording site)
            % |                1                   |                      2                     |                  3                 |                      4                     ||
            % | Percent Particpation of Deep Cells | Percent Participation of Superficial Cells | Mean FR of Particpating Deep Cells | Mean FR of Participating Superficial Cells ||

            PreSleep_Ripples=Ripple_Events(Ripple_Events(:,2)<Run_Times(1,1),:);
            PreSleep_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,2)<Run_Times(1,1),:);
            PreSleep_Deep_Superficial_All_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,2)<Run_Times(1,1),:,:);
            PreSleep_Deep_Superficial_Coherent_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,2)<Run_Times(1,1),:,:);
            PreSleep_Deep_Superficial_Fragmented_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,2)<Run_Times(1,1),:,:);
            Run_Ripples=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            Run_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:);
            Run_Deep_Superficial_All_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
            Run_Deep_Superficial_Coherent_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
            Run_Deep_Superficial_Fragmented_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
            if size(Run_Times,1)==1
                PostSleep_Ripples=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2),:);
                PostSleep_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,1)>Run_Times(1,2),:);
                PostSleep_Deep_Superficial_All_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2),:,:);
                PostSleep_Deep_Superficial_Coherent_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2),:,:);
                PostSleep_Deep_Superficial_Fragmented_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2),:,:);
            else
                PostSleep_Ripples=Ripple_Events(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:);
                PostSleep_Coherent_Fragmented_Ripples=Coherent_Fragmented_Ripples(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:);
                PostSleep_Deep_Superficial_All_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:,:);
                PostSleep_Deep_Superficial_Coherent_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:,:);
                PostSleep_Deep_Superficial_Fragmented_Ripple_Participation=Deep_Superficial_All_Ripple_Participation(Ripple_Events(:,1)>Run_Times(1,2) & Ripple_Events(:,2)<Run_Times(2,1),:,:);
            end

            for Current_Ripple=1:size(PreSleep_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=PreSleep_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=PreSleep_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Deep_Cells),:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Superficial_Cells),:);
                    Large_Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Deep_Cells),:);
                    Large_Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Superficial_Cells),:);
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                    if PreSleep_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                    elseif PreSleep_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PreSleep_Ripples(Current_Ripple,2)-PreSleep_Ripples(Current_Ripple,1))];
                    end
                else
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                    PreSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    if PreSleep_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        PreSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    elseif PreSleep_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    end
                end
            end

            for Current_Ripple=1:size(Run_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=Run_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Deep_Cells),:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Superficial_Cells),:);
                    Large_Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Deep_Cells),:);
                    Large_Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Superficial_Cells),:);
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                    if Run_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                    elseif Run_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(Run_Ripples(Current_Ripple,2)-Run_Ripples(Current_Ripple,1))];
                    end
                else
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                    Run_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    if Run_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        Run_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    elseif Run_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        Run_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    end
                end
            end

            for Current_Ripple=1:size(PostSleep_Ripples,1)
                Ripple_Spike_Data=Spike_Data(Spike_Data(:,1)>=PostSleep_Ripples(Current_Ripple,1) & Spike_Data(:,1)<=PostSleep_Ripples(Current_Ripple,2),:);
                if ~isempty(Ripple_Spike_Data)
                    Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Deep_Cells),:);
                    Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Superficial_Cells),:);
                    Large_Ripple_Deep_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Deep_Cells),:);
                    Large_Ripple_Superficial_Cell_Spikes=Ripple_Spike_Data(ismember(Ripple_Spike_Data(:,2),Large_Superficial_Cells),:);
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                    if PostSleep_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                    elseif PostSleep_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,1)=[length(unique(Ripple_Deep_Cell_Spikes(:,2)))/length(Deep_Cells),length(unique(Ripple_Superficial_Cell_Spikes(:,2)))/length(Superficial_Cells)];
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:2,2)=[length(unique(Large_Ripple_Deep_Cell_Spikes(:,2)))/length(Large_Deep_Cells),length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2)))/length(Large_Superficial_Cells)];
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,1)=[(length(Ripple_Deep_Cell_Spikes(:,1))/length(unique(Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,3:4,2)=[(length(Large_Ripple_Deep_Cell_Spikes(:,1))/length(unique(Large_Ripple_Deep_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1)),(length(Large_Ripple_Superficial_Cell_Spikes(:,1))/length(unique(Large_Ripple_Superficial_Cell_Spikes(:,2))))/(PostSleep_Ripples(Current_Ripple,2)-PostSleep_Ripples(Current_Ripple,1))];
                    end
                else
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                    PostSleep_Deep_Superficial_All_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    if PostSleep_Coherent_Fragmented_Ripples(Current_Ripple,2)==1
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        PostSleep_Deep_Superficial_Coherent_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    elseif PostSleep_Coherent_Fragmented_Ripples(Current_Ripple,3)==1
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,1)=[0,0,NaN,NaN];
                        PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(Current_Ripple,1:4,2)=[0,0,NaN,NaN];
                    end
                end
            end

            save('Cell_Participation_Per_Ripple','PreSleep_Deep_Superficial_All_Ripple_Participation','Run_Deep_Superficial_All_Ripple_Participation','PostSleep_Deep_Superficial_All_Ripple_Participation','PreSleep_Deep_Superficial_Coherent_Ripple_Participation','Run_Deep_Superficial_Coherent_Ripple_Participation','PostSleep_Deep_Superficial_Coherent_Ripple_Participation','PreSleep_Deep_Superficial_Fragmented_Ripple_Participation','Run_Deep_Superficial_Fragmented_Ripple_Participation','PostSleep_Deep_Superficial_Fragmented_Ripple_Participation')

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end
    
    clear Directory
    cd ..

end

clearvars -except Initial_Variables

% This is all cells
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load Cell_Participation_Per_Ripple
        load('Spike_Data','Spike_Data','Inhibitory_Neurons')
        load('Field_Data','Field_Data')
        for N=1:max(Spike_Data(:,2))
            if max(max(Field_Data(:,:,N)))==0 || max(max(Field_Data(:,:,N)))>80 || sum(Inhibitory_Neurons==N)>0
                Spike_Data=Spike_Data(Spike_Data(:,2)~=N,:);
            end
        end
        Number_Of_Neurons=length(unique(Spike_Data(:,2)));

        Mean_PreSleep_Deep_Participation=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,1))))];
        Mean_PreSleep_Deep_Firing_Rate=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,1))))];
        Mean_PreSleep_Superficial_Participation=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,1))))];
        Mean_PreSleep_Superficial_Firing_Rate=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,1))))];

        Mean_Run_Deep_Participation=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_All_Ripple_Participation(:,1,1))))];
        Mean_Run_Deep_Firing_Rate=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_All_Ripple_Participation(:,3,1))))];
        Mean_Run_Superficial_Participation=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_All_Ripple_Participation(:,2,1))))];
        Mean_Run_Superficial_Firing_Rate=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_All_Ripple_Participation(:,4,1))))];

        Mean_PostSleep_Deep_Participation=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,1))))];
        Mean_PostSleep_Deep_Firing_Rate=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,1))))];
        Mean_PostSleep_Superficial_Participation=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,1))))];
        Mean_PostSleep_Superficial_Firing_Rate=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,1))))];

        Large_Mean_PreSleep_Deep_Participation=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,1,2))))];
        Large_Mean_PreSleep_Deep_Firing_Rate=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,3,2))))];
        Large_Mean_PreSleep_Superficial_Participation=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,2,2))))];
        Large_Mean_PreSleep_Superficial_Firing_Rate=[mean(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan'),std(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_All_Ripple_Participation(:,4,2))))];

        Large_Mean_Run_Deep_Participation=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_All_Ripple_Participation(:,1,2))))];
        Large_Mean_Run_Deep_Firing_Rate=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_All_Ripple_Participation(:,3,2))))];
        Large_Mean_Run_Superficial_Participation=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_All_Ripple_Participation(:,2,2))))];
        Large_Mean_Run_Superficial_Firing_Rate=[mean(Run_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan'),std(Run_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_All_Ripple_Participation(:,4,2))))];

        Large_Mean_PostSleep_Deep_Participation=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,1,2))))];
        Large_Mean_PostSleep_Deep_Firing_Rate=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,3,2))))];
        Large_Mean_PostSleep_Superficial_Participation=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,2,2))))];
        Large_Mean_PostSleep_Superficial_Firing_Rate=[mean(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan'),std(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_All_Ripple_Participation(:,4,2))))];

        Mean_PreSleep_Deep_Participation_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1))))];
        Mean_PreSleep_Deep_Firing_Rate_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1))))];
        Mean_PreSleep_Superficial_Participation_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1))))];
        Mean_PreSleep_Superficial_Firing_Rate_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1))))];

        Mean_Run_Deep_Participation_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,1))))];
        Mean_Run_Deep_Firing_Rate_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,1))))];
        Mean_Run_Superficial_Participation_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,1))))];
        Mean_Run_Superficial_Firing_Rate_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,1))))];

        Mean_PostSleep_Deep_Participation_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,1))))];
        Mean_PostSleep_Deep_Firing_Rate_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,1))))];
        Mean_PostSleep_Superficial_Participation_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,1))))];
        Mean_PostSleep_Superficial_Firing_Rate_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,1))))];

        Large_Mean_PreSleep_Deep_Participation_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2))))];
        Large_Mean_PreSleep_Deep_Firing_Rate_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2))))];
        Large_Mean_PreSleep_Superficial_Participation_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2))))];
        Large_Mean_PreSleep_Superficial_Firing_Rate_Coherent=[mean(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan'),std(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2))))];

        Large_Mean_Run_Deep_Participation_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Coherent_Ripple_Participation(:,1,2))))];
        Large_Mean_Run_Deep_Firing_Rate_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Coherent_Ripple_Participation(:,3,2))))];
        Large_Mean_Run_Superficial_Participation_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Coherent_Ripple_Participation(:,2,2))))];
        Large_Mean_Run_Superficial_Firing_Rate_Coherent=[mean(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan'),std(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Coherent_Ripple_Participation(:,4,2))))];

        Large_Mean_PostSleep_Deep_Participation_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,1,2))))];
        Large_Mean_PostSleep_Deep_Firing_Rate_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,3,2))))];
        Large_Mean_PostSleep_Superficial_Participation_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,2,2))))];
        Large_Mean_PostSleep_Superficial_Firing_Rate_Coherent=[mean(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan'),std(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Coherent_Ripple_Participation(:,4,2))))];

        Mean_PreSleep_Deep_Participation_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1))))];
        Mean_PreSleep_Deep_Firing_Rate_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1))))];
        Mean_PreSleep_Superficial_Participation_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1))))];
        Mean_PreSleep_Superficial_Firing_Rate_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1))))];

        Mean_Run_Deep_Participation_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1))))];
        Mean_Run_Deep_Firing_Rate_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1))))];
        Mean_Run_Superficial_Participation_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1))))];
        Mean_Run_Superficial_Firing_Rate_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1))))];

        Mean_PostSleep_Deep_Participation_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,1))))];
        Mean_PostSleep_Deep_Firing_Rate_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,1))))];
        Mean_PostSleep_Superficial_Participation_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,1))))];
        Mean_PostSleep_Superficial_Firing_Rate_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,1))))];

        Large_Mean_PreSleep_Deep_Participation_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2))))];
        Large_Mean_PreSleep_Deep_Firing_Rate_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2))))];
        Large_Mean_PreSleep_Superficial_Participation_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2))))];
        Large_Mean_PreSleep_Superficial_Firing_Rate_Fragmented=[mean(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan'),std(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PreSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2))))];

        Large_Mean_Run_Deep_Participation_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2))))];
        Large_Mean_Run_Deep_Firing_Rate_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2))))];
        Large_Mean_Run_Superficial_Participation_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2))))];
        Large_Mean_Run_Superficial_Firing_Rate_Fragmented=[mean(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan'),std(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan')/sum(~isnan(size(Run_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2))))];

        Large_Mean_PostSleep_Deep_Participation_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,1,2))))];
        Large_Mean_PostSleep_Deep_Firing_Rate_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,3,2))))];
        Large_Mean_PostSleep_Superficial_Participation_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,2,2))))];
        Large_Mean_PostSleep_Superficial_Firing_Rate_Fragmented=[mean(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan'),std(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(PostSleep_Deep_Superficial_Fragmented_Ripple_Participation(:,4,2))))];

        if exist('All_Run_Deep_Superficial_Ripple_Participation','var')
            All_PreSleep_Deep_Superficial_Ripple_Participation=[All_PreSleep_Deep_Superficial_Ripple_Participation;PreSleep_Deep_Superficial_All_Ripple_Participation];
            All_Run_Deep_Superficial_Ripple_Participation=[All_Run_Deep_Superficial_Ripple_Participation;Run_Deep_Superficial_All_Ripple_Participation];
            All_PostSleep_Deep_Superficial_Ripple_Participation=[All_PostSleep_Deep_Superficial_Ripple_Participation;PostSleep_Deep_Superficial_All_Ripple_Participation];

            All_Mean_PreSleep_Deep_Participation=[All_Mean_PreSleep_Deep_Participation;Mean_PreSleep_Deep_Participation];
            All_Mean_PreSleep_Deep_Firing_Rate=[All_Mean_PreSleep_Deep_Firing_Rate;Mean_PreSleep_Deep_Firing_Rate];
            All_Mean_PreSleep_Superficial_Participation=[All_Mean_PreSleep_Superficial_Participation;Mean_PreSleep_Superficial_Participation];
            All_Mean_PreSleep_Superficial_Firing_Rate=[All_Mean_PreSleep_Superficial_Firing_Rate;Mean_PreSleep_Superficial_Firing_Rate];

            All_Mean_Run_Deep_Participation=[All_Mean_Run_Deep_Participation;Mean_Run_Deep_Participation];
            All_Mean_Run_Deep_Firing_Rate=[All_Mean_Run_Deep_Firing_Rate;Mean_Run_Deep_Firing_Rate];
            All_Mean_Run_Superficial_Participation=[All_Mean_Run_Superficial_Participation;Mean_Run_Superficial_Participation];
            All_Mean_Run_Superficial_Firing_Rate=[All_Mean_Run_Superficial_Firing_Rate;Mean_Run_Superficial_Firing_Rate];

            All_Mean_PostSleep_Deep_Participation=[All_Mean_PostSleep_Deep_Participation;Mean_PostSleep_Deep_Participation];
            All_Mean_PostSleep_Deep_Firing_Rate=[All_Mean_PostSleep_Deep_Firing_Rate;Mean_PostSleep_Deep_Firing_Rate];
            All_Mean_PostSleep_Superficial_Participation=[All_Mean_PostSleep_Superficial_Participation;Mean_PostSleep_Superficial_Participation];
            All_Mean_PostSleep_Superficial_Firing_Rate=[All_Mean_PostSleep_Superficial_Firing_Rate;Mean_PostSleep_Superficial_Firing_Rate];

            All_Large_Mean_PreSleep_Deep_Participation=[All_Large_Mean_PreSleep_Deep_Participation;Large_Mean_PreSleep_Deep_Participation];
            All_Large_Mean_PreSleep_Deep_Firing_Rate=[All_Large_Mean_PreSleep_Deep_Firing_Rate;Large_Mean_PreSleep_Deep_Firing_Rate];
            All_Large_Mean_PreSleep_Superficial_Participation=[All_Large_Mean_PreSleep_Superficial_Participation;Large_Mean_PreSleep_Superficial_Participation];
            All_Large_Mean_PreSleep_Superficial_Firing_Rate=[All_Large_Mean_PreSleep_Superficial_Firing_Rate;Large_Mean_PreSleep_Superficial_Firing_Rate];

            All_Large_Mean_Run_Deep_Participation=[All_Large_Mean_Run_Deep_Participation;Large_Mean_Run_Deep_Participation];
            All_Large_Mean_Run_Deep_Firing_Rate=[All_Large_Mean_Run_Deep_Firing_Rate;Large_Mean_Run_Deep_Firing_Rate];
            All_Large_Mean_Run_Superficial_Participation=[All_Large_Mean_Run_Superficial_Participation;Large_Mean_Run_Superficial_Participation];
            All_Large_Mean_Run_Superficial_Firing_Rate=[All_Large_Mean_Run_Superficial_Firing_Rate;Large_Mean_Run_Superficial_Firing_Rate];

            All_Large_Mean_PostSleep_Deep_Participation=[All_Large_Mean_PostSleep_Deep_Participation;Large_Mean_PostSleep_Deep_Participation];
            All_Large_Mean_PostSleep_Deep_Firing_Rate=[All_Large_Mean_PostSleep_Deep_Firing_Rate;Large_Mean_PostSleep_Deep_Firing_Rate];
            All_Large_Mean_PostSleep_Superficial_Participation=[All_Large_Mean_PostSleep_Superficial_Participation;Large_Mean_PostSleep_Superficial_Participation];
            All_Large_Mean_PostSleep_Superficial_Firing_Rate=[All_Large_Mean_PostSleep_Superficial_Firing_Rate;Large_Mean_PostSleep_Superficial_Firing_Rate];

            Coherent_PreSleep_Deep_Superficial_Ripple_Participation=[Coherent_PreSleep_Deep_Superficial_Ripple_Participation;PreSleep_Deep_Superficial_Coherent_Ripple_Participation];
            Coherent_Run_Deep_Superficial_Ripple_Participation=[Coherent_Run_Deep_Superficial_Ripple_Participation;Run_Deep_Superficial_Coherent_Ripple_Participation];
            Coherent_PostSleep_Deep_Superficial_Ripple_Participation=[Coherent_PostSleep_Deep_Superficial_Ripple_Participation;PostSleep_Deep_Superficial_Coherent_Ripple_Participation];

            Coherent_Mean_PreSleep_Deep_Participation=[Coherent_Mean_PreSleep_Deep_Participation;Mean_PreSleep_Deep_Participation_Coherent];
            Coherent_Mean_PreSleep_Deep_Firing_Rate=[Coherent_Mean_PreSleep_Deep_Firing_Rate;Mean_PreSleep_Deep_Firing_Rate_Coherent];
            Coherent_Mean_PreSleep_Superficial_Participation=[Coherent_Mean_PreSleep_Superficial_Participation;Mean_PreSleep_Superficial_Participation_Coherent];
            Coherent_Mean_PreSleep_Superficial_Firing_Rate=[Coherent_Mean_PreSleep_Superficial_Firing_Rate;Mean_PreSleep_Superficial_Firing_Rate_Coherent];

            Coherent_Mean_Run_Deep_Participation=[Coherent_Mean_Run_Deep_Participation;Mean_Run_Deep_Participation_Coherent];
            Coherent_Mean_Run_Deep_Firing_Rate=[Coherent_Mean_Run_Deep_Firing_Rate;Mean_Run_Deep_Firing_Rate_Coherent];
            Coherent_Mean_Run_Superficial_Participation=[Coherent_Mean_Run_Superficial_Participation;Mean_Run_Superficial_Participation_Coherent];
            Coherent_Mean_Run_Superficial_Firing_Rate=[Coherent_Mean_Run_Superficial_Firing_Rate;Mean_Run_Superficial_Firing_Rate_Coherent];

            Coherent_Mean_PostSleep_Deep_Participation=[Coherent_Mean_PostSleep_Deep_Participation;Mean_PostSleep_Deep_Participation_Coherent];
            Coherent_Mean_PostSleep_Deep_Firing_Rate=[Coherent_Mean_PostSleep_Deep_Firing_Rate;Mean_PostSleep_Deep_Firing_Rate_Coherent];
            Coherent_Mean_PostSleep_Superficial_Participation=[Coherent_Mean_PostSleep_Superficial_Participation;Mean_PostSleep_Superficial_Participation_Coherent];
            Coherent_Mean_PostSleep_Superficial_Firing_Rate=[Coherent_Mean_PostSleep_Superficial_Firing_Rate;Mean_PostSleep_Superficial_Firing_Rate_Coherent];

            Coherent_Large_Mean_PreSleep_Deep_Participation=[Coherent_Large_Mean_PreSleep_Deep_Participation;Large_Mean_PreSleep_Deep_Participation_Coherent];
            Coherent_Large_Mean_PreSleep_Deep_Firing_Rate=[Coherent_Large_Mean_PreSleep_Deep_Firing_Rate;Large_Mean_PreSleep_Deep_Firing_Rate_Coherent];
            Coherent_Large_Mean_PreSleep_Superficial_Participation=[Coherent_Large_Mean_PreSleep_Superficial_Participation;Large_Mean_PreSleep_Superficial_Participation_Coherent];
            Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate=[Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate;Large_Mean_PreSleep_Superficial_Firing_Rate_Coherent];

            Coherent_Large_Mean_Run_Deep_Participation=[Coherent_Large_Mean_Run_Deep_Participation;Large_Mean_Run_Deep_Participation_Coherent];
            Coherent_Large_Mean_Run_Deep_Firing_Rate=[Coherent_Large_Mean_Run_Deep_Firing_Rate;Large_Mean_Run_Deep_Firing_Rate_Coherent];
            Coherent_Large_Mean_Run_Superficial_Participation=[Coherent_Large_Mean_Run_Superficial_Participation;Large_Mean_Run_Superficial_Participation_Coherent];
            Coherent_Large_Mean_Run_Superficial_Firing_Rate=[Coherent_Large_Mean_Run_Superficial_Firing_Rate;Large_Mean_Run_Superficial_Firing_Rate_Coherent];

            Coherent_Large_Mean_PostSleep_Deep_Participation=[Coherent_Large_Mean_PostSleep_Deep_Participation;Large_Mean_PostSleep_Deep_Participation_Coherent];
            Coherent_Large_Mean_PostSleep_Deep_Firing_Rate=[Coherent_Large_Mean_PostSleep_Deep_Firing_Rate;Large_Mean_PostSleep_Deep_Firing_Rate_Coherent];
            Coherent_Large_Mean_PostSleep_Superficial_Participation=[Coherent_Large_Mean_PostSleep_Superficial_Participation;Large_Mean_PostSleep_Superficial_Participation_Coherent];
            Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate=[Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate;Large_Mean_PostSleep_Superficial_Firing_Rate_Coherent];

            Fragmented_PreSleep_Deep_Superficial_Ripple_Participation=[Fragmented_PreSleep_Deep_Superficial_Ripple_Participation;PreSleep_Deep_Superficial_Fragmented_Ripple_Participation];
            Fragmented_Run_Deep_Superficial_Ripple_Participation=[Fragmented_Run_Deep_Superficial_Ripple_Participation;Run_Deep_Superficial_Fragmented_Ripple_Participation];
            Fragmented_PostSleep_Deep_Superficial_Ripple_Participation=[Fragmented_PostSleep_Deep_Superficial_Ripple_Participation;PostSleep_Deep_Superficial_Fragmented_Ripple_Participation];

            Fragmented_Mean_PreSleep_Deep_Participation=[Fragmented_Mean_PreSleep_Deep_Participation;Mean_PreSleep_Deep_Participation_Fragmented];
            Fragmented_Mean_PreSleep_Deep_Firing_Rate=[Fragmented_Mean_PreSleep_Deep_Firing_Rate;Mean_PreSleep_Deep_Firing_Rate_Fragmented];
            Fragmented_Mean_PreSleep_Superficial_Participation=[Fragmented_Mean_PreSleep_Superficial_Participation;Mean_PreSleep_Superficial_Participation_Fragmented];
            Fragmented_Mean_PreSleep_Superficial_Firing_Rate=[Fragmented_Mean_PreSleep_Superficial_Firing_Rate;Mean_PreSleep_Superficial_Firing_Rate_Fragmented];

            Fragmented_Mean_Run_Deep_Participation=[Fragmented_Mean_Run_Deep_Participation;Mean_Run_Deep_Participation_Fragmented];
            Fragmented_Mean_Run_Deep_Firing_Rate=[Fragmented_Mean_Run_Deep_Firing_Rate;Mean_Run_Deep_Firing_Rate_Fragmented];
            Fragmented_Mean_Run_Superficial_Participation=[Fragmented_Mean_Run_Superficial_Participation;Mean_Run_Superficial_Participation_Fragmented];
            Fragmented_Mean_Run_Superficial_Firing_Rate=[Fragmented_Mean_Run_Superficial_Firing_Rate;Mean_Run_Superficial_Firing_Rate_Fragmented];

            Fragmented_Mean_PostSleep_Deep_Participation=[Fragmented_Mean_PostSleep_Deep_Participation;Mean_PostSleep_Deep_Participation_Fragmented];
            Fragmented_Mean_PostSleep_Deep_Firing_Rate=[Fragmented_Mean_PostSleep_Deep_Firing_Rate;Mean_PostSleep_Deep_Firing_Rate_Fragmented];
            Fragmented_Mean_PostSleep_Superficial_Participation=[Fragmented_Mean_PostSleep_Superficial_Participation;Mean_PostSleep_Superficial_Participation_Fragmented];
            Fragmented_Mean_PostSleep_Superficial_Firing_Rate=[Fragmented_Mean_PostSleep_Superficial_Firing_Rate;Mean_PostSleep_Superficial_Firing_Rate_Fragmented];

            Fragmented_Large_Mean_PreSleep_Deep_Participation=[Fragmented_Large_Mean_PreSleep_Deep_Participation;Large_Mean_PreSleep_Deep_Participation_Fragmented];
            Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate=[Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate;Large_Mean_PreSleep_Deep_Firing_Rate_Fragmented];
            Fragmented_Large_Mean_PreSleep_Superficial_Participation=[Fragmented_Large_Mean_PreSleep_Superficial_Participation;Large_Mean_PreSleep_Superficial_Participation_Fragmented];
            Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate=[Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate;Large_Mean_PreSleep_Superficial_Firing_Rate_Fragmented];

            Fragmented_Large_Mean_Run_Deep_Participation=[Fragmented_Large_Mean_Run_Deep_Participation;Large_Mean_Run_Deep_Participation_Fragmented];
            Fragmented_Large_Mean_Run_Deep_Firing_Rate=[Fragmented_Large_Mean_Run_Deep_Firing_Rate;Large_Mean_Run_Deep_Firing_Rate_Fragmented];
            Fragmented_Large_Mean_Run_Superficial_Participation=[Fragmented_Large_Mean_Run_Superficial_Participation;Large_Mean_Run_Superficial_Participation_Fragmented];
            Fragmented_Large_Mean_Run_Superficial_Firing_Rate=[Fragmented_Large_Mean_Run_Superficial_Firing_Rate;Large_Mean_Run_Superficial_Firing_Rate_Fragmented];

            Fragmented_Large_Mean_PostSleep_Deep_Participation=[Fragmented_Large_Mean_PostSleep_Deep_Participation;Large_Mean_PostSleep_Deep_Participation_Fragmented];
            Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate=[Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate;Large_Mean_PostSleep_Deep_Firing_Rate_Fragmented];
            Fragmented_Large_Mean_PostSleep_Superficial_Participation=[Fragmented_Large_Mean_PostSleep_Superficial_Participation;Large_Mean_PostSleep_Superficial_Participation_Fragmented];
            Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate=[Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate;Large_Mean_PostSleep_Superficial_Firing_Rate_Fragmented];

        else
            All_PreSleep_Deep_Superficial_Ripple_Participation=PreSleep_Deep_Superficial_All_Ripple_Participation;
            All_Run_Deep_Superficial_Ripple_Participation=Run_Deep_Superficial_All_Ripple_Participation;
            All_PostSleep_Deep_Superficial_Ripple_Participation=PostSleep_Deep_Superficial_All_Ripple_Participation;

            All_Mean_PreSleep_Deep_Participation=Mean_PreSleep_Deep_Participation;
            All_Mean_PreSleep_Deep_Firing_Rate=Mean_PreSleep_Deep_Firing_Rate;
            All_Mean_PreSleep_Superficial_Participation=Mean_PreSleep_Superficial_Participation;
            All_Mean_PreSleep_Superficial_Firing_Rate=Mean_PreSleep_Superficial_Firing_Rate;

            All_Mean_Run_Deep_Participation=Mean_Run_Deep_Participation;
            All_Mean_Run_Deep_Firing_Rate=Mean_Run_Deep_Firing_Rate;
            All_Mean_Run_Superficial_Participation=Mean_Run_Superficial_Participation;
            All_Mean_Run_Superficial_Firing_Rate=Mean_Run_Superficial_Firing_Rate;

            All_Mean_PostSleep_Deep_Participation=Mean_PostSleep_Deep_Participation;
            All_Mean_PostSleep_Deep_Firing_Rate=Mean_PostSleep_Deep_Firing_Rate;
            All_Mean_PostSleep_Superficial_Participation=Mean_PostSleep_Superficial_Participation;
            All_Mean_PostSleep_Superficial_Firing_Rate=Mean_PostSleep_Superficial_Firing_Rate;

            All_Large_Mean_PreSleep_Deep_Participation=Large_Mean_PreSleep_Deep_Participation;
            All_Large_Mean_PreSleep_Deep_Firing_Rate=Large_Mean_PreSleep_Deep_Firing_Rate;
            All_Large_Mean_PreSleep_Superficial_Participation=Large_Mean_PreSleep_Superficial_Participation;
            All_Large_Mean_PreSleep_Superficial_Firing_Rate=Large_Mean_PreSleep_Superficial_Firing_Rate;

            All_Large_Mean_Run_Deep_Participation=Large_Mean_Run_Deep_Participation;
            All_Large_Mean_Run_Deep_Firing_Rate=Large_Mean_Run_Deep_Firing_Rate;
            All_Large_Mean_Run_Superficial_Participation=Large_Mean_Run_Superficial_Participation;
            All_Large_Mean_Run_Superficial_Firing_Rate=Large_Mean_Run_Superficial_Firing_Rate;

            All_Large_Mean_PostSleep_Deep_Participation=Large_Mean_PostSleep_Deep_Participation;
            All_Large_Mean_PostSleep_Deep_Firing_Rate=Large_Mean_PostSleep_Deep_Firing_Rate;
            All_Large_Mean_PostSleep_Superficial_Participation=Large_Mean_PostSleep_Superficial_Participation;
            All_Large_Mean_PostSleep_Superficial_Firing_Rate=Large_Mean_PostSleep_Superficial_Firing_Rate;

            Coherent_PreSleep_Deep_Superficial_Ripple_Participation=PreSleep_Deep_Superficial_Coherent_Ripple_Participation;
            Coherent_Run_Deep_Superficial_Ripple_Participation=Run_Deep_Superficial_Coherent_Ripple_Participation;
            Coherent_PostSleep_Deep_Superficial_Ripple_Participation=PostSleep_Deep_Superficial_Coherent_Ripple_Participation;

            Coherent_Mean_PreSleep_Deep_Participation=Mean_PreSleep_Deep_Participation_Coherent;
            Coherent_Mean_PreSleep_Deep_Firing_Rate=Mean_PreSleep_Deep_Firing_Rate_Coherent;
            Coherent_Mean_PreSleep_Superficial_Participation=Mean_PreSleep_Superficial_Participation_Coherent;
            Coherent_Mean_PreSleep_Superficial_Firing_Rate=Mean_PreSleep_Superficial_Firing_Rate_Coherent;

            Coherent_Mean_Run_Deep_Participation=Mean_Run_Deep_Participation_Coherent;
            Coherent_Mean_Run_Deep_Firing_Rate=Mean_Run_Deep_Firing_Rate_Coherent;
            Coherent_Mean_Run_Superficial_Participation=Mean_Run_Superficial_Participation_Coherent;
            Coherent_Mean_Run_Superficial_Firing_Rate=Mean_Run_Superficial_Firing_Rate_Coherent;

            Coherent_Mean_PostSleep_Deep_Participation=Mean_PostSleep_Deep_Participation_Coherent;
            Coherent_Mean_PostSleep_Deep_Firing_Rate=Mean_PostSleep_Deep_Firing_Rate_Coherent;
            Coherent_Mean_PostSleep_Superficial_Participation=Mean_PostSleep_Superficial_Participation_Coherent;
            Coherent_Mean_PostSleep_Superficial_Firing_Rate=Mean_PostSleep_Superficial_Firing_Rate_Coherent;

            Coherent_Large_Mean_PreSleep_Deep_Participation=Large_Mean_PreSleep_Deep_Participation_Coherent;
            Coherent_Large_Mean_PreSleep_Deep_Firing_Rate=Large_Mean_PreSleep_Deep_Firing_Rate_Coherent;
            Coherent_Large_Mean_PreSleep_Superficial_Participation=Large_Mean_PreSleep_Superficial_Participation_Coherent;
            Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate=Large_Mean_PreSleep_Superficial_Firing_Rate_Coherent;

            Coherent_Large_Mean_Run_Deep_Participation=Large_Mean_Run_Deep_Participation_Coherent;
            Coherent_Large_Mean_Run_Deep_Firing_Rate=Large_Mean_Run_Deep_Firing_Rate_Coherent;
            Coherent_Large_Mean_Run_Superficial_Participation=Large_Mean_Run_Superficial_Participation_Coherent;
            Coherent_Large_Mean_Run_Superficial_Firing_Rate=Large_Mean_Run_Superficial_Firing_Rate_Coherent;

            Coherent_Large_Mean_PostSleep_Deep_Participation=Large_Mean_PostSleep_Deep_Participation_Coherent;
            Coherent_Large_Mean_PostSleep_Deep_Firing_Rate=Large_Mean_PostSleep_Deep_Firing_Rate_Coherent;
            Coherent_Large_Mean_PostSleep_Superficial_Participation=Large_Mean_PostSleep_Superficial_Participation_Coherent;
            Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate=Large_Mean_PostSleep_Superficial_Firing_Rate_Coherent;

            Fragmented_PreSleep_Deep_Superficial_Ripple_Participation=PreSleep_Deep_Superficial_Fragmented_Ripple_Participation;
            Fragmented_Run_Deep_Superficial_Ripple_Participation=Run_Deep_Superficial_Fragmented_Ripple_Participation;
            Fragmented_PostSleep_Deep_Superficial_Ripple_Participation=PostSleep_Deep_Superficial_Fragmented_Ripple_Participation;

            Fragmented_Mean_PreSleep_Deep_Participation=Mean_PreSleep_Deep_Participation_Fragmented;
            Fragmented_Mean_PreSleep_Deep_Firing_Rate=Mean_PreSleep_Deep_Firing_Rate_Fragmented;
            Fragmented_Mean_PreSleep_Superficial_Participation=Mean_PreSleep_Superficial_Participation_Fragmented;
            Fragmented_Mean_PreSleep_Superficial_Firing_Rate=Mean_PreSleep_Superficial_Firing_Rate_Fragmented;

            Fragmented_Mean_Run_Deep_Participation=Mean_Run_Deep_Participation_Fragmented;
            Fragmented_Mean_Run_Deep_Firing_Rate=Mean_Run_Deep_Firing_Rate_Fragmented;
            Fragmented_Mean_Run_Superficial_Participation=Mean_Run_Superficial_Participation_Fragmented;
            Fragmented_Mean_Run_Superficial_Firing_Rate=Mean_Run_Superficial_Firing_Rate_Fragmented;

            Fragmented_Mean_PostSleep_Deep_Participation=Mean_PostSleep_Deep_Participation_Fragmented;
            Fragmented_Mean_PostSleep_Deep_Firing_Rate=Mean_PostSleep_Deep_Firing_Rate_Fragmented;
            Fragmented_Mean_PostSleep_Superficial_Participation=Mean_PostSleep_Superficial_Participation_Fragmented;
            Fragmented_Mean_PostSleep_Superficial_Firing_Rate=Mean_PostSleep_Superficial_Firing_Rate_Fragmented;

            Fragmented_Large_Mean_PreSleep_Deep_Participation=Large_Mean_PreSleep_Deep_Participation_Fragmented;
            Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate=Large_Mean_PreSleep_Deep_Firing_Rate_Fragmented;
            Fragmented_Large_Mean_PreSleep_Superficial_Participation=Large_Mean_PreSleep_Superficial_Participation_Fragmented;
            Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate=Large_Mean_PreSleep_Superficial_Firing_Rate_Fragmented;

            Fragmented_Large_Mean_Run_Deep_Participation=Large_Mean_Run_Deep_Participation_Fragmented;
            Fragmented_Large_Mean_Run_Deep_Firing_Rate=Large_Mean_Run_Deep_Firing_Rate_Fragmented;
            Fragmented_Large_Mean_Run_Superficial_Participation=Large_Mean_Run_Superficial_Participation_Fragmented;
            Fragmented_Large_Mean_Run_Superficial_Firing_Rate=Large_Mean_Run_Superficial_Firing_Rate_Fragmented;

            Fragmented_Large_Mean_PostSleep_Deep_Participation=Large_Mean_PostSleep_Deep_Participation_Fragmented;
            Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate=Large_Mean_PostSleep_Deep_Firing_Rate_Fragmented;
            Fragmented_Large_Mean_PostSleep_Superficial_Participation=Large_Mean_PostSleep_Superficial_Participation_Fragmented;
            Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate=Large_Mean_PostSleep_Superficial_Firing_Rate_Fragmented;

        end

        cd ..

    end

    clear Directory

    cd ..

end

Per_Ripple_Mean_PreSleep_Deep_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Ripple_Mean_PreSleep_Deep_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Ripple_Mean_PreSleep_Superficial_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Ripple_Mean_PreSleep_Superficial_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Ripple_Mean_Run_Deep_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Ripple_Mean_Run_Deep_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Ripple_Mean_Run_Superficial_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Ripple_Mean_Run_Superficial_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Ripple_Mean_PostSleep_Deep_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Ripple_Mean_PostSleep_Deep_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Ripple_Mean_PostSleep_Superficial_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Ripple_Mean_PostSleep_Superficial_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Ripple_Large_Mean_PreSleep_Deep_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Ripple_Large_Mean_PreSleep_Superficial_Participation=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate=[mean(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Ripple_Large_Mean_Run_Deep_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Ripple_Large_Mean_Run_Deep_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Ripple_Large_Mean_Run_Superficial_Participation=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Ripple_Large_Mean_Run_Superficial_Firing_Rate=[mean(All_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(All_Run_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Ripple_Large_Mean_PostSleep_Deep_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Ripple_Large_Mean_PostSleep_Superficial_Participation=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate=[mean(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];


Per_Coherent_Ripple_Mean_PreSleep_Deep_Participation=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Coherent_Ripple_Mean_PreSleep_Deep_Firing_Rate=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Coherent_Ripple_Mean_PreSleep_Superficial_Participation=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Coherent_Ripple_Mean_PreSleep_Superficial_Firing_Rate=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Coherent_Ripple_Mean_Run_Deep_Participation=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Coherent_Ripple_Mean_Run_Deep_Firing_Rate=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Coherent_Ripple_Mean_Run_Superficial_Participation=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Coherent_Ripple_Mean_Run_Superficial_Firing_Rate=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Coherent_Ripple_Mean_PostSleep_Deep_Participation=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Coherent_Ripple_Mean_PostSleep_Deep_Firing_Rate=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Coherent_Ripple_Mean_PostSleep_Superficial_Participation=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Coherent_Ripple_Mean_PostSleep_Superficial_Firing_Rate=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate=[mean(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Coherent_Ripple_Large_Mean_Run_Deep_Participation=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Coherent_Ripple_Large_Mean_Run_Deep_Firing_Rate=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Coherent_Ripple_Large_Mean_Run_Superficial_Participation=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Coherent_Ripple_Large_Mean_Run_Superficial_Firing_Rate=[mean(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Coherent_Run_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate=[mean(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];


Per_Fragmented_Ripple_Mean_PreSleep_Deep_Participation=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Fragmented_Ripple_Mean_PreSleep_Deep_Firing_Rate=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Fragmented_Ripple_Mean_PreSleep_Superficial_Participation=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Fragmented_Ripple_Mean_PreSleep_Superficial_Firing_Rate=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Fragmented_Ripple_Mean_Run_Deep_Participation=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Fragmented_Ripple_Mean_Run_Deep_Firing_Rate=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Fragmented_Ripple_Mean_Run_Superficial_Participation=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Fragmented_Ripple_Mean_Run_Superficial_Firing_Rate=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Fragmented_Ripple_Mean_PostSleep_Deep_Participation=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,1))))];
Per_Fragmented_Ripple_Mean_PostSleep_Deep_Firing_Rate=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,1))))];
Per_Fragmented_Ripple_Mean_PostSleep_Superficial_Participation=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,1))))];
Per_Fragmented_Ripple_Mean_PostSleep_Superficial_Firing_Rate=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,1))))];

Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate=[mean(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Fragmented_Ripple_Large_Mean_Run_Deep_Participation=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Fragmented_Ripple_Large_Mean_Run_Deep_Firing_Rate=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Fragmented_Ripple_Large_Mean_Run_Superficial_Participation=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Fragmented_Ripple_Large_Mean_Run_Superficial_Firing_Rate=[mean(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Fragmented_Run_Deep_Superficial_Ripple_Participation(:,4,2))))];

Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2))))];
Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2))))];
Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2))))];
Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate=[mean(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan'),std(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),'omitnan')/sqrt(sum(~isnan(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2))))];


if isfolder('AllRatsCombined')
    cd AllRatsCombined
else
    mkdir('AllRatsCombined')
    cd AllRatsCombined
end

clear Rat
clear Rat_Name
clear Rats
clear Directory_Name
clear Experiment

save('All_Cell_Participation_Per_Ripple')

cd ..

if isfolder('_Figures')
    cd _Figures
else
    mkdir('_Figures')
    cd _Figures
end

if isfolder('PerRippleAnalysis')
    cd PerRippleAnalysis
else
    mkdir('PerRippleAnalysis')
    cd PerRippleAnalysis
end


%Plot the cell participation of large-amplitude-spike deep vs. superficial neurons when averaged across all ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1)],[Per_Ripple_Large_Mean_PreSleep_Deep_Participation(2),Per_Ripple_Large_Mean_PostSleep_Deep_Participation(2)]);
errorbar(1:2,[Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],[Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(2),Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1)-Per_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([1,1],[Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PreSleep_Deep_Participation(1)+Per_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1)-Per_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Ripple_Large_Mean_PostSleep_Deep_Participation(1)+Per_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)-Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)+Per_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)-Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)+Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Ripple_Large_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

ANOVA_Matrix=[[All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*3,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*4,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);


%Plot the participating large-amplitude-spikes cell firing rate of deep vs. superficial neurons when averaged across all ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)],[Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2),Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)]);
errorbar(1:2,[Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],[Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2),Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)-Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([1,1],[Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)+Per_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)-Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)+Per_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)-Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)+Per_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)-Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)+Per_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=9to13.5).jpg')
close

ANOVA_Matrix=[[All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*1,ones(length(All_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*3,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*4,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(All_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);
 


%Plot the cell participation of large-amplitude-spike deep vs. superficial neurons when averaged across coherent ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1)],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(2),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(2)]);
errorbar(1:2,[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(2),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1)-Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([1,1],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(1)+Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1)-Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(1)+Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)-Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)+Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)-Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)+Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Coherent_Ripple_Large_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

ANOVA_Matrix=[[Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2];[Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*3,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*2,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*4,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);


%Plot the participating large-amplitude-spikes cell firing rate of deep vs. superficial neurons when averaged across coherent ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)]);
errorbar(1:2,[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)-Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([1,1],[Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)+Per_Coherent_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)-Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)+Per_Coherent_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)-Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)+Per_Coherent_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)-Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)+Per_Coherent_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Coherent_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=9to13.5).jpg')
close

ANOVA_Matrix=[[Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*1,ones(length(Coherent_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2];[Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*3,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*2,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*4,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(Coherent_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);
 



%Plot the cell participation of large-amplitude-spike deep vs. superficial neurons when averaged across Fragmented ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1)],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(2),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(2)]);
errorbar(1:2,[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(2),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1)-Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([1,1],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(1)+Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1)-Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([2,2],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(1)+Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)-Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([4,4],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(1)+Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)-Per_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
plot([5,5],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(1)+Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Participation(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Fragmented_Ripple_Large_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

ANOVA_Matrix=[[Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2];[Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2),ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*3,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*2,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,1,2)),1)*1];[Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2),ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*4,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,2,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);


%Plot the participating large-amplitude-spikes cell firing rate of deep vs. superficial neurons when averaged across Fragmented ripples in all sessions (as if it were one giant recording session) 
figure;
hold on;
errorbar(1:2,[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)]);
errorbar(1:2,[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)]);
Y_Lim=ylim;
close;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([1,2,4,5],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,1],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)-Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([1,1],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(1)+Per_Fragmented_Ripple_Large_Mean_PreSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)-Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([2,2],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(1)+Per_Fragmented_Ripple_Large_Mean_PostSleep_Deep_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)-Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([4,4],[Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(1)+Per_Fragmented_Ripple_Large_Mean_PreSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)-Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
plot([5,5],[Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1),Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(1)+Per_Fragmented_Ripple_Large_Mean_PostSleep_Superficial_Firing_Rate(2)],'k','LineWidth',3);
set(gca,'XLim',[0 6]);
set(gca,'YLim',[Y_Lim(1) Y_Lim(2)]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
print('-djpeg','Per_Fragmented_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=9to13.5).jpg')
close

ANOVA_Matrix=[[Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*1,ones(length(Fragmented_PreSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2];[Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2),ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*3,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*2,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,3,2)),1)*1];[Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2),ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*4,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2,ones(length(Fragmented_PostSleep_Deep_Superficial_Ripple_Participation(:,4,2)),1)*2]];
figure;[P,Table,Stats]=anova1(ANOVA_Matrix(:,1),ANOVA_Matrix(:,2));
figure;C1=multcompare(Stats);
% figure;[P,Table,Stats]=anovan(ANOVA_Matrix(:,1),{ANOVA_Matrix(:,3),ANOVA_Matrix(:,4)});
% figure;C1=multcompare(Stats,"Dimension",[1,2]);
 





%Plot the cell participation of all large-amplitude-spike deep vs. superficial neurons when averaged per session
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[All_Large_Mean_PreSleep_Deep_Participation(N,1),All_Large_Mean_PostSleep_Deep_Participation(N,1)],[All_Large_Mean_PreSleep_Deep_Participation(N,2),All_Large_Mean_PostSleep_Deep_Participation(N,2)],'k');
    plot([1,2],[All_Large_Mean_PreSleep_Deep_Participation(N,1),All_Large_Mean_PostSleep_Deep_Participation(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[All_Large_Mean_PreSleep_Superficial_Participation(N,1),All_Large_Mean_PostSleep_Superficial_Participation(N,1)],[All_Large_Mean_PreSleep_Superficial_Participation(N,2),All_Large_Mean_PostSleep_Superficial_Participation(N,2)],'k');
    plot([4,5],[All_Large_Mean_PreSleep_Superficial_Participation(N,1),All_Large_Mean_PostSleep_Superficial_Participation(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(All_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],[std(All_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan')/sqrt(10),std(All_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(All_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(All_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],[std(All_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10),std(All_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(All_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Session_Per_Ripple_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(All_Large_Mean_PreSleep_Deep_Participation(:,1),All_Large_Mean_PostSleep_Deep_Participation(:,1))
[p,h]=signrank(All_Large_Mean_PreSleep_Superficial_Participation(:,1),All_Large_Mean_PostSleep_Superficial_Participation(:,1))

%Plot the firing rate of participating large-amplitude-spike cells of all deep vs. superficial neurons when averaged per session
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[All_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),All_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],[All_Large_Mean_PreSleep_Deep_Firing_Rate(N,2),All_Large_Mean_PostSleep_Deep_Firing_Rate(N,2)],'k');
    plot([1,2],[All_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),All_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[All_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),All_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],[All_Large_Mean_PreSleep_Superficial_Firing_Rate(N,2),All_Large_Mean_PostSleep_Superficial_Firing_Rate(N,2)],'k');
    plot([4,5],[All_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),All_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(All_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],[std(All_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10),std(All_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(All_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(All_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],[std(All_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10),std(All_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(All_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(All_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(All_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),All_Large_Mean_PostSleep_Deep_Firing_Rate(:,1))
[p,h]=signrank(All_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),All_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1))



%Plot the cell participation of all large-amplitude-spike deep vs. superficial neurons when averaged per session for only coherent ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[Coherent_Large_Mean_PreSleep_Deep_Participation(N,1),Coherent_Large_Mean_PostSleep_Deep_Participation(N,1)],[Coherent_Large_Mean_PreSleep_Deep_Participation(N,2),Coherent_Large_Mean_PostSleep_Deep_Participation(N,2)],'k');
    plot([1,2],[Coherent_Large_Mean_PreSleep_Deep_Participation(N,1),Coherent_Large_Mean_PostSleep_Deep_Participation(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[Coherent_Large_Mean_PreSleep_Superficial_Participation(N,1),Coherent_Large_Mean_PostSleep_Superficial_Participation(N,1)],[Coherent_Large_Mean_PreSleep_Superficial_Participation(N,2),Coherent_Large_Mean_PostSleep_Superficial_Participation(N,2)],'k');
    plot([4,5],[Coherent_Large_Mean_PreSleep_Superficial_Participation(N,1),Coherent_Large_Mean_PostSleep_Superficial_Participation(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(Coherent_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],[std(Coherent_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan')/sqrt(10),std(Coherent_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(Coherent_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(Coherent_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],[std(Coherent_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10),std(Coherent_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(Coherent_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Session_Per_Ripple_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(Coherent_Large_Mean_PreSleep_Deep_Participation(:,1),Coherent_Large_Mean_PostSleep_Deep_Participation(:,1))
[p,h]=signrank(Coherent_Large_Mean_PreSleep_Superficial_Participation(:,1),Coherent_Large_Mean_PostSleep_Superficial_Participation(:,1))

%Plot the firing rate of participating large-amplitude-spike cells of all deep vs. superficial neurons when averaged per session
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],[Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(N,2),Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(N,2)],'k');
    plot([1,2],[Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],[Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(N,2),Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(N,2)],'k');
    plot([4,5],[Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],[std(Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10),std(Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],[std(Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10),std(Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(Coherent_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),Coherent_Large_Mean_PostSleep_Deep_Firing_Rate(:,1))
[p,h]=signrank(Coherent_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),Coherent_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1))



%Plot the cell participation of all large-amplitude-spike deep vs. superficial neurons when averaged per session for only fragmented ripples
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[Fragmented_Large_Mean_PreSleep_Deep_Participation(N,1),Fragmented_Large_Mean_PostSleep_Deep_Participation(N,1)],[Fragmented_Large_Mean_PreSleep_Deep_Participation(N,2),Fragmented_Large_Mean_PostSleep_Deep_Participation(N,2)],'k');
    plot([1,2],[Fragmented_Large_Mean_PreSleep_Deep_Participation(N,1),Fragmented_Large_Mean_PostSleep_Deep_Participation(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[Fragmented_Large_Mean_PreSleep_Superficial_Participation(N,1),Fragmented_Large_Mean_PostSleep_Superficial_Participation(N,1)],[Fragmented_Large_Mean_PreSleep_Superficial_Participation(N,2),Fragmented_Large_Mean_PostSleep_Superficial_Participation(N,2)],'k');
    plot([4,5],[Fragmented_Large_Mean_PreSleep_Superficial_Participation(N,1),Fragmented_Large_Mean_PostSleep_Superficial_Participation(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(Fragmented_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],[std(Fragmented_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan')/sqrt(10),std(Fragmented_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(Fragmented_Large_Mean_PreSleep_Deep_Participation(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Deep_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(Fragmented_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],[std(Fragmented_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10),std(Fragmented_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(Fragmented_Large_Mean_PreSleep_Superficial_Participation(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Superficial_Participation(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Session_Per_Ripple_Cell_Participation_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(Fragmented_Large_Mean_PreSleep_Deep_Participation(:,1),Fragmented_Large_Mean_PostSleep_Deep_Participation(:,1))
[p,h]=signrank(Fragmented_Large_Mean_PreSleep_Superficial_Participation(:,1),Fragmented_Large_Mean_PostSleep_Superficial_Participation(:,1))

%Plot the firing rate of participating large-amplitude-spike cells of all deep vs. superficial neurons when averaged per session
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:10
    errorbar([1,2],[Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],[Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(N,2),Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(N,2)],'k');
    plot([1,2],[Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(N,1),Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
    errorbar([4,5],[Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],[Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(N,2),Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(N,2)],'k');
    plot([4,5],[Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(N,1),Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(N,1)],'ok','MarkerFaceColor','k');
end
errorbar([0.75 2.25],[mean(Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],[std(Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10),std(Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([0.75 2.25],[mean(Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
errorbar([3.75 5.25],[mean(Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],[std(Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10),std(Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')/sqrt(10)],'k','LineWidth',3);
plot([3.75 5.25],[mean(Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),'omitnan'),mean(Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1),'omitnan')],'sk','MarkerFaceColor','k','MarkerSize',15);
set(gca,'XLim',[0 6]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
print('-djpeg','Per_Ripple_Firing_Rate_Of_Participating_Large_Cells_In_Pre_Vs_Post_Ripples_For_Deep(left)_Vs_Superficial(right)_Cells(Y=0.16to0.2).jpg')
close

[p,h]=signrank(Fragmented_Large_Mean_PreSleep_Deep_Firing_Rate(:,1),Fragmented_Large_Mean_PostSleep_Deep_Firing_Rate(:,1))
[p,h]=signrank(Fragmented_Large_Mean_PreSleep_Superficial_Firing_Rate(:,1),Fragmented_Large_Mean_PostSleep_Superficial_Firing_Rate(:,1))

cd ..
cd ..


end



