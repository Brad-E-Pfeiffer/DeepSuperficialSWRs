function DSRP_DECODE_RIPPLE_EVENTS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the spike data associated with each ripple event and
% decodes the encoded spatial information.  The decoded data is saved for
% future analysis.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Ripple_Events','Ripple_Events')
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
load('Field_Data','Field_Data_Linear','Field_Data_Linear_In','Field_Data_Linear_Out')

% This truncates the Spike_Data to only excitatory neurons
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end
Cell_List=unique(Spike_Data(:,2));

% Because the decoding algorithm multiplies fields together for a
% part of the calculation, any field with a value of 0 prevents the
% algorithm from ever representing that location.  Therefore, I need to go
% through and replace all values of 0 with a very low, non-zero number.    
Field_Data_Linear2=Field_Data_Linear;
Field_Data_Linear_In2=Field_Data_Linear_In;
Field_Data_Linear_Out2=Field_Data_Linear_Out;
for N=1:size(Field_Data_Linear,2)
    Field=Field_Data_Linear(:,N);
    Field_In=Field_Data_Linear_In2(:,N);
    Field_Out=Field_Data_Linear_Out2(:,N);
    Minimum=min(Field(Field>0));
    Minimum_In=min(Field_In(Field_In>0));
    Minimum_Out=min(Field_Out(Field_Out>0));
    if ~isempty(Minimum)
        Field(Field<=0)=Minimum/10;
    else
        Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_In)
        Field_In(Field_In<=0)=Minimum_In/10;
    else
        Field_In(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    if ~isempty(Minimum_Out)
        Field_Out(Field_Out<=0)=Minimum_Out/10;
    else
        Field_Out(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
    end
    Field_Data_Linear2(:,N)=Field;
    Field_Data_Linear_In2(:,N)=Field_In;
    Field_Data_Linear_Out2(:,N)=Field_Out;
    clear Minimum;
    clear Minimum_In;
    clear Minimum_Out;
    clear Field;
    clear Field_In;
    clear Field_Out;
end
clear N;


Decoded_Linear_Ripple_Events=[];

for Current_Ripple=1:size(Ripple_Events,1)
    Event_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
    if ~isempty(Event_Spike_Data)
        
        %This decodes the raw data and finds the virtual step size across each pair of consecutive windows 
        [Decoded_Data_Total,Decoded_Data_In,Decoded_Data_Out]=DSRP_BAYESIAN_DECODING_LINEAR(Event_Spike_Data,Field_Data_Linear,Field_Data_Linear_In,Field_Data_Linear_Out,Field_Data_Linear2,Field_Data_Linear_In2,Field_Data_Linear_Out2,Initial_Variables);

        eval(sprintf('Decoded_Linear_Ripple_Events.Ripple_%d_Linear_Data=Decoded_Data_Total;',Current_Ripple));
        eval(sprintf('Decoded_Linear_Ripple_Events.Ripple_%d_Linear_Data_In=Decoded_Data_In;',Current_Ripple));
        eval(sprintf('Decoded_Linear_Ripple_Events.Ripple_%d_Linear_Data_Out=Decoded_Data_Out;',Current_Ripple));
    end
end
save('Decoded_Linear_Ripple_Events','Decoded_Linear_Ripple_Events','-v7.3');

clear Decoded_Data_Total;
clear Decoded_Data_In;
clear Decoded_Data_Out;

end