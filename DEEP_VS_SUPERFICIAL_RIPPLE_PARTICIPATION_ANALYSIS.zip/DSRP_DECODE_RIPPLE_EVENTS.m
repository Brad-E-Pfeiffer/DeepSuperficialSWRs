function DSRP_DECODE_RIPPLE_EVENTS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the spike data associated with each ripple event and
% decodes the encoded spatial information.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Ripple_Events','Ripple_Events')
load('Spike_Data','Spike_Data','Inhibitory_Neurons')
load('Field_Data','Field_Data')

% This truncates the Spike_Data to only excitatory neurons
for N=1:length(Inhibitory_Neurons)
    Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
end

Decoded_Ripple_Events=[];

for Current_Ripple=1:size(Ripple_Events,1)
    Event_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
    if ~isempty(Event_Spike_Data)
        
        %This decodes the raw data and finds the virtual step size across each pair of consecutive windows 
        if Initial_Variables.Use_Maximum_Posterior_Probability==1
            [Decoded_Sequence,Decoded_Data]=SGCO_BAYESIAN_DECODING_PEAK_POSTERIOR(Event_Spike_Data,Field_Data,Initial_Variables.Decoding_Time_Window,Initial_Variables.Decoding_Time_Advance);
        else
            [Decoded_Sequence,Decoded_Data]=SGCO_BAYESIAN_DECODING_WEIGHTED_MEAN(Event_Spike_Data,Field_Data,Initial_Variables.Decoding_Time_Window,Initial_Variables.Decoding_Time_Advance);
        end
        eval(sprintf('Decoded_Ripple_Events.Ripple_%d_Sequence=Decoded_Sequence;',Current_Ripple));
        eval(sprintf('Decoded_Ripple_Events.Ripple_%d_Data=Decoded_Data;',Current_Ripple));
    end
end
save('Decoded_Ripple_Events','Decoded_Ripple_Events','-v7.3');

end