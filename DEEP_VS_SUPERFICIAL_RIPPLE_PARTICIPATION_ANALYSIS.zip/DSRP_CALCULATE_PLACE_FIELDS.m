function DSRP_CALCULATE_PLACE_FIELDS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
% 
% This function calculates the locations within the behavioral arena or
% track where the neurons fire.  It will first calculate 2-dimensional
% place fields.  If the track is linear (Track_Type==1), the program will
% also calculate linear (uni-directional and bi-directional) place fields.
% 
% Bin_Size is the size (in cm) of the bins that are used to make the place
% fields.  Velocity_Cutoff is the velocity (in cm/sec) that the rat must be
% moving in order for the spikes to count toward place fields.
% Firing_Rate_Cutoff is the minimum peak firing rate (in Hz) that a cell
% must have to be considered to have a place field.  Otherwise, its place
% field is eliminated from future analysis.  Analyze_Linear (1 or 0) tells
% the program whether or not to calculate linear place fields (1=yes,0=no).
% 
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load('Experiment_Information','Track_Type');
load('Epochs','Run_Times')
load('Spike_Data_Integrated_With_Position','Spike_Data');
load('Position_Data','Position_Data')

%This removes spikes for which position information was not assigned
Spike_Data=Spike_Data(~isnan(Spike_Data(:,3)) & ~isnan(Spike_Data(:,4)) & ~isnan(Spike_Data(:,5)) & ~isnan(Spike_Data(:,6)),:);

%This limits analysis to the behavioral portions (excluding sleep box periods, only the first run portion is analyzed if there were more than one)
Run_Spike_Data=Spike_Data(Spike_Data(:,1)>=Run_Times(1,1) & Spike_Data(:,1)<=Run_Times(1,2),:);
Run_Position_Data=Position_Data(Position_Data(:,1)>=Run_Times(1,1) & Position_Data(:,1)<=Run_Times(1,2),:);
Original_Spike_Data=Spike_Data;
Spike_Data=Run_Spike_Data;
Position_Data=Run_Position_Data;
Spike_Data=Spike_Data(Spike_Data(:,1)>=min(Position_Data(:,1)) & Spike_Data(:,1)<=max(Position_Data(:,1)),:);

% This next section calculates the 2-dimensional place fields
Position_Data(:,2)=ceil(Position_Data(:,2)/Initial_Variables.Bin_Size);
Position_Data(:,3)=ceil(Position_Data(:,3)/Initial_Variables.Bin_Size);
if Track_Type==1  %finds the long axis of the track
    if (max(Position_Data(:,2))-min(Position_Data(:,2)))>(max(Position_Data(:,3))-min(Position_Data(:,3)))
        Position_Data(:,4)=Position_Data(:,2);
    else
        Position_Data(:,4)=Position_Data(:,3);
    end
end
Position_Data(:,5)=DSRP_CALCULATE_VELOCITY(Position_Data);

%This calculates the movement direction for linear track experiments, which is used to calculate directional place fields below 
if Track_Type==1
    Position_Data(1:end-1,6)=diff(Position_Data(:,4));
    Position_Data(end,6)=Position_Data(end-1,6);
    Position_Data(:,6)=filtfilt(fspecial('gaussian',[20 1],2),1,Position_Data(:,6));
    Position_Data(:,6)=sign(Position_Data(:,6));
    if Position_Data(1,6)==0
        Position_Data(1,6)=Position_Data(find(Position_Data(:,6)~=0,1,'first'),6);
    end
    for N=2:size(Position_Data,1)
        if Position_Data(N,6)==0
            Position_Data(N,6)=Position_Data(N-1,6);
        end
    end
    Spike_Data(:,7)=interp1(Position_Data(:,1),Position_Data(:,6),Spike_Data(:,1),'nearest');
end

% Here, the time spent in each position bin is calculated.  I use the
% position data rather than the spike data for this purpose because the
% position data is acquired on a regular frequency, whereas the spike occur
% irregularly.  Therefore, if I didn't record from a large number of
% cells, the rat's apparent position occupancy could be skewed if I used
% the spike data for this calculation.  This uses the same calculations as
% in the function SRS_SPIKE_POSITION_INTEGRATION.
Time_Change=diff(Position_Data(:,1));
Time_Change(end+1)=Time_Change(end);
Time_Change(Time_Change>(10*median(Time_Change)))=median(Time_Change); %This removes large time jumps (from sleep sessions)
%[FilterA,FilterB]=butter(2,0.02);
%Time_Change=filtfilt(FilterA,FilterB,Time_Change);
Time_Change(Time_Change<=0)=min(Time_Change(Time_Change>0))/10;

% This eliminates all position and spike data where the rat was moving
% slower than the Velocity_Cutoff. I then bin the position information.
Index=Position_Data(:,5)>=Initial_Variables.Velocity_Cutoff;
Position_Data=Position_Data(Index,:);
Time_Change=Time_Change(Index,:);
Index=Spike_Data(:,6)>=Initial_Variables.Velocity_Cutoff;
Spike_Data=Spike_Data(Index,:);
clear Index;

% Here, the total time spent moving in each position bin is calculated
Time_In_Position=zeros(max([max(Position_Data(:,3)),max(Spike_Data(:,4))]),max([max(Position_Data(:,2)),max(Spike_Data(:,3))]));
for N=1:size(Position_Data,1)
    Time_In_Position(Position_Data(N,3),Position_Data(N,2))=Time_In_Position(Position_Data(N,3),Position_Data(N,2))+Time_Change(N,1);
end

% Here, the number of spikes in each position bin is calculated for each cell
Spikes_In_Position=zeros(max([max(Position_Data(:,3)),max(Spike_Data(:,4))]),max([max(Position_Data(:,2)),max(Spike_Data(:,3))]),max(Original_Spike_Data(:,2)));
for N=1:size(Spike_Data,1)
    Spikes_In_Position(Spike_Data(N,4),Spike_Data(N,3),Spike_Data(N,2))=Spikes_In_Position(Spike_Data(N,4),Spike_Data(N,3),Spike_Data(N,2))+1;
end

% Here, I calculate the actual firing rate (spikes/time) and save it as Field_Data
Firing_Rate_In_Position=zeros(size(Spikes_In_Position,1),size(Spikes_In_Position,2),size(Spikes_In_Position,3));
for N=1:size(Spikes_In_Position,3)
    Firing_Rate_In_Position(:,:,N)=Spikes_In_Position(:,:,N)./Time_In_Position;
end
Firing_Rate_In_Position(isnan(Firing_Rate_In_Position))=0;
Firing_Rate_In_Position(isinf(Firing_Rate_In_Position))=0;
Smoothed_Firing_Rate=Firing_Rate_In_Position;
Two_D_Filter=fspecial('gaussian',[20 20],2);  %This is a gaussian filter with a kernel St. Dev. of 2 bins (4 cm) that filters out to 10 bins in all directions (20 cm)
for N=1:size(Firing_Rate_In_Position,3)
    Smoothed_Firing_Rate(:,:,N)=filter2(Two_D_Filter,Firing_Rate_In_Position(:,:,N));
end
Smoothed_Firing_Rate(isnan(Smoothed_Firing_Rate))=0;
Smoothed_Firing_Rate(Smoothed_Firing_Rate<0)=0;
for Z=1:size(Smoothed_Firing_Rate,3)
    % This eliminates fields with a peak firing rate beneath the cutoff defined above.
    if max(max(max(Smoothed_Firing_Rate(:,:,Z))))<Initial_Variables.Place_Field_Firing_Rate_Cutoff
        Smoothed_Firing_Rate(:,:,Z)=0;
    end
end
Field_Data=Smoothed_Firing_Rate;
save('Field_Data','Field_Data')

%In the next section, I calculate linear place fields.  

% Here, I calculate bi-directional fields.
Linear_Time_In_Position=zeros(max(Position_Data(:,4)),1);
for N=1:size(Position_Data,1)
    Linear_Time_In_Position(Position_Data(N,4),1)=Linear_Time_In_Position(Position_Data(N,4),1)+Time_Change(N,1);
end
Linear_Spikes_In_Position=zeros(max(Position_Data(:,4)),max(Original_Spike_Data(:,2)));
for N=1:size(Spike_Data,1)
    Linear_Spikes_In_Position(Spike_Data(N,5),Spike_Data(N,2))=Linear_Spikes_In_Position(Spike_Data(N,5),Spike_Data(N,2))+1;
end
Linear_Rate_In_Position=zeros(size(Linear_Spikes_In_Position,1),size(Linear_Spikes_In_Position,2));
for N=1:size(Linear_Spikes_In_Position,2)
    Linear_Rate_In_Position(:,N)=Linear_Spikes_In_Position(:,N)./Linear_Time_In_Position;
end
Linear_Rate_In_Position(isnan(Linear_Rate_In_Position))=0;
Linear_Rate_In_Position(isinf(Linear_Rate_In_Position))=0;
Smoothed_Linear_Firing_Rate=Linear_Rate_In_Position;
Filter=fspecial('gaussian',[20 1],2); %This filter smoothes the firing rates with a gaussian kernel with a St.Dev. of 2 bins (4cm), out to 10 bins on either side (20cm)
for N=1:size(Linear_Rate_In_Position,2)
    Smoothed_Linear_Firing_Rate(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position(:,N));
end
Smoothed_Linear_Firing_Rate(isnan(Smoothed_Linear_Firing_Rate))=0;
Smoothed_Linear_Firing_Rate(Smoothed_Linear_Firing_Rate<0)=0;
for Z=1:size(Smoothed_Linear_Firing_Rate,2)
    if max(max(max(Smoothed_Linear_Firing_Rate(:,Z))))<Initial_Variables.Place_Field_Firing_Rate_Cutoff
        Smoothed_Linear_Firing_Rate(:,Z)=0;
    end
end
Field_Data_Linear=Smoothed_Linear_Firing_Rate;

% Here, I calculate uni-directional fields.
Linear_Time_In_Position_Out=zeros(max(Position_Data(:,4)),1);
Linear_Time_In_Position_In=zeros(max(Position_Data(:,4)),1);
for N=1:size(Position_Data,1)
    if Position_Data(N,6)==-1
        Linear_Time_In_Position_Out(Position_Data(N,4),1)=Linear_Time_In_Position_Out(Position_Data(N,4),1)+Time_Change(N,1);
    elseif Position_Data(N,6)==1
        Linear_Time_In_Position_In(Position_Data(N,4),1)=Linear_Time_In_Position_In(Position_Data(N,4),1)+Time_Change(N,1);
    end
end
Linear_Spikes_In_Position_Out=zeros(max(Position_Data(:,4)),max(Original_Spike_Data(:,2)));
Linear_Spikes_In_Position_In=zeros(max(Position_Data(:,4)),max(Original_Spike_Data(:,2)));
for N=1:size(Spike_Data,1)
    if Spike_Data(N,7)==-1
        Linear_Spikes_In_Position_Out(Spike_Data(N,5),Spike_Data(N,2))=Linear_Spikes_In_Position_Out(Spike_Data(N,5),Spike_Data(N,2))+1;
    elseif Spike_Data(N,7)==1
        Linear_Spikes_In_Position_In(Spike_Data(N,5),Spike_Data(N,2))=Linear_Spikes_In_Position_In(Spike_Data(N,5),Spike_Data(N,2))+1;
    end
end
for N=1:size(Linear_Spikes_In_Position_Out,2)
    Linear_Rate_In_Position_Out(:,N)=Linear_Spikes_In_Position_Out(:,N)./Linear_Time_In_Position_Out;
    Linear_Rate_In_Position_In(:,N)=Linear_Spikes_In_Position_In(:,N)./Linear_Time_In_Position_In;
end
Linear_Rate_In_Position_Out(isnan(Linear_Rate_In_Position_Out))=0;
Linear_Rate_In_Position_Out(isinf(Linear_Rate_In_Position_Out))=0;
Linear_Rate_In_Position_In(isnan(Linear_Rate_In_Position_In))=0;
Linear_Rate_In_Position_In(isinf(Linear_Rate_In_Position_In))=0;
Smoothed_Linear_Firing_Rate_Out=Linear_Rate_In_Position_Out;
Smoothed_Linear_Firing_Rate_In=Linear_Rate_In_Position_In;
for N=1:size(Linear_Rate_In_Position_Out,2)
    Smoothed_Linear_Firing_Rate_Out(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position_Out(:,N));
    Smoothed_Linear_Firing_Rate_In(:,N)=filtfilt(Filter,1,Linear_Rate_In_Position_In(:,N));
end
Smoothed_Linear_Firing_Rate_Out(isnan(Smoothed_Linear_Firing_Rate_Out))=0;
Smoothed_Linear_Firing_Rate_Out(Smoothed_Linear_Firing_Rate_Out<0)=0;
Smoothed_Linear_Firing_Rate_In(isnan(Smoothed_Linear_Firing_Rate_In))=0;
Smoothed_Linear_Firing_Rate_In(Smoothed_Linear_Firing_Rate_In<0)=0;
for Z=1:size(Smoothed_Linear_Firing_Rate_Out,2)
    if max(max(max(Smoothed_Linear_Firing_Rate_Out(:,Z))))<Initial_Variables.Place_Field_Firing_Rate_Cutoff
        Smoothed_Linear_Firing_Rate_Out(:,Z)=0;
    end
    if max(max(max(Smoothed_Linear_Firing_Rate_In(:,Z))))<Initial_Variables.Place_Field_Firing_Rate_Cutoff
        Smoothed_Linear_Firing_Rate_In(:,Z)=0;
    end
end
Field_Data_Linear_Out=Smoothed_Linear_Firing_Rate_Out;
Field_Data_Linear_In=Smoothed_Linear_Firing_Rate_In;

% I now find the bins that contain the maximum firing rates and create a
% variable that allows the spike data to be plotted according to place
% field peak. The first column is the cell number, the second column is the
% peak bin for bi-directional fields, the third column is the peak bin for
% the out direction, and the fourth column is the peak bin for the in
% direction.
Firing_Rate_Peaks=zeros(max(Spike_Data(:,2)),4);
Firing_Rate_Peaks(:,1)=1:max(Spike_Data(:,2));
for N=1:size(Firing_Rate_Peaks)
    if max(Field_Data_Linear(:,N))>0
        Firing_Rate_Peaks(N,2)=find(Field_Data_Linear(:,N)==max(Field_Data_Linear(:,N)),1,'first');
    else
        Firing_Rate_Peaks(N,2)=0;
    end
    if max(Field_Data_Linear_Out(:,N))>0
        Firing_Rate_Peaks(N,3)=find(Field_Data_Linear_Out(:,N)==max(Field_Data_Linear_Out(:,N)),1,'first');
    else
        Firing_Rate_Peaks(N,3)=0;
    end
    if max(Field_Data_Linear_In(:,N))>0
        Firing_Rate_Peaks(N,4)=find(Field_Data_Linear_In(:,N)==max(Field_Data_Linear_In(:,N)),1,'first');
    else
        Firing_Rate_Peaks(N,4)=0;
    end
end

save('Field_Data','Field_Data','Field_Data_Linear','Field_Data_Linear_Out','Field_Data_Linear_In','Firing_Rate_Peaks')

end