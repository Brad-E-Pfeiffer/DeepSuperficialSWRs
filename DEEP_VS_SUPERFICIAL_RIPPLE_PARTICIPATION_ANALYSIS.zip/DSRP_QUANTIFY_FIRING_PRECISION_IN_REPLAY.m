function DSRP_QUANTIFY_FIRING_PRECISION_IN_REPLAY(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up each ripple and decodes the content.  Then, for
% each cell, it quantifies the distance from the peak decoded location and
% the peak of the cell's place field.  This is the "precision" of that cell
% (should probably be called "accuracy" to be semantically correct).  Each
% cell that fired in a given ripple has this value quantified.  If a cell
% fired more than one spike, the decoding precision is averaged for that
% ripple. 
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        if 1%~isfile('Ripple_Cell_Firing_Precision.mat')

            disp('==========================================================================');
            disp(sprintf('Starting Quantification of Firing Precision in Replay for Rat: %s, Session: %s.',Rat_Name,Directory_Name));

            load('Ripple_Events','Ripple_Events')
            load('Spike_Data','Spike_Data','Inhibitory_Neurons')
            load('Field_Data','Field_Data_Linear')
            load('Coherent_Fragmented_Ripples','Coherent_Fragmented_Ripples')
            Ripple_Cell_Firing_Precision=zeros(size(Ripple_Events,1),max(Spike_Data(:,2)));
            Ripple_Cell_Spikes_Per_Decoding_Window=zeros(size(Ripple_Events,1),max(Spike_Data(:,2)));
            Ripple_Cell_Firing_Precision(:,:)=NaN;
            Ripple_Cell_Spikes_Per_Decoding_Window(:,:)=NaN;
            for N=1:length(Inhibitory_Neurons)
                Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
            end

            % Because the decoding algorithm multiplies fields together for a
            % part of the calculation, any field with a value of 0 prevents the
            % algorithm from ever representing that location.  Therefore, I need to go
            % through and replace all values of 0 with a very low, non-zero number.
            Field_Data_Linear2=Field_Data_Linear;
            for N=1:size(Field_Data_Linear,2)
                Field=Field_Data_Linear(:,N);
                Minimum=min(Field(Field>0));
                if ~isempty(Minimum)
                    Field(Field<=0)=Minimum/10;
                else
                    Field(:)=1;  % If a neuron has a firing rate of 0 throughout the entire environment, I change it to 1 to effectively eliminate it from the product analysis.
                end
                Field_Data_Linear2(:,N)=Field;
                clear Minimum;
                clear Field;
            end
            clear N;

            for Current_Ripple=1:size(Ripple_Events,1)
                Event_Spike_Data=Spike_Data(Spike_Data(:,1)>=Ripple_Events(Current_Ripple,1) & Spike_Data(:,1)<=Ripple_Events(Current_Ripple,2),:);
                if ~isempty(Event_Spike_Data)

                    Start_Time=min(Event_Spike_Data(:,1));
                    End_Time=max(Event_Spike_Data(:,1));

                    % Here is where the decoding actual happens
                    Current_Ripple_Cell_Firing_Precision=zeros(2,max(Spike_Data(:,2)));
                    Current_Ripple_Cell_Firing_Precision(:,:)=NaN;
                    while Start_Time<=End_Time
                        Subset_Spike_Data=Event_Spike_Data(Event_Spike_Data(:,1)>=Start_Time & Event_Spike_Data(:,1)<(Start_Time+Initial_Variables.Decoding_Time_Window),:);
                        if ~isempty(Subset_Spike_Data)
                            Decoded_Matrix=prod(Field_Data_Linear2(:,Subset_Spike_Data(:,2)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum(Field_Data_Linear,2));
                            if isinf(max(max(Decoded_Matrix))) %If the max posterior probability is infinite (which happens if too many spikes are in the decoding window because Matlab can't store exceedingly large values), I iteratively decrease the place field firing rates equally until I get a value that is non-infinite.
                                Divider=1;
                                while isinf(max(max(Decoded_Matrix)))
                                    Decoded_Matrix=prod((Field_Data_Linear2(:,Subset_Spike_Data(:,2))/(2^Divider)),2).*exp(-Initial_Variables.Decoding_Time_Window*sum((Field_Data_Linear/(2^Divider)),2));
                                    Divider=Divider+1;
                                end
                                clear Divider;
                            end
                            Decoded_Matrix(Decoded_Matrix<0)=0;
                            if max(Decoded_Matrix)>0
                                Decoded_Matrix=Decoded_Matrix/sum(Decoded_Matrix);
                            end
                            if max(Decoded_Matrix)>0
                                [~,Decoded_Location]=max(Decoded_Matrix);
                            end
                            for Current_Spike=1:size(Subset_Spike_Data,1)
                                Current_Cell=Subset_Spike_Data(Current_Spike,2);
                                if max(Field_Data_Linear(:,Current_Cell))>0
                                    [~,Place_Field_Peak_Location]=max(Field_Data_Linear(:,Current_Cell));
                                    Current_Ripple_Cell_Firing_Precision(1,Current_Cell)=max([abs(Place_Field_Peak_Location-Decoded_Location),Current_Ripple_Cell_Firing_Precision(1,Current_Cell)+abs(Place_Field_Peak_Location-Decoded_Location)]);
                                    Current_Ripple_Cell_Firing_Precision(2,Current_Cell)=max([1,Current_Ripple_Cell_Firing_Precision(2,Current_Cell)+1]);
                                end
                            end
                        end
                        Start_Time=Start_Time+Initial_Variables.Decoding_Time_Advance;
                    end

                    Ripple_Cell_Firing_Precision(Current_Ripple,:)=Current_Ripple_Cell_Firing_Precision(1,:)./Current_Ripple_Cell_Firing_Precision(2,:);

                    % Here is where the number of spikes per decoding window is calculated 
                    Current_Ripple_Cell_Spikes_Per_Decoding_Window=zeros(2,max(Spike_Data(:,2)));
                    Current_Ripple_Cell_Spikes_Per_Decoding_Window(:,:)=NaN;
                    Start_Time=min(Event_Spike_Data(:,1));
                    while Start_Time<=End_Time
                        Subset_Spike_Data=Event_Spike_Data(Event_Spike_Data(:,1)>=Start_Time & Event_Spike_Data(:,1)<(Start_Time+Initial_Variables.Decoding_Time_Window),:);
                        if ~isempty(Subset_Spike_Data)
                            Unique_Cell_List=unique(Subset_Spike_Data(:,2));
                            for Current_Cell=1:length(Unique_Cell_List)
                                Current_Cell_Count=sum(Subset_Spike_Data(:,2)==Current_Cell);
                                Current_Ripple_Cell_Spikes_Per_Decoding_Window(1,Current_Cell)=max([Current_Cell_Count,Current_Ripple_Cell_Spikes_Per_Decoding_Window(1,Current_Cell)+Current_Cell_Count]);
                                Current_Ripple_Cell_Spikes_Per_Decoding_Window(2,Current_Cell)=max([1,Current_Ripple_Cell_Spikes_Per_Decoding_Window(2,Current_Cell)+1]);
                            end
                        end
                        Start_Time=Start_Time+Initial_Variables.Decoding_Time_Advance;
                    end

                    Ripple_Cell_Spikes_Per_Decoding_Window(Current_Ripple,:)=Current_Ripple_Cell_Spikes_Per_Decoding_Window(1,:)./Current_Ripple_Cell_Spikes_Per_Decoding_Window(2,:);

                end
            end

            save('Ripple_Cell_Firing_Precision','Ripple_Cell_Firing_Precision','Ripple_Cell_Spikes_Per_Decoding_Window')

            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        end

        cd ..

    end

    clear Directory

    cd ..

end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables



% Here, the data above is split by cell type (deep vs. superficial),
% ripple type (coherent vs. fragmented), and epoch (pre/ontask/post,
% sleep/wake)

% Per_Deep/Super/LargeDeep/LargeSuper_Cell_Firing_Precision (All values are measures of "precision" in SWRs: the distance between decoding peak and place field peak)
% Page 1 is Sleep and Wake Combined, Page 2 is Sleep Only, Page 3 is Wake Only
% |    1    |     2   |        3     |         4      |      5     |        6        |          7        |      8   |       9       |        10       ||
% | Cell ID | All Pre | Coherent Pre | Fragmented Pre | All OnTask | Coherent OnTask | Fragmented OnTask | All Post | Coherent Post | Fragmented Post ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Ripple_Cell_Firing_Precision','Ripple_Cell_Firing_Precision','Ripple_Cell_Spikes_Per_Decoding_Window');
        load('Deep_And_Superficial_Cell_Identities','Deep_Cells','Superficial_Cells','Large_Deep_Cells','Large_Superficial_Cells');
        load('Ripple_Categories','Ripple_Categories');
        Super_Cells=Superficial_Cells;
        Large_Super_Cells=Large_Superficial_Cells;

        % Deep Cells

        Pre_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1,Deep_Cells),1,'omitnan')';
        Pre_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Pre_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        OnTask_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2,Deep_Cells),1,'omitnan')';
        OnTask_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        OnTask_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        Post_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3,Deep_Cells),1,'omitnan')';
        Post_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Post_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';

        Per_Deep_Cell_Firing_Precision=[Deep_Cells,Pre_Deep_All_Ripples_Firing_Precision,Pre_Deep_Coherent_Ripples_Firing_Precision,Pre_Deep_Fragmented_Ripples_Firing_Precision,OnTask_Deep_All_Ripples_Firing_Precision,OnTask_Deep_Coherent_Ripples_Firing_Precision,OnTask_Deep_Fragmented_Ripples_Firing_Precision,Post_Deep_All_Ripples_Firing_Precision,Post_Deep_Coherent_Ripples_Firing_Precision,Post_Deep_Fragmented_Ripples_Firing_Precision];

        Pre_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1,Deep_Cells),1,'omitnan')';
        Pre_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Pre_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        OnTask_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2,Deep_Cells),1,'omitnan')';
        OnTask_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        OnTask_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        Post_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3,Deep_Cells),1,'omitnan')';
        Post_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Post_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';

        Per_Deep_Cell_Spikes_Per_Decoding_Window=[Deep_Cells,Pre_Deep_All_Ripples_Spikes_Per_Decoding_Window,Pre_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,Pre_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window,OnTask_Deep_All_Ripples_Spikes_Per_Decoding_Window,OnTask_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,OnTask_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window,Post_Deep_All_Ripples_Spikes_Per_Decoding_Window,Post_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,Post_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window];

        Pre_Sleep_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1,Deep_Cells),1,'omitnan')';
        Pre_Sleep_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Pre_Sleep_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        Post_Sleep_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3,Deep_Cells),1,'omitnan')';
        Post_Sleep_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Post_Sleep_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';

        Per_Deep_Cell_Firing_Precision(:,:,2)=[Deep_Cells,Pre_Sleep_Deep_All_Ripples_Firing_Precision,Pre_Sleep_Deep_Coherent_Ripples_Firing_Precision,Pre_Sleep_Deep_Fragmented_Ripples_Firing_Precision,zeros(length(Deep_Cells),3),Post_Sleep_Deep_All_Ripples_Firing_Precision,Post_Sleep_Deep_Coherent_Ripples_Firing_Precision,Post_Sleep_Deep_Fragmented_Ripples_Firing_Precision];

        Pre_Awake_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1,Deep_Cells),1,'omitnan')';
        Pre_Awake_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Pre_Awake_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';
        Post_Awake_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3,Deep_Cells),1,'omitnan')';
        Post_Awake_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Deep_Cells),1,'omitnan')';
        Post_Awake_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Deep_Cells),1,'omitnan')';

        Per_Deep_Cell_Firing_Precision(:,:,3)=[Deep_Cells,Pre_Awake_Deep_All_Ripples_Firing_Precision,Pre_Awake_Deep_Coherent_Ripples_Firing_Precision,Pre_Awake_Deep_Fragmented_Ripples_Firing_Precision,zeros(length(Deep_Cells),3),Post_Awake_Deep_All_Ripples_Firing_Precision,Post_Awake_Deep_Coherent_Ripples_Firing_Precision,Post_Awake_Deep_Fragmented_Ripples_Firing_Precision];

        % Superficial Cells

        Pre_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1,Super_Cells),1,'omitnan')';
        Pre_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Pre_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        OnTask_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2,Super_Cells),1,'omitnan')';
        OnTask_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        OnTask_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        Post_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3,Super_Cells),1,'omitnan')';
        Post_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Post_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';

        Per_Super_Cell_Firing_Precision=[Super_Cells,Pre_Super_All_Ripples_Firing_Precision,Pre_Super_Coherent_Ripples_Firing_Precision,Pre_Super_Fragmented_Ripples_Firing_Precision,OnTask_Super_All_Ripples_Firing_Precision,OnTask_Super_Coherent_Ripples_Firing_Precision,OnTask_Super_Fragmented_Ripples_Firing_Precision,Post_Super_All_Ripples_Firing_Precision,Post_Super_Coherent_Ripples_Firing_Precision,Post_Super_Fragmented_Ripples_Firing_Precision];

        Pre_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1,Super_Cells),1,'omitnan')';
        Pre_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Pre_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        OnTask_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2,Super_Cells),1,'omitnan')';
        OnTask_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        OnTask_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        Post_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3,Super_Cells),1,'omitnan')';
        Post_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Post_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';

        Per_Super_Cell_Spikes_Per_Decoding_Window=[Super_Cells,Pre_Super_All_Ripples_Spikes_Per_Decoding_Window,Pre_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,Pre_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window,OnTask_Super_All_Ripples_Spikes_Per_Decoding_Window,OnTask_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,OnTask_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window,Post_Super_All_Ripples_Spikes_Per_Decoding_Window,Post_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,Post_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window];

        Pre_Sleep_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1,Super_Cells),1,'omitnan')';
        Pre_Sleep_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Pre_Sleep_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        Post_Sleep_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3,Super_Cells),1,'omitnan')';
        Post_Sleep_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Post_Sleep_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';

        Per_Super_Cell_Firing_Precision(:,:,2)=[Super_Cells,Pre_Sleep_Super_All_Ripples_Firing_Precision,Pre_Sleep_Super_Coherent_Ripples_Firing_Precision,Pre_Sleep_Super_Fragmented_Ripples_Firing_Precision,zeros(length(Super_Cells),3),Post_Sleep_Super_All_Ripples_Firing_Precision,Post_Sleep_Super_Coherent_Ripples_Firing_Precision,Post_Sleep_Super_Fragmented_Ripples_Firing_Precision];

        Pre_Awake_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1,Super_Cells),1,'omitnan')';
        Pre_Awake_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Pre_Awake_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';
        Post_Awake_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3,Super_Cells),1,'omitnan')';
        Post_Awake_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Super_Cells),1,'omitnan')';
        Post_Awake_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Super_Cells),1,'omitnan')';

        Per_Super_Cell_Firing_Precision(:,:,3)=[Super_Cells,Pre_Awake_Super_All_Ripples_Firing_Precision,Pre_Awake_Super_Coherent_Ripples_Firing_Precision,Pre_Awake_Super_Fragmented_Ripples_Firing_Precision,zeros(length(Super_Cells),3),Post_Awake_Super_All_Ripples_Firing_Precision,Post_Awake_Super_Coherent_Ripples_Firing_Precision,Post_Awake_Super_Fragmented_Ripples_Firing_Precision];


        % Large Amplitude Spike Deep Cells

        Pre_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';

        Per_Large_Deep_Cell_Firing_Precision=[Large_Deep_Cells,Pre_Large_Deep_All_Ripples_Firing_Precision,Pre_Large_Deep_Coherent_Ripples_Firing_Precision,Pre_Large_Deep_Fragmented_Ripples_Firing_Precision,OnTask_Large_Deep_All_Ripples_Firing_Precision,OnTask_Large_Deep_Coherent_Ripples_Firing_Precision,OnTask_Large_Deep_Fragmented_Ripples_Firing_Precision,Post_Large_Deep_All_Ripples_Firing_Precision,Post_Large_Deep_Coherent_Ripples_Firing_Precision,Post_Large_Deep_Fragmented_Ripples_Firing_Precision];

        Pre_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        OnTask_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Post_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';

        Per_Large_Deep_Cell_Spikes_Per_Decoding_Window=[Large_Deep_Cells,Pre_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window,Pre_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,Pre_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window,Post_Large_Deep_All_Ripples_Spikes_Per_Decoding_Window,Post_Large_Deep_Coherent_Ripples_Spikes_Per_Decoding_Window,Post_Large_Deep_Fragmented_Ripples_Spikes_Per_Decoding_Window];

        Pre_Sleep_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Sleep_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Sleep_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        Post_Sleep_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3,Large_Deep_Cells),1,'omitnan')';
        Post_Sleep_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Post_Sleep_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';

        Per_Large_Deep_Cell_Firing_Precision(:,:,2)=[Large_Deep_Cells,Pre_Sleep_Large_Deep_All_Ripples_Firing_Precision,Pre_Sleep_Large_Deep_Coherent_Ripples_Firing_Precision,Pre_Sleep_Large_Deep_Fragmented_Ripples_Firing_Precision,zeros(length(Large_Deep_Cells),3),Post_Sleep_Large_Deep_All_Ripples_Firing_Precision,Post_Sleep_Large_Deep_Coherent_Ripples_Firing_Precision,Post_Sleep_Large_Deep_Fragmented_Ripples_Firing_Precision];

        Pre_Awake_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Awake_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Pre_Awake_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';
        Post_Awake_Large_Deep_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3,Large_Deep_Cells),1,'omitnan')';
        Post_Awake_Large_Deep_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Deep_Cells),1,'omitnan')';
        Post_Awake_Large_Deep_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Deep_Cells),1,'omitnan')';

        Per_Large_Deep_Cell_Firing_Precision(:,:,3)=[Large_Deep_Cells,Pre_Awake_Large_Deep_All_Ripples_Firing_Precision,Pre_Awake_Large_Deep_Coherent_Ripples_Firing_Precision,Pre_Awake_Large_Deep_Fragmented_Ripples_Firing_Precision,zeros(length(Large_Deep_Cells),3),Post_Awake_Large_Deep_All_Ripples_Firing_Precision,Post_Awake_Large_Deep_Coherent_Ripples_Firing_Precision,Post_Awake_Large_Deep_Fragmented_Ripples_Firing_Precision];

        % Large Amplitude Spike Superficial Cells

        Pre_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';

        Per_Large_Super_Cell_Firing_Precision=[Large_Super_Cells,Pre_Large_Super_All_Ripples_Firing_Precision,Pre_Large_Super_Coherent_Ripples_Firing_Precision,Pre_Large_Super_Fragmented_Ripples_Firing_Precision,OnTask_Large_Super_All_Ripples_Firing_Precision,OnTask_Large_Super_Coherent_Ripples_Firing_Precision,OnTask_Large_Super_Fragmented_Ripples_Firing_Precision,Post_Large_Super_All_Ripples_Firing_Precision,Post_Large_Super_Coherent_Ripples_Firing_Precision,Post_Large_Super_Fragmented_Ripples_Firing_Precision];

        Pre_Large_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        OnTask_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==2 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_All_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Post_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window=mean(Ripple_Cell_Spikes_Per_Decoding_Window(Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';

        Per_Large_Super_Cell_Spikes_Per_Decoding_Window=[Large_Super_Cells,Pre_Large_Super_All_Ripples_Spikes_Per_Decoding_Window,Pre_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,Pre_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Super_All_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,OnTask_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window,Post_Large_Super_All_Ripples_Spikes_Per_Decoding_Window,Post_Large_Super_Coherent_Ripples_Spikes_Per_Decoding_Window,Post_Large_Super_Fragmented_Ripples_Spikes_Per_Decoding_Window];

        Pre_Sleep_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Sleep_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Sleep_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        Post_Sleep_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3,Large_Super_Cells),1,'omitnan')';
        Post_Sleep_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Post_Sleep_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==2 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';

        Per_Large_Super_Cell_Firing_Precision(:,:,2)=[Large_Super_Cells,Pre_Sleep_Large_Super_All_Ripples_Firing_Precision,Pre_Sleep_Large_Super_Coherent_Ripples_Firing_Precision,Pre_Sleep_Large_Super_Fragmented_Ripples_Firing_Precision,zeros(length(Large_Super_Cells),3),Post_Sleep_Large_Super_All_Ripples_Firing_Precision,Post_Sleep_Large_Super_Coherent_Ripples_Firing_Precision,Post_Sleep_Large_Super_Fragmented_Ripples_Firing_Precision];

        Pre_Awake_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Awake_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Pre_Awake_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==1 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';
        Post_Awake_Large_Super_All_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3,Large_Super_Cells),1,'omitnan')';
        Post_Awake_Large_Super_Coherent_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==1,Large_Super_Cells),1,'omitnan')';
        Post_Awake_Large_Super_Fragmented_Ripples_Firing_Precision=mean(Ripple_Cell_Firing_Precision(Ripple_Categories(:,3)==1 & Ripple_Categories(:,2)==3 & Ripple_Categories(:,4)==2,Large_Super_Cells),1,'omitnan')';

        Per_Large_Super_Cell_Firing_Precision(:,:,3)=[Large_Super_Cells,Pre_Awake_Large_Super_All_Ripples_Firing_Precision,Pre_Awake_Large_Super_Coherent_Ripples_Firing_Precision,Pre_Awake_Large_Super_Fragmented_Ripples_Firing_Precision,zeros(length(Large_Super_Cells),3),Post_Awake_Large_Super_All_Ripples_Firing_Precision,Post_Awake_Large_Super_Coherent_Ripples_Firing_Precision,Post_Awake_Large_Super_Fragmented_Ripples_Firing_Precision];


        save('Per_Cell_Mean_Firing_Precision','Per_*');

        clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name

        cd ..

    end

    clear Directory

    cd ..

end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables



% Here, I combine data across all rats and sessions

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load Per_Cell_Mean_Firing_Precision;
        load Firing_Properties_Per_Cell_During_Behavior;

        if exist('All_Per_Session_Deep_Cell_Precision','var')
            All_Per_Session_Deep_Cell_Precision=[All_Per_Session_Deep_Cell_Precision;mean(Per_Deep_Cell_Firing_Precision,1,'omitnan')];
            All_Per_Session_Super_Cell_Precision=[All_Per_Session_Super_Cell_Precision;mean(Per_Super_Cell_Firing_Precision,1,'omitnan')];
            All_Per_Session_Large_Deep_Cell_Precision=[All_Per_Session_Large_Deep_Cell_Precision;mean(Per_Large_Deep_Cell_Firing_Precision,1,'omitnan')];
            All_Per_Session_Large_Super_Cell_Precision=[All_Per_Session_Large_Super_Cell_Precision;mean(Per_Large_Super_Cell_Firing_Precision,1,'omitnan')];
            All_Per_Session_Deep_Cell_Spikes_Per_Decoding_Window=[All_Per_Session_Deep_Cell_Spikes_Per_Decoding_Window;mean(Per_Deep_Cell_Spikes_Per_Decoding_Window,1,'omitnan')];
            All_Per_Session_Super_Cell_Spikes_Per_Decoding_Window=[All_Per_Session_Super_Cell_Spikes_Per_Decoding_Window;mean(Per_Super_Cell_Spikes_Per_Decoding_Window,1,'omitnan')];
            All_Per_Session_Large_Deep_Cell_Spikes_Per_Decoding_Window=[All_Per_Session_Large_Deep_Cell_Spikes_Per_Decoding_Window;mean(Per_Large_Deep_Cell_Spikes_Per_Decoding_Window,1,'omitnan')];
            All_Per_Session_Large_Super_Cell_Spikes_Per_Decoding_Window=[All_Per_Session_Large_Super_Cell_Spikes_Per_Decoding_Window;mean(Per_Large_Super_Cell_Spikes_Per_Decoding_Window,1,'omitnan')];
        else
            All_Per_Session_Deep_Cell_Precision=mean(Per_Deep_Cell_Firing_Precision,1,'omitnan');
            All_Per_Session_Super_Cell_Precision=mean(Per_Super_Cell_Firing_Precision,1,'omitnan');
            All_Per_Session_Large_Deep_Cell_Precision=mean(Per_Large_Deep_Cell_Firing_Precision,1,'omitnan');
            All_Per_Session_Large_Super_Cell_Precision=mean(Per_Large_Super_Cell_Firing_Precision,1,'omitnan');
            All_Per_Session_Deep_Cell_Spikes_Per_Decoding_Window=mean(Per_Deep_Cell_Spikes_Per_Decoding_Window,1,'omitnan');
            All_Per_Session_Super_Cell_Spikes_Per_Decoding_Window=mean(Per_Super_Cell_Spikes_Per_Decoding_Window,1,'omitnan');
            All_Per_Session_Large_Deep_Cell_Spikes_Per_Decoding_Window=mean(Per_Large_Deep_Cell_Spikes_Per_Decoding_Window,1,'omitnan');
            All_Per_Session_Large_Super_Cell_Spikes_Per_Decoding_Window=mean(Per_Large_Super_Cell_Spikes_Per_Decoding_Window,1,'omitnan');
        end

        if exist('All_Deep_Cell_Precision','var')
            All_Deep_Cell_Precision=[All_Deep_Cell_Precision;Per_Deep_Cell_Firing_Precision];
            All_Super_Cell_Precision=[All_Super_Cell_Precision;Per_Super_Cell_Firing_Precision];
            All_Large_Deep_Cell_Precision=[All_Large_Deep_Cell_Precision;Per_Large_Deep_Cell_Firing_Precision];
            All_Large_Super_Cell_Precision=[All_Large_Super_Cell_Precision;Per_Large_Super_Cell_Firing_Precision];
            All_Deep_Cell_Spikes_Per_Decoding_Window=[All_Deep_Cell_Spikes_Per_Decoding_Window;Per_Deep_Cell_Spikes_Per_Decoding_Window];
            All_Super_Cell_Spikes_Per_Decoding_Window=[All_Super_Cell_Spikes_Per_Decoding_Window;Per_Super_Cell_Spikes_Per_Decoding_Window];
            All_Large_Deep_Cell_Spikes_Per_Decoding_Window=[All_Large_Deep_Cell_Spikes_Per_Decoding_Window;Per_Large_Deep_Cell_Spikes_Per_Decoding_Window];
            All_Large_Super_Cell_Spikes_Per_Decoding_Window=[All_Large_Super_Cell_Spikes_Per_Decoding_Window;Per_Large_Super_Cell_Spikes_Per_Decoding_Window];
        else
            All_Deep_Cell_Precision=Per_Deep_Cell_Firing_Precision;
            All_Super_Cell_Precision=Per_Super_Cell_Firing_Precision;
            All_Large_Deep_Cell_Precision=Per_Large_Deep_Cell_Firing_Precision;
            All_Large_Super_Cell_Precision=Per_Large_Super_Cell_Firing_Precision;
            All_Deep_Cell_Spikes_Per_Decoding_Window=Per_Deep_Cell_Spikes_Per_Decoding_Window;
            All_Super_Cell_Spikes_Per_Decoding_Window=Per_Super_Cell_Spikes_Per_Decoding_Window;
            All_Large_Deep_Cell_Spikes_Per_Decoding_Window=Per_Large_Deep_Cell_Spikes_Per_Decoding_Window;
            All_Large_Super_Cell_Spikes_Per_Decoding_Window=Per_Large_Super_Cell_Spikes_Per_Decoding_Window;
        end

        clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name All*

        cd ..

    end

    clear Directory

    cd ..

end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables All*

cd AllRatsCombined
save('All_Cell_Precision_In_Replay','All*')
cd ..


end

