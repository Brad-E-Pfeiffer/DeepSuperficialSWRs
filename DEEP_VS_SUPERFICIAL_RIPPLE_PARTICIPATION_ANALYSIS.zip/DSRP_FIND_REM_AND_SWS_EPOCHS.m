function DSRP_FIND_REM_AND_SWS_EPOCHS(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the theta and delta power during identified
% sleep epochs and calculates REM epochs as elevations in the theta/delta
% power ratio.  The remainder of sleep is defined as SWS.
% 
% Because the LFP was recorded at 3.2 kHz, but we are only looking at
% oscillations of 12 Hz or slower, we can subsample the data to speed up
% processing.  Thus, I use only every 10th data point, bringing the
% effective recording frequency to 320 Hz, which is still sufficiently high
% to avoid any Nyquist frequency issues.  (I compared the result of this
% subsampling with analysis on the original and found no difference.)
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Epochs
load('Spike_Data','Tetrode_Cell_IDs');
Duration_To_Remove=Initial_Variables.Duration_To_Remove_Around_Bad_LFP;
if ~isfile('Sleep_Theta_Delta_Ratio.mat')
    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    Directory_List=dir;
    for N=1:size(Directory_List,1)
        for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if there are more channels, increase this number accordingly
            Comparison_String=sprintf('CSC%d.ncs',M);
            if strcmp(Directory_List(N).name,Comparison_String)
                if exist('LFP_Electrodes','var')
                    LFP_Electrodes=[LFP_Electrodes,M];
                else
                    LFP_Electrodes=M;
                end
            end
            clear Comparison_String;
        end
    end
    if ~exist('LFP_Electrodes','var')
        error('ERROR! No CSC files were identified in the listed load directory.')
    end
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1)/10;  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
    clear M;
    clear N;
    clear Directory_List;
    clear LFP_Electrodes;
    clear LFP_Filename;
    
    Theta_Stop_Low=5;
    Theta_Pass_Low=6;
    Theta_Pass_High=12;
    Theta_Stop_High=14;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Theta=fdesign.bandpass(Theta_Stop_Low,Theta_Pass_Low,Theta_Pass_High,Theta_Stop_High,Stop_Band_Attenuation_One,Pass_Band,Stop_Band_Attenuation_Two,LFP_Frequency);
    Theta_Filter=design(Filter_Design_For_Theta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    
    Delta_Stop_Low=1;
    Delta_Pass_Low=1.5;             % Most papers use between 1 and 5 Hz to identify delta oscillations
    Delta_Pass_High=4;
    Delta_Stop_High=5;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Delta=fdesign.bandpass(Delta_Stop_Low, Delta_Pass_Low, Delta_Pass_High, Delta_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Delta_Filter=design(Filter_Design_For_Delta,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    
    for Current_Tetrode=min(Tetrode_Cell_IDs(:,1)):max(Tetrode_Cell_IDs(:,1))
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2); %Only processes tetrodes with recorded cells on them
        if ~isempty(Cells_On_This_Tetrode)
            for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
                Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
                if isfile(Electrode_Name)
                    LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                    for Header_Line=1:length(LFP_Header)
                        Header_Info=cell2mat(LFP_Header(Header_Line));
                        if length(Header_Info)>12
                            if strcmp(Header_Info(1:11),'-ADMaxValue')
                                Max_Value=str2num(Header_Info(13:end));
                            end
                            if strcmp(Header_Info(1:11),'-InputRange')
                                Max_Range=str2num(Header_Info(13:end));
                            end
                        end
                    end
                    LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                    Times=zeros(512,size(LFP_Times,2));
                    for B=1:length(LFP_Times)-1
                        Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                    end
                    Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                    clear B;
                    clear LFP_Times;
                    Times=Times(:);
                    LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                    LFP_Samples=LFP_Samples(:)*-(Max_Range/Max_Value); %Multiply by -1 to correct for the fact that the raw LFP was recorded inverted (see Header info)
                    LFP_Data_All=[Times,LFP_Samples];
                    LFP_Data_All=LFP_Data_All(1:10:end,:);  %Because I'm only looking at theta and delta, I subsample each 10th data point, making this recording frequency effectively 320 Hz (the LFP_Frequency variable is adjusted above)
                    if ~exist('All_Theta_LFP_Data','var')
                        All_Theta_LFP_Data=LFP_Data_All(:,1);
                        All_Delta_LFP_Data=LFP_Data_All(:,1);
                    end
                    clear Times;
                    clear LFP_Samples;
                    clear Max_Value;
                    
                    %For speed, this limits the analysis to only identified sleep periods (plus 5 seconds on either side for filtering)
                    LFP_Data=LFP_Data_All(1,:);
                    for N=1:size(Sleep_Times,1)
                        LFP_Data=[LFP_Data;LFP_Data_All(LFP_Data_All(:,1)>=(Sleep_Times(N,1)-5) & LFP_Data_All(:,1)<=(Sleep_Times(N,2)+5),:)];
                    end
                    LFP_Data=LFP_Data(2:end,:);
                    
                    Theta_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                    Theta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,LFP_Data(:,2));
                    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Theta_Filtered_LFP_Data(:,2)=filter(Theta_Filter,Theta_Filtered_LFP_Data(:,2));
                    Theta_Filtered_LFP_Data(:,2)=Theta_Filtered_LFP_Data(end:-1:1,2);
                    Theta_Filtered_LFP_Data(:,3)=abs(hilbert(Theta_Filtered_LFP_Data(:,2)));
                    Theta_Gaussian_Filter=fspecial('gaussian',[round(3*(300/((1/LFP_Frequency)*1000))),1],round(300/((1/LFP_Frequency)*1000)));  %sigma of 300 ms
                    Theta_Filtered_LFP_Data(:,3)=filtfilt(Theta_Gaussian_Filter,1,Theta_Filtered_LFP_Data(:,3));
                    
                    Delta_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                    Delta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Delta_Filtered_LFP_Data(:,2)=filter(Delta_Filter,LFP_Data(:,2));
                    Delta_Filtered_LFP_Data(:,2)=Delta_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Delta_Filtered_LFP_Data(:,2)=filter(Delta_Filter,Delta_Filtered_LFP_Data(:,2));
                    Delta_Filtered_LFP_Data(:,2)=Delta_Filtered_LFP_Data(end:-1:1,2);
                    Delta_Filtered_LFP_Data(:,3)=abs(hilbert(Delta_Filtered_LFP_Data(:,2)));
                    Delta_Gaussian_Filter=fspecial('gaussian',[round(3*(1500/((1/LFP_Frequency)*1000))),1],round(1500/((1/LFP_Frequency)*1000)));  %sigma of 1500 ms
                    Delta_Filtered_LFP_Data(:,3)=filtfilt(Delta_Gaussian_Filter,1,Delta_Filtered_LFP_Data(:,3));
                    
                    %This identifies parts of the LFP that are beyond the recording parameters and for which the LFP cannot be properly quantified -- the theta and delta power of these times and all within Duration_To_Remove seconds will be NaN
                    Index_To_Remove=find(LFP_Data(:,2)==Max_Range | LFP_Data(:,2)==(-1*Max_Range));
                    for N=1:100000:length(Index_To_Remove)
                        Index_To_Remove2=(ones(length(N:min([N+99999,length(Index_To_Remove)])),1).*((-round(LFP_Frequency*Duration_To_Remove)):round(LFP_Frequency*Duration_To_Remove)))+Index_To_Remove(N:min([N+99999,length(Index_To_Remove)]));
                        Index_To_Remove2=Index_To_Remove2(:);
                        Index_To_Remove2=Index_To_Remove2(Index_To_Remove2>0 & Index_To_Remove2<=size(Theta_Filtered_LFP_Data,1));
                        Theta_Filtered_LFP_Data(Index_To_Remove2,4)=1;
                        Delta_Filtered_LFP_Data(Index_To_Remove2,4)=1;
                    end
                    Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,4)==1,3)=NaN;
                    Delta_Filtered_LFP_Data(Delta_Filtered_LFP_Data(:,4)==1,3)=NaN;
                    clear N;
                    clear LFP_Data;
                    clear Max_Range;
                    clear Index_To_Remove;
                    clear Index_To_Remove2;
                    
                    All_Theta_LFP_Data(:,end+1)=NaN;
                    All_Delta_LFP_Data(:,end+1)=NaN;
                    Integration_Index=round(interp1(Theta_Filtered_LFP_Data(:,1),1:size(Theta_Filtered_LFP_Data,1),All_Theta_LFP_Data(:,1),'nearest'));
                    Integration_Index(Integration_Index==0)=1;
                    Integration_Index(Integration_Index>size(Theta_Filtered_LFP_Data,1))=size(Theta_Filtered_LFP_Data,1);
                    All_Theta_LFP_Data(~isnan(Integration_Index),end)=Theta_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),3);
                    All_Theta_LFP_Data(isnan(Integration_Index),end)=NaN;
                    clear Integration_Index;
                    Integration_Index=round(interp1(Delta_Filtered_LFP_Data(:,1),1:size(Delta_Filtered_LFP_Data,1),All_Delta_LFP_Data(:,1),'nearest'));
                    Integration_Index(Integration_Index==0)=1;
                    Integration_Index(Integration_Index>size(Delta_Filtered_LFP_Data,1))=size(Delta_Filtered_LFP_Data,1);
                    All_Delta_LFP_Data(~isnan(Integration_Index),end)=Delta_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),3);
                    All_Delta_LFP_Data(isnan(Integration_Index),end)=NaN;
                    clear Integration_Index;
                    clear Theta_Filtered_LFP_Data;
                    clear Delta_Filtered_LFP_Data;
                    
                end
            end
        end
        disp(sprintf('Finished quantifying theta and delta power for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    
    cd(Current_Working_Directory);
    
    Average_Theta_Power=[All_Theta_LFP_Data(:,1),mean(All_Theta_LFP_Data(:,2:end),2,'omitnan')];
    Average_Delta_Power=[All_Delta_LFP_Data(:,1),mean(All_Delta_LFP_Data(:,2:end),2,'omitnan')];
    Index_To_Keep=~isnan(Average_Theta_Power(:,2)) & ~isnan(Average_Delta_Power(:,2));
    Average_Theta_Power=Average_Theta_Power(Index_To_Keep,:);
    Average_Delta_Power=Average_Delta_Power(Index_To_Keep,:);
    
    Theta_Delta_Ratio=[Average_Theta_Power(:,1),Average_Theta_Power(:,2)./Average_Delta_Power(:,2)];
    Theta_Delta_Ratio(isinf(Theta_Delta_Ratio(:,2)),2)=max(Theta_Delta_Ratio(~isinf(Theta_Delta_Ratio(:,2)),2))*10; %This accounts for the rare case where the average delta power is exactly zero
    Theta_Delta_Filter=fspecial('gaussian',[round(3*(5000/((1/LFP_Frequency)*1000))),1],round(5000/((1/LFP_Frequency)*1000)));  %sigma of 5 s
    Theta_Delta_Ratio(:,3)=filtfilt(Theta_Delta_Filter,1,Theta_Delta_Ratio(:,2));
    
    Sleep_Theta_Delta_Ratio=zeros(1,3);
    for N=1:size(Sleep_Times,1)
        Sleep_Theta_Delta_Ratio=[Sleep_Theta_Delta_Ratio;Theta_Delta_Ratio(Theta_Delta_Ratio(:,1)>=Sleep_Times(N,1) & Theta_Delta_Ratio(:,1)<=Sleep_Times(N,2),:)];
    end
    Sleep_Theta_Delta_Ratio=Sleep_Theta_Delta_Ratio(2:end,:);
    
    save('Sleep_Theta_Delta_Ratio','Sleep_Theta_Delta_Ratio')
    
else
    load Sleep_Theta_Delta_Ratio
end

clear REM_Times
REM_Threshold=1;
REM_Times=zeros(1,2);
for M=1:size(Sleep_Times,1)
    Sleep_Epoch_Theta_Delta_Ratio=Sleep_Theta_Delta_Ratio(Sleep_Theta_Delta_Ratio(:,1)>=Sleep_Times(M,1) & Sleep_Theta_Delta_Ratio(:,1)<=Sleep_Times(M,2),:);
    for N=2:size(Sleep_Epoch_Theta_Delta_Ratio,1)
        if Sleep_Epoch_Theta_Delta_Ratio(N-1,3)<REM_Threshold && Sleep_Epoch_Theta_Delta_Ratio(N,3)>=REM_Threshold
            L=N;
            while L<size(Sleep_Epoch_Theta_Delta_Ratio,1) && Sleep_Epoch_Theta_Delta_Ratio(L,3)>=REM_Threshold
                L=L+1;
            end
            REM_Times(end+1,:)=[Sleep_Epoch_Theta_Delta_Ratio(N,1),Sleep_Epoch_Theta_Delta_Ratio(L,1)];
        end
    end
end
REM_Time_Durations=(REM_Times(:,2)-REM_Times(:,1));
REM_Times=REM_Times(REM_Time_Durations>=10,:);
clear M;
clear N;
clear L;

%This finds the SWS times (defined as sleep periods not classified as REM)
SWS_Times=zeros(1,2);
for N=1:size(Sleep_Times,1)
    Current_Sleep_Epoch=Sleep_Times(N,:);
    REM_Periods_In_This_Epoch=REM_Times(REM_Times(:,1)>=Current_Sleep_Epoch(1) & REM_Times(:,2)<=Current_Sleep_Epoch(2),:);
    if isempty(REM_Periods_In_This_Epoch)
        SWS_Times=[SWS_Times;Current_Sleep_Epoch];
    else
        if REM_Periods_In_This_Epoch(1,1)>Current_Sleep_Epoch(1)
            SWS_Times=[SWS_Times;[Current_Sleep_Epoch(1),REM_Periods_In_This_Epoch(1,1)]];
        end
        if size(REM_Periods_In_This_Epoch,1)==1 && REM_Periods_In_This_Epoch(1,2)<Current_Sleep_Epoch(2)
            SWS_Times=[SWS_Times;[REM_Periods_In_This_Epoch(1,2),Current_Sleep_Epoch(2)]];
        elseif size(REM_Periods_In_This_Epoch,1)>1
            for N=1:(size(REM_Periods_In_This_Epoch,1)-1)
                SWS_Times=[SWS_Times;[REM_Periods_In_This_Epoch(N,2),REM_Periods_In_This_Epoch((N+1),1)]];
            end
            if REM_Periods_In_This_Epoch(end,2)<Current_Sleep_Epoch(2)
                SWS_Times=[SWS_Times;[REM_Periods_In_This_Epoch(end,2),Current_Sleep_Epoch(2)]];
            end
        end
    end
end
SWS_Times=SWS_Times(2:end,:);

%This finds Sleep Box Awake Immobile Times (defined as sleep box immobile times not classified as sleep)
Sleep_Box_Awake_Immobile_Times=zeros(1,2);
for N=1:size(Sleep_Box_Immobile_Times,1)
    Current_Immobile_Epoch=Sleep_Box_Immobile_Times(N,:);
    Sleep_Periods_In_This_Epoch=Sleep_Times(Sleep_Times(:,1)>=Current_Immobile_Epoch(1) & Sleep_Times(:,2)<=Current_Immobile_Epoch(2),:);
    if isempty(Sleep_Periods_In_This_Epoch)
        Sleep_Box_Awake_Immobile_Times=[Sleep_Box_Awake_Immobile_Times;Current_Immobile_Epoch];
    else
        if Sleep_Periods_In_This_Epoch(1,1)>Current_Immobile_Epoch(1)
            Sleep_Box_Awake_Immobile_Times=[Sleep_Box_Awake_Immobile_Times;[Current_Immobile_Epoch(1),Sleep_Periods_In_This_Epoch(1,1)]];
        end
        if size(Sleep_Periods_In_This_Epoch,1)==1 && Sleep_Periods_In_This_Epoch(1,2)<Current_Immobile_Epoch(2)
            Sleep_Box_Awake_Immobile_Times=[Sleep_Box_Awake_Immobile_Times;[Sleep_Periods_In_This_Epoch(1,2),Current_Immobile_Epoch(2)]];
        elseif size(Sleep_Periods_In_This_Epoch,1)>1
            for N=1:(size(Sleep_Periods_In_This_Epoch,1)-1)
                Sleep_Box_Awake_Immobile_Times=[Sleep_Box_Awake_Immobile_Times;[Sleep_Periods_In_This_Epoch(N,2),Sleep_Periods_In_This_Epoch((N+1),1)]];
            end
            if Sleep_Periods_In_This_Epoch(end,2)<Current_Immobile_Epoch(2)
                Sleep_Box_Awake_Immobile_Times=[Sleep_Box_Awake_Immobile_Times;[Sleep_Periods_In_This_Epoch(end,2),Current_Immobile_Epoch(2)]];
            end
        end
    end
end
Sleep_Box_Awake_Immobile_Times=Sleep_Box_Awake_Immobile_Times(2:end,:);

save('Epochs','REM_Times','Sleep_Times','Run_Times','Sleep_Box_Immobile_Times','SWS_Times','Sleep_Box_Awake_Immobile_Times')

end

