function DSRP_IDENTIFY_REPLAY_EVENTS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function decodes each identified ripple and determines if the replay
% encodes a meaningful trajectory across the environment.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if ~isfile('Completed_Identify_Replay_Events.mat')
                       
            disp('==========================================================================');
            disp(sprintf('Starting Replay Detection Analysis for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            
            disp('Decoding Ripple Content.')
            if ~isfile('Decoded_Ripple_Events.mat')
                SGCO_DECODE_RIPPLE_EVENTS(Initial_Variables);
            end
            
            Completed_Identify_Replay_Events=1;
            save('Completed_Identify_Replay_Events','Completed_Identify_Replay_Events');
            
            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name
            
        end
            
        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables

end

