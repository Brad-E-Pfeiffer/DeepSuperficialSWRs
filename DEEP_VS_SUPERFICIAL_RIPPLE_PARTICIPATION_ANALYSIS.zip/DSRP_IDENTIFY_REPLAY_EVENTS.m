function DSRP_IDENTIFY_REPLAY_EVENTS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function decodes each identified ripple and determines if the replay
% encodes a meaningful trajectory across the environment.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if 1%~isfile('Completed_Identify_Replay_Events.mat')
                       
            disp('==========================================================================');
            disp(sprintf('Starting Replay Detection Analysis for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            
            disp('Decoding Ripple Content.')
            if ~isfile('Decoded_Linear_Ripple_Events.mat')
                DSRP_DECODE_RIPPLE_EVENTS(Initial_Variables);
                if 0 %Not currently using shuffles
                    DSRP_DECODE_RIPPLE_EVENT_SHUFFLES(Initial_Variables);
                end
            end

            disp('Identifying Coherent vs. Fragmented Ripples.')
            DSRP_DETERMINE_COHERENT_VS_FRAGMENTED_RIPPLES(Initial_Variables)

            Completed_Identify_Replay_Events=1;
            save('Completed_Identify_Replay_Events','Completed_Identify_Replay_Events');
            
            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name
            
        end
            
        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables

end

