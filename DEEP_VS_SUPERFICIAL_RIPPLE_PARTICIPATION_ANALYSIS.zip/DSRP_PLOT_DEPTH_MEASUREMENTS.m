function DSRP_PLOT_DEPTH_MEASUREMENTS

cd Harpy
cd Linear1

load Sharp_Wave_Deflection_Per_Tetrode
load Combined_Ripple_LFP_Data
load Ripple_Events
load Epochs
load('Spike_Data','Tetrode_Cell_IDs')
Unique_Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
Ripple_Events_Sharp_Wave_Deflections=Ripple_Events_Sharp_Wave_Deflections(:,:,Unique_Tetrode_List);
Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:),'omitnan'),[3,1,2]);
[~,Deep_To_Superficial_Tetrode_Order]=sortrows(Sharp_Wave_Deflection_Per_Tetrode,'descend');
cd ..
cd ..
if isfolder('_Figures')
    cd _Figures
else
    mkdir('_Figures')
    cd _Figures
end
if isfolder('Example_Sharp_Waves_Per_Tetrode')
    cd Example_Sharp_Waves_Per_Tetrode
else
    mkdir('Example_Sharp_Waves_Per_Tetrode')
    cd Example_Sharp_Waves_Per_Tetrode
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:length(Deep_To_Superficial_Tetrode_Order)
    plot(Combined_All_Ripple_LFP_Data(:,1),Combined_All_Ripple_LFP_Data(:,(Deep_To_Superficial_Tetrode_Order(N)+1))-(N*50),'Color',[1-(N/(length(Deep_To_Superficial_Tetrode_Order))),0,N/(length(Deep_To_Superficial_Tetrode_Order))],'LineWidth',2);
end
set(gca,'XLim',[-0.25 0.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Harpy_Linear1_Average_Ripple_Per_Tetrode(N=%d_Ripples)(X=-0.25to0.25s)(Y=%d).jpg'');',size(Ripple_Events,1),Y_Lim(2)-Y_Lim(1)));
close
cd ..
cd ..

end