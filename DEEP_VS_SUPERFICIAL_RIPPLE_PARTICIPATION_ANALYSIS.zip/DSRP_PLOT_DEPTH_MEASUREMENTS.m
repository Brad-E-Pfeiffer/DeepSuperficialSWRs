function DSRP_PLOT_DEPTH_MEASUREMENTS(Initial_Variables)

cd Harpy
cd Linear1

load Sharp_Wave_Deflection_Per_Tetrode
load Combined_Ripple_LFP_Data
load Ripple_Events
load Epochs
load('Spike_Data','Tetrode_Cell_IDs')
Unique_Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
Ripple_Events_Sharp_Wave_Deflections=Ripple_Events_Sharp_Wave_Deflections(:,:,Unique_Tetrode_List);
Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:),'omitnan'),[3,1,2]);
[~,Deep_To_Superficial_Tetrode_Order]=sortrows(Sharp_Wave_Deflection_Per_Tetrode,'descend');
cd ..
cd ..
if isfolder('_Figures')
    cd _Figures
else
    mkdir('_Figures')
    cd _Figures
end
if isfolder('Example_Sharp_Waves_Per_Tetrode')
    cd Example_Sharp_Waves_Per_Tetrode
else
    mkdir('Example_Sharp_Waves_Per_Tetrode')
    cd Example_Sharp_Waves_Per_Tetrode
end

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=1:length(Deep_To_Superficial_Tetrode_Order)
    plot(Combined_All_Ripple_LFP_Data(:,1),Combined_All_Ripple_LFP_Data(:,(Deep_To_Superficial_Tetrode_Order(N)+1))-(N*50),'Color',[1-(N/(length(Deep_To_Superficial_Tetrode_Order))),0,N/(length(Deep_To_Superficial_Tetrode_Order))],'LineWidth',2);
end
set(gca,'XLim',[-0.25 0.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Harpy_Linear1_Average_Ripple_Per_Tetrode(N=%d_Ripples)(X=-0.25to0.25s)(Y=%d).jpg'');',size(Ripple_Events,1),Y_Lim(2)-Y_Lim(1)));
close
cd ..
cd ..




cd Harpy
cd Linear1
Current_Directory=pwd;
load Ripple_Events;
eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
cd(Raw_LFP_Directory)
LFP_Frequency=Nlx2MatCSC('CSC5.ncs',[0 0 1 0 0],0,3,1);
LFP_Header=Nlx2MatCSC('CSC5.ncs',[0 0 0 0 0],1,1,0);
LFP_Times=Nlx2MatCSC('CSC5.ncs',[1 0 0 0 0],0,1)/1000000;
for Header_Line=1:length(LFP_Header)
    Header_Info=cell2mat(LFP_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            Max_Range=str2num(Header_Info(13:end));
        end
    end
end
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
end
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
clear B;
clear LFP_Times;
Times=Times(:);
LFP_Samples=Nlx2MatCSC('CSC5.ncs',[0 0 0 0 1],0,1);
LFP_Samples=(-LFP_Samples(:))*(Max_Range/Max_Value); %The value is made negative to flip the signal back to the correct raw values as the recording was inverted (see Header info in the raw data file)
LFP_Data=[Times,LFP_Samples];
clear LFP_Times;
clear LFP_Samples;
cd(Current_Directory)
cd ..
cd ..
cd _Figures
cd Example_Sharp_Waves_Per_Tetrode
Ripple_Stop_Low=130;
Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
Ripple_Pass_High=250;
Ripple_Stop_High=275;
Stop_Band_Attenuation_One=60;
Pass_Band=1;
Stop_Band_Attenuation_Two=80;
Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);

if isfolder('Ripple_Examples')
    cd Ripple_Examples
else
    mkdir('Ripple_Examples')
    cd Ripple_Examples
end

for Ripple=[6,9,1000,1023]
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    L=LFP_Data(LFP_Data(:,1)>=(Ripple_Events(Ripple,1)-0.5) & LFP_Data(:,1)<=(Ripple_Events(Ripple,2)+0.5),:);
    R=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)>=(Ripple_Events(Ripple,1)-0.5) & Ripple_Filtered_LFP_Data(:,1)<=(Ripple_Events(Ripple,2)+0.5),:);
    plot(L(:,1),L(:,2),'k','LineWidth',1);
    plot(L(L(:,1)>=Ripple_Events(Ripple,1) & L(:,1)<=Ripple_Events(Ripple,2),1),L(L(:,1)>=Ripple_Events(Ripple,1) & L(:,1)<=Ripple_Events(Ripple,2),2),'r','LineWidth',1);
    set(gca,'XLim',[(Ripple_Events(Ripple,1)-0.5) (Ripple_Events(Ripple,2)+0.5)]);
    X_Lim=xlim;
    Y_Lim=ylim;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''TT2_Ripple_%d_Raw_(X=%dto%d)(Y=%dto%d).jpg'');',Ripple,X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
    close

    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    plot(R(:,1),R(:,2),'k','LineWidth',1);
    plot(R(R(:,1)>=Ripple_Events(Ripple,1) & R(:,1)<=Ripple_Events(Ripple,2),1),R(R(:,1)>=Ripple_Events(Ripple,1) & R(:,1)<=Ripple_Events(Ripple,2),2),'r','LineWidth',1);
    set(gca,'XLim',[(Ripple_Events(Ripple,1)-0.5) (Ripple_Events(Ripple,2)+0.5)]);
    X_Lim=xlim;
    Y_Lim=ylim;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''TT2_Ripple_%d_Ripple_(X=%dto%d)(Y=%dto%d).jpg'');',Ripple,X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
    close
end
cd ..
cd ..
cd ..


cd Harpy
cd Linear1
Current_Directory=pwd;
load Ripple_Events;
eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
cd(Raw_LFP_Directory)
LFP_Frequency=Nlx2MatCSC('CSC109.ncs',[0 0 1 0 0],0,3,1);
LFP_Header=Nlx2MatCSC('CSC109.ncs',[0 0 0 0 0],1,1,0);
LFP_Times=Nlx2MatCSC('CSC109.ncs',[1 0 0 0 0],0,1)/1000000;
for Header_Line=1:length(LFP_Header)
    Header_Info=cell2mat(LFP_Header(Header_Line));
    if length(Header_Info)>12
        if strcmp(Header_Info(1:11),'-ADMaxValue')
            Max_Value=str2num(Header_Info(13:end));
        end
        if strcmp(Header_Info(1:11),'-InputRange')
            Max_Range=str2num(Header_Info(13:end));
        end
    end
end
Times=zeros(512,size(LFP_Times,2));
for B=1:length(LFP_Times)-1
    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
end
Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
clear B;
clear LFP_Times;
Times=Times(:);
LFP_Samples=Nlx2MatCSC('CSC109.ncs',[0 0 0 0 1],0,1);
LFP_Samples=(-LFP_Samples(:))*(Max_Range/Max_Value); %The value is made negative to flip the signal back to the correct raw values as the recording was inverted (see Header info in the raw data file)
LFP_Data=[Times,LFP_Samples];
clear LFP_Times;
clear LFP_Samples;
cd(Current_Directory)
cd ..
cd ..
cd _Figures
cd Example_Sharp_Waves_Per_Tetrode
Ripple_Stop_Low=130;
Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
Ripple_Pass_High=250;
Ripple_Stop_High=275;
Stop_Band_Attenuation_One=60;
Pass_Band=1;
Stop_Band_Attenuation_Two=80;
Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);

if isfolder('Ripple_Examples')
    cd Ripple_Examples
else
    mkdir('Ripple_Examples')
    cd Ripple_Examples
end

for Ripple=[6,9,1000,1023]
    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    L=LFP_Data(LFP_Data(:,1)>=(Ripple_Events(Ripple,1)-0.5) & LFP_Data(:,1)<=(Ripple_Events(Ripple,2)+0.5),:);
    R=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,1)>=(Ripple_Events(Ripple,1)-0.5) & Ripple_Filtered_LFP_Data(:,1)<=(Ripple_Events(Ripple,2)+0.5),:);
    plot(L(:,1),L(:,2),'k','LineWidth',1);
    plot(L(L(:,1)>=Ripple_Events(Ripple,1) & L(:,1)<=Ripple_Events(Ripple,2),1),L(L(:,1)>=Ripple_Events(Ripple,1) & L(:,1)<=Ripple_Events(Ripple,2),2),'r','LineWidth',1);
    set(gca,'XLim',[(Ripple_Events(Ripple,1)-0.5) (Ripple_Events(Ripple,2)+0.5)]);
    X_Lim=xlim;
    Y_Lim=ylim;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''TT28_Ripple_%d_Raw_(X=%dto%d)(Y=%dto%d).jpg'');',Ripple,X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
    close

    figure;
    hold on;
    subplot('Position',[0 0 1 1]);
    hold on;
    plot(R(:,1),R(:,2),'k','LineWidth',1);
    plot(R(R(:,1)>=Ripple_Events(Ripple,1) & R(:,1)<=Ripple_Events(Ripple,2),1),R(R(:,1)>=Ripple_Events(Ripple,1) & R(:,1)<=Ripple_Events(Ripple,2),2),'r','LineWidth',1);
    set(gca,'XLim',[(Ripple_Events(Ripple,1)-0.5) (Ripple_Events(Ripple,2)+0.5)]);
    X_Lim=xlim;
    Y_Lim=ylim;
    set(gca,'XTick',[]);
    set(gca,'YTick',[]);
    eval(sprintf('print(''-djpeg'',''TT28_Ripple_%d_Ripple_(X=%dto%d)(Y=%dto%d).jpg'');',Ripple,X_Lim(1),X_Lim(2),Y_Lim(1),Y_Lim(2)));
    close
end
cd ..
cd ..
cd ..



Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
        Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
        if exist('All_Sharp_Wave_Deflection_Per_Tetrode','var')
            if size(All_Sharp_Wave_Deflection_Per_Tetrode,1)>size(Sharp_Wave_Deflection_Per_Tetrode,1)
                All_Sharp_Wave_Deflection_Per_Tetrode(1:size(Sharp_Wave_Deflection_Per_Tetrode,1),end+1)=Sharp_Wave_Deflection_Per_Tetrode;
                All_Sharp_Wave_Deflection_Per_Tetrode((size(Sharp_Wave_Deflection_Per_Tetrode,1)+1):end,end)=NaN;
            else
                All_Sharp_Wave_Deflection_Per_Tetrode(1:size(Sharp_Wave_Deflection_Per_Tetrode,1),end+1)=Sharp_Wave_Deflection_Per_Tetrode;
            end
        else
            All_Sharp_Wave_Deflection_Per_Tetrode=Sharp_Wave_Deflection_Per_Tetrode;
        end

        cd ..

    end
    clear Directory
    cd ..
end

cd _Figures
cd Example_Sharp_Waves_Per_Tetrode
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
fill([0 0 size(All_Sharp_Wave_Deflection_Per_Tetrode,2)+1 size(All_Sharp_Wave_Deflection_Per_Tetrode,2)+1 0],[-50 50 50 -50 -50],[0.7 0.7 0.7],'EdgeColor',[0.7 0.7 0.7],'FaceColor',[0.7 0.7 0.7]);
for N=1:size(All_Sharp_Wave_Deflection_Per_Tetrode,2)
    U=unique(All_Sharp_Wave_Deflection_Per_Tetrode(All_Sharp_Wave_Deflection_Per_Tetrode(:,N)>=0 & All_Sharp_Wave_Deflection_Per_Tetrode(:,N)<50,N));
    Plot1=scatter(ones(length(U),1)*N,U,100,'^','MarkerFaceColor',[0.3 0.3 0.3],'MarkerEdgeColor',[0 0 0],'LineWidth',2);
    Plot1.MarkerFaceAlpha=0.3;
    U=-unique(abs(All_Sharp_Wave_Deflection_Per_Tetrode(All_Sharp_Wave_Deflection_Per_Tetrode(:,N)<0 & All_Sharp_Wave_Deflection_Per_Tetrode(:,N)>-50,N)));
    Plot2=scatter(ones(length(U),1)*N,U,100,'v','MarkerFaceColor',[0.3 0.3 0.3],'MarkerEdgeColor',[0 0 0],'LineWidth',2);
    Plot2.MarkerFaceAlpha=0.3;
    U=unique(All_Sharp_Wave_Deflection_Per_Tetrode(All_Sharp_Wave_Deflection_Per_Tetrode(:,N)>=50,N));
    Plot3=scatter(ones(length(U),1)*N,U,100,'^','MarkerFaceColor','r','MarkerEdgeColor',[0 0 0],'LineWidth',2);
    Plot3.MarkerFaceAlpha=0.9;
    U=-unique(abs(All_Sharp_Wave_Deflection_Per_Tetrode(All_Sharp_Wave_Deflection_Per_Tetrode(:,N)<=-50,N)));
    Plot3=scatter(ones(length(U),1)*N,U,100,'v','MarkerFaceColor','b','MarkerEdgeColor',[0 0 0],'LineWidth',2);
    Plot3.MarkerFaceAlpha=0.9;
end
plot([0 N+1],[0 0],'k--','LineWidth',2);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0 N+1]);
set(gca,'YLim',[-350 350]);
set(gca,'YLim',[-400 400]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''All_Sessions_Sharp_Wave_Amplitude_Distributions_WithColor(X=SessionNumber)(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
cd ..
cd ..


end