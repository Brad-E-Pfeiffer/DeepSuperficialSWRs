function DSRP_COMPARE_SPIKE_AND_FIRING_PROPERTIES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This script loads the raw spike waveforms for each unimodal and bimodal
% neuron and quantifies various spike properties, such as half-width and
% height.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Spike Properties
% |                   1                       |            2         |                   3                  |              4               ||
% | Mean Spike Width Across All Four Tetrodes | Maximum Spike Height | Largest Spike Afterhyperpolarization | Spike Half-Height Width (ms) ||
% |                                           |                      |         Normalized to Peak           |                              || 
if exist('Spike_Properties.mat','file')==2
    load Spike_Properties.mat
else
    if exist('Spike_Waveforms.mat','file')==2
        load Spike_Waveforms
    else
        load Spike_Data
        Current_Directory=pwd;
        %This is where the orignal raw data is stored for the spike waveforms
        %The raw data is stored in bits; the conversion factor converts the bits into mV 
        if strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear1')
            Raw_Directory_Name='H:\Janni\2010-04-06_LinearTrack_NoReplay\2010-04-06_13-35-33';
            Conversion_Factor=32767/1.5;  %This session the input range was set to +/-1500uV.
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear2')
            Raw_Directory_Name='H:\Janni\2010-04-08_LinearTrack_NoReward_DifferentRun\2010-04-08_16-14-30';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear3')
            Raw_Directory_Name='H:\Janni\2010-04-10_LinearTrack_BigReward_DifferentRun\2010-04-10_12-24-11';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear4')
            Raw_Directory_Name='H:\Janni\2010-04-11_LinearTrack_OneReplay\2010-04-11_12-45-01';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear5')
            Raw_Directory_Name='H:\Janni\2010-04-12_LinearTrack_NoReward_SameRun\2010-04-12_15-51-58';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Linear6')
            Raw_Directory_Name='H:\Janni\2010-04-13_LinearTrack_BigReward_SameRun\2010-04-13_14-12-01';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Open1')
            Raw_Directory_Name='H:\Janni\2010-04-07_OpenField(Day_ZeroTwo)\2010-04-07_11-03-59';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Janni') && strcmp(Directory_Name,'Open2')
            Raw_Directory_Name='H:\Janni\2010-04-07_OpenField(DayOne)\2010-04-07_18-30-08';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Harpy') && strcmp(Directory_Name,'Linear1')
            Raw_Directory_Name='H:\Harpy\2010-01-08 One_Run_Trial\2010-01-08_12-33-36';
            Conversion_Factor=32767/0.5;  %This session the input range was set to +/-500uV.
        elseif strcmp(Rat_Name,'Harpy') && strcmp(Directory_Name,'Linear2')
            Raw_Directory_Name='H:\Harpy\2010-01-15 Linear_Track_BigReward_DuringRun\2010-01-15_16-36-30';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Harpy') && strcmp(Directory_Name,'Open1')
            Raw_Directory_Name='H:\Harpy\2010-01-10 First_Open_Field\2010-01-10_15-48-05';
            Conversion_Factor=32767/2;  %This session the input range was set to +/-2000uV.
        elseif strcmp(Rat_Name,'Harpy') && strcmp(Directory_Name,'Open2')
            Raw_Directory_Name='H:\Harpy\2010-01-12 Second_Open_Field\2010-01-12_15-20-49';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Imp') && strcmp(Directory_Name,'Linear1')
            Raw_Directory_Name='H:\Imp\2010-02-22 Linear_Track_Reward_Big_Reward_Separate\2010-02-22_17-29-17';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Imp') && strcmp(Directory_Name,'Linear2')
            Raw_Directory_Name='H:\Imp\2010-02-27 Linear_Track_Reward_Big_Reward_Same\2010-02-27_16-12-54';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Imp') && strcmp(Directory_Name,'Open1')
            Raw_Directory_Name='H:\Imp\2010-02-17 First Open Field Experiment\2010-02-17_17-23-35';
            Conversion_Factor=32767/1.5;
        elseif strcmp(Rat_Name,'Imp') && strcmp(Directory_Name,'Open2')
            Raw_Directory_Name='H:\Imp\2010-02-18 Second Open Field Experiment\2010-02-18_17-03-47';
            Conversion_Factor=32767/1.5;
        end
        cd(Raw_Directory_Name)
        
        Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
        Spike_Waveforms=zeros(32,4,size(Spike_Data,1));
        for Current_Tetrode=1:length(Tetrode_List)
            Tetrode_Name=sprintf('TT%d.ntt',Tetrode_List(Current_Tetrode));
            Raw_Spike_Times=Nlx2MatSpike(Tetrode_Name,[1 0 0 0 0],0,1)/1000000;
            Raw_Spike_Waveforms=Nlx2MatSpike(Tetrode_Name,[0 0 0 0 1],0,1)/Conversion_Factor; %in mV
            Cells_On_Current_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Tetrode_List(Current_Tetrode),2);
            for N=1:length(Cells_On_Current_Tetrode)
                Current_Cell=Cells_On_Current_Tetrode(N);
                Current_Cell_Spike_Times=Spike_Data(Spike_Data(:,2)==Current_Cell,1);
                Raw_Or_Clustered_Spike_Index=zeros(length(Current_Cell_Spike_Times),2);
                for M=1:size(Raw_Or_Clustered_Spike_Index,1)
                    Raw_Or_Clustered_Spike_Index(M,:)=[find(Raw_Spike_Times==Current_Cell_Spike_Times(M),1,'first'),find(Spike_Data(:,1)==Current_Cell_Spike_Times(M) & Spike_Data(:,2)==Current_Cell,1,'first')];
                end
                Spike_Waveforms(:,:,Raw_Or_Clustered_Spike_Index(:,2))=Raw_Spike_Waveforms(:,:,Raw_Or_Clustered_Spike_Index(:,1));
                clear M;
                clear Current_Cell
                clear Current_Cell_Spike_Times;
                clear Raw_Or_Clustered_Spike_Index;
            end
            clear N;
            clear Raw_Spike_Times;
            clear Raw_Spike_Waveforms;
            clear Cells_On_Current_Tetrode;
            fprintf('Finished loading spike waveforms for Tetrode %d (%d of %d).\n',Tetrode_List(Current_Tetrode),Current_Tetrode,length(Tetrode_List));
        end
        clear Current_Tetrode;
        cd(Current_Directory);
        clear Tetrode_List;
        clear Raw_Directory_Name;
        clear Current_Directory;
        save('Spike_Waveforms','Spike_Waveforms','-v7.3');
    end
    
    % Spike_Properties (each page is Electrode 1-4)
    % |        1     |             2             |                 3             |               4                ||
    % | Spike Height | Spike Width (Peak to Min) | Spike Afterhyperpolariazation | Spike Half-Height Width (msec) ||
    % |    (in mV)   |         (in msec)         |       Normalized to Peak      |                                || 
    
    % The way the spike amplitudes were quantified for clustering is to
    % simply find the maximum, which isn't always temporally aligned, so
    % this program re-aligns based on the peak amplitude to get a more
    % accurate measure of the spike properties.
    
    Recentered_Spike_Waveforms=zeros(size(Spike_Waveforms));
    parfor Spike=1:size(Spike_Waveforms,3)
        [Max1,Location1]=max(Spike_Waveforms(:,1,Spike));
        [Max2,Location2]=max(Spike_Waveforms(:,2,Spike));
        [Max3,Location3]=max(Spike_Waveforms(:,3,Spike));
        [Max4,Location4]=max(Spike_Waveforms(:,4,Spike));
        Maxes=[Max1,Max2,Max3,Max4];
        Locations=[Location1,Location2,Location3,Location4];
        [~,Max_Location]=max(Maxes);
        Max_Location=Locations(Max_Location);
        Current_Spike_Waveforms=Spike_Waveforms(:,:,Spike);
        if Max_Location<8
            Diff=8-Max_Location;
            Current_Spike_Waveforms=[zeros(Diff,4);Current_Spike_Waveforms(1:(size(Current_Spike_Waveforms,1)-Diff),:)];
        elseif Max_Location>8
            Diff=Max_Location-8;
            Current_Spike_Waveforms=[Current_Spike_Waveforms((Diff+1):size(Current_Spike_Waveforms,1),:);zeros(Diff,4)];
        end
        Recentered_Spike_Waveforms(:,:,Spike)=Current_Spike_Waveforms;
    end
    
    Spike_Properties=zeros(size(Recentered_Spike_Waveforms,3),4,4);
    parfor Spike=1:size(Recentered_Spike_Waveforms,3)
        Current_Spike_Waveforms=Recentered_Spike_Waveforms(:,:,Spike);
        Spike1=interp1(1:32,Current_Spike_Waveforms(:,1),1:0.1:32,'spline');
        Spike2=interp1(1:32,Current_Spike_Waveforms(:,2),1:0.1:32,'spline');
        Spike3=interp1(1:32,Current_Spike_Waveforms(:,3),1:0.1:32,'spline');
        Spike4=interp1(1:32,Current_Spike_Waveforms(:,4),1:0.1:32,'spline');
        
        %Finds the max between ~100 and ~375 usec
        [Max1,Max1Location]=max(Spike1(40:120));
        [Max2,Max2Location]=max(Spike2(40:120));
        [Max3,Max3Location]=max(Spike3(40:120));
        [Max4,Max4Location]=max(Spike4(40:120));
        Max1Location=Max1Location+39; %This corrects the location to account for the fact that I'm only looking for the max starting from bin 40
        Max2Location=Max2Location+39;
        Max3Location=Max3Location+39;
        Max4Location=Max4Location+39;
        
        %Finds the min of the afterhyperpolarization between ~310 and ~625 usec 
        [Min1,Min1Location]=min(Spike1(100:200));
        [Min2,Min2Location]=min(Spike2(100:200));
        [Min3,Min3Location]=min(Spike3(100:200));
        [Min4,Min4Location]=min(Spike4(100:200));
        Min1Location=Min1Location+99; %This corrects the location to account for the fact that I'm only looking for the max starting from bin 100
        Min2Location=Min2Location+99;
        Min3Location=Min3Location+99;
        Min4Location=Min4Location+99;
        
        if Max1>0
            Normalized_Afterhyperpolarization1=Min1/Max1;
        else
            Normalized_Afterhyperpolarization1=nan(1);
        end
        if Max2>0
            Normalized_Afterhyperpolarization2=Min2/Max2;
        else
            Normalized_Afterhyperpolarization2=nan(1);
        end
        if Max3>0
            Normalized_Afterhyperpolarization3=Min3/Max3;
        else
            Normalized_Afterhyperpolarization3=nan(1);
        end
        if Max4>0
            Normalized_Afterhyperpolarization4=Min4/Max4;
        else
            Normalized_Afterhyperpolarization4=nan(1);
        end
        
        Spike1_Prepeak=Spike1(1:Max1Location);
        Spike2_Prepeak=Spike2(1:Max2Location);
        Spike3_Prepeak=Spike3(1:Max3Location);
        Spike4_Prepeak=Spike4(1:Max4Location);
        Spike1_Postpeak=Spike1(Max1Location:end);
        Spike2_Postpeak=Spike2(Max2Location:end);
        Spike3_Postpeak=Spike3(Max3Location:end);
        Spike4_Postpeak=Spike4(Max4Location:end);
        Spike1_Prepeak_Halfheight_Location=max([1,find(Spike1_Prepeak<=(Max1/2),1,'last')]);
        Spike2_Prepeak_Halfheight_Location=max([1,find(Spike2_Prepeak<=(Max2/2),1,'last')]);
        Spike3_Prepeak_Halfheight_Location=max([1,find(Spike3_Prepeak<=(Max3/2),1,'last')]);
        Spike4_Prepeak_Halfheight_Location=max([1,find(Spike4_Prepeak<=(Max4/2),1,'last')]);
        Spike1_Postpeak_Halfheight_Location=min([length(Spike1_Postpeak),find(Spike1_Postpeak<=(Max1/2),1,'first')+(Max1Location-1)]);
        Spike2_Postpeak_Halfheight_Location=min([length(Spike2_Postpeak),find(Spike2_Postpeak<=(Max2/2),1,'first')+(Max2Location-1)]);
        Spike3_Postpeak_Halfheight_Location=min([length(Spike3_Postpeak),find(Spike3_Postpeak<=(Max3/2),1,'first')+(Max3Location-1)]);
        Spike4_Postpeak_Halfheight_Location=min([length(Spike4_Postpeak),find(Spike4_Postpeak<=(Max4/2),1,'first')+(Max4Location-1)]);
        
        Spike_Properties(Spike,:,:)=permute([[Max1,Max2,Max3,Max4];[Min1Location-Max1Location,Min2Location-Max2Location,Min3Location-Max3Location,Min4Location-Max4Location]/310;[Normalized_Afterhyperpolarization1,Normalized_Afterhyperpolarization2,Normalized_Afterhyperpolarization3,Normalized_Afterhyperpolarization4];[Spike1_Postpeak_Halfheight_Location-Spike1_Prepeak_Halfheight_Location,Spike2_Postpeak_Halfheight_Location-Spike2_Prepeak_Halfheight_Location,Spike3_Postpeak_Halfheight_Location-Spike3_Prepeak_Halfheight_Location,Spike4_Postpeak_Halfheight_Location-Spike4_Prepeak_Halfheight_Location]/310],[3,1,2]);
    end
    
    % This removes spikes during the noisy periods
    if eval(sprintf('isfield(Timepoints_To_Remove,''%s_%s_To_Remove'')',Rat_Name,Directory_Name))
        eval(sprintf('Sections_To_Remove=%s_%s_To_Remove;',Rat_Name,Directory_Name));
        for Section=1:size(Sections_To_Remove,1)
            Spike_Properties=Spike_Properties(Spike_Data(:,1)<Sections_To_Remove(Section,1) | Spike_Data(:,1)>Sections_To_Remove(Section,2),:,:);
            Spike_Data=Spike_Data(Spike_Data(:,1)<Sections_To_Remove(Section,1) | Spike_Data(:,1)>Sections_To_Remove(Section,2),:);
        end
        clear Section
    end
    clear Sections_To_Remove

    % Average_Spike_Properties_Per_Cell
    % |        1     |             2             |                 3             |               4                |        5       |
    % | Spike Height | Spike Width (Peak to Min) | Spike Afterhyperpolariazation | Spike Half-Height Width (msec) | Bursting Index |
    % |    (in mV)   |         (in msec)         |       Normalized to Peak      |                                |                | 

    % The average properties per cell are based on the single electrode that had the highest average amplitude spike 
    Average_Spike_Properties_Per_Cell=zeros(max(Spike_Data(:,2)),4,2);
    for Current_Cell=1:max(Spike_Data(:,2))
        Current_Cell_Properties=Spike_Properties(Spike_Data(:,2)==Current_Cell,:,:);
        Mean_Amplitudes=permute(mean(Current_Cell_Properties(:,1,:),1),[3,2,1]);
        [~,Electrode_To_Use]=max(Mean_Amplitudes);
        Current_Cell_Properties=Current_Cell_Properties(:,:,Electrode_To_Use);
        Average_Spike_Properties_Per_Cell(Current_Cell,:,1)=mean(Current_Cell_Properties,1,'omitnan');
        Average_Spike_Properties_Per_Cell(Current_Cell,:,2)=std(Current_Cell_Properties,'omitnan')/sqrt(size(Current_Cell_Properties,1));
    end
    Average_Spike_Properties_Per_Cell(:,5,:)=0;
    for Current_Cell=1:max(Spike_Data(:,2))
        Current_Cell_Spike_Data=Spike_Data(Spike_Data(:,2)==Current_Cell,:);
        Number_Of_Spikes=size(Current_Cell_Spike_Data,1);
        Closest_Interspike_Intervals=zeros(size(Current_Cell_Spike_Data,1),1);
        if Number_Of_Spikes>2
            Closest_Interspike_Intervals(1,1)=Current_Cell_Spike_Data(2,1)-Current_Cell_Spike_Data(1,1);
            Closest_Interspike_Intervals(end,1)=Current_Cell_Spike_Data(end,1)-Current_Cell_Spike_Data(end-1,1);
            for N=2:(size(Current_Cell_Spike_Data,1)-1)
                Closest_Interspike_Intervals(N,1)=min([Current_Cell_Spike_Data(N,1)-Current_Cell_Spike_Data(N-1,1),Current_Cell_Spike_Data(N+1,1)-Current_Cell_Spike_Data(N,1)]);
            end
            Number_Of_Bursting_Spikes=sum(Closest_Interspike_Intervals(:,1)<=0.006);
            Bursting_Spike_Index=Number_Of_Bursting_Spikes/Number_Of_Spikes;
            Average_Spike_Properties_Per_Cell(Current_Cell,5,1)=Bursting_Spike_Index;
        end
    end
        
    save('Spike_Properties','Spike_Properties','Average_Spike_Properties_Per_Cell');
    
end


end