function DSRP_PLOT_SHARP_WAVE_DEFLECTION_VS_RIPPLE_PHASE_OFFSET(Initial_Variables)

Limit_To_Run=0;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
        load('Epochs','Run_Times')
        load('Ripple_Events','Ripple_Events')
        if Limit_To_Run
            Ripple_Events_Sharp_Wave_Deflections=Ripple_Events_Sharp_Wave_Deflections(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
            Ripple_Events=Ripple_Events(Ripple_Events(:,1)>=Run_Times(1,1) & Ripple_Events(:,2)<=Run_Times(1,2),:,:);
        end
        Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
        load('Spike_Data','Inhibitory_Neurons');
        load('Spike_Data_With_Ripple_Phase');
        for N=1:length(Inhibitory_Neurons)
            Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
        end
        Ripple_Spike_Data=Spike_Data(1,:);
        for N=1:size(Ripple_Events,1)
            Ripple_Spike_Data=[Ripple_Spike_Data;Spike_Data(Spike_Data(:,1)>=Ripple_Events(N,1) & Spike_Data(:,1)<=Ripple_Events(N,2),:)];
        end
        Ripple_Spike_Data=Ripple_Spike_Data(2:end,:);
        Ripple_Spike_Data(:,5)=NaN;
        load('Spike_Data','Tetrode_Cell_IDs');
        Tetrode_List=unique(Tetrode_Cell_IDs(:,1));
        for TT=1:length(Tetrode_List)
            Current_Tetrode=Tetrode_List(TT);
            Cell_List=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2);
            Sharp_Wave_Offset=Sharp_Wave_Deflection_Per_Tetrode(Current_Tetrode,1);
            if ~isempty(Cell_List)
                for CC=1:length(Cell_List)
                    Current_Cell=Cell_List(CC);
                    Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Current_Cell,5)=Sharp_Wave_Offset;
                    if exist('Per_Cell_Phase_Offset','var')
                        Per_Cell_Phase_Offset=[Per_Cell_Phase_Offset;[Current_Cell,mean(Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Current_Cell,3),'omitnan'),Sharp_Wave_Offset]];
                    else
                        Per_Cell_Phase_Offset=[Current_Cell,mean(Ripple_Spike_Data(Ripple_Spike_Data(:,2)==Current_Cell,3),'omitnan'),Sharp_Wave_Offset];
                    end
                end
            end
        end

        cd ..

    end
    clear Directory
    cd ..
end

Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection=[0,0,0];
for N=-300:10:300
    if ~isempty(Per_Cell_Phase_Offset(:,3)>=N & Per_Cell_Phase_Offset(:,3)<=(N+10))
        Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection=[Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection;[mean(Per_Cell_Phase_Offset(Per_Cell_Phase_Offset(:,3)>=N & Per_Cell_Phase_Offset(:,3)<=(N+10),2),'omitnan'),std(Per_Cell_Phase_Offset(Per_Cell_Phase_Offset(:,3)>=N & Per_Cell_Phase_Offset(:,3)<=(N+10),2),'omitnan')/sqrt(sum(Per_Cell_Phase_Offset(:,3)>=N & Per_Cell_Phase_Offset(:,3)<=(N+10))),N]];
    end
end
Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection=Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(2:end,:);
Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection=Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(~isnan(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,1)),:);
Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection=Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3)>=-200 & Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3)<=200,:);

figure;
hold on;
subplot('Position',[0 0 1 1])
hold on;
plot(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,1),Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3),'ok','MarkerFaceColor','k','MarkerSize',10)
for N=1:size(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection,1)
    plot([Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,1)-Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,2),Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,1)+Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,2)],[Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,3),Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(N,3)],'k');
end
Coeff=polyfit(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3),Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,1),1);
Y_Vals=polyval(Coeff,[min(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3)),max(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3))]);
plot([Y_Vals(1),Y_Vals(2)],[min(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3)),max(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3))],'k--','LineWidth',3)
set(gca,'YLim',[-210 210]);
set(gca,'XLim',[155 215]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
cd _Figures
print('-djpeg','Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(10uVBins,X=150to210,Y=-200to200).jpg');
close
cd ..

[Ripple_Phase_SW_Offset_R,Ripple_Phase_SW_Offset_P]=corr(Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,3),Mean_SEM_Ripple_Phase_Offset_Per_Sharp_Wave_Deflection(:,1))

end
