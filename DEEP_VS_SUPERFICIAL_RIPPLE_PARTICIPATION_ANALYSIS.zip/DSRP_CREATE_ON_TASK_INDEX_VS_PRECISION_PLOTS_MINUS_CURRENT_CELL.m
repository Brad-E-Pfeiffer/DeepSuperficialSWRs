function DSRP_CREATE_ON_TASK_INDEX_VS_PRECISION_PLOTS_MINUS_CURRENT_CELL(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot On-Task Peak Firing Rate Vs. Experience Modulation of Ripple Firing For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================

cd AllRatsCombined

load All_Cell_Precision_In_Replay_Minus_Current_Cell
load All_Firing_Properties_During_Behavior

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity')
    mkdir('Experience_Modulation_Of_SWR_Activity')
end
cd 'Experience_Modulation_Of_SWR_Activity'

if ~isfolder('Correlation_In_OnTask_Firing_And_Ripple_Modulation')
    mkdir('Correlation_In_OnTask_Firing_And_Ripple_Modulation')
end
cd('Correlation_In_OnTask_Firing_And_Ripple_Modulation')

%--------------------------------------------------------------------------

%Precision for Large Cells for All Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Cell_Precision(:,8,1)./All_Large_Deep_Cell_Precision(:,2,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Cell_Precision(:,8,1)./All_Large_Super_Cell_Precision(:,2,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[0 1])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Precision_All_Corr_R,Large_Deep_Precision_All_Corr_P]=corr(Deep(Deep(:,1)>=0,1),Deep(Deep(:,1)>=0,2))
[Large_Super_Precision_All_Corr_R,Large_Super_Precision_All_Corr_P]=corr(Super(Super(:,1)>=0,1),Super(Super(:,1)>=0,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0),1)*2,Deep(Deep(:,1)>0,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*3,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0),1)*4,Super(Super(:,1)>0,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_All_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_All_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Precision_All_Lo_P=signrank(Deep(Deep(:,1)<=0,2))*4  %*4 for Bonferroni correction
Large_Deep_Precision_All_Hi_P=signrank(Deep(Deep(:,1)>0,2))*4
Large_Super_Precision_All_Lo_P=signrank(Super(Super(:,1)<=0,2))*4
Large_Super_Precision_All_Hi_P=signrank(Super(Super(:,1)>0,2))*4

%--------------------------------------------------------------------------

%Precision for Large Cells for Coherent Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,1)-All_Large_Deep_Firing_Properties_During_Behavior(:,4))./(All_Large_Deep_Firing_Properties_During_Behavior(:,1)+All_Large_Deep_Firing_Properties_During_Behavior(:,4)),log(All_Large_Deep_Cell_Precision(:,9,1)./All_Large_Deep_Cell_Precision(:,3,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,1)-All_Large_Super_Firing_Properties_During_Behavior(:,4))./(All_Large_Super_Firing_Properties_During_Behavior(:,1)+All_Large_Super_Firing_Properties_During_Behavior(:,4)),log(All_Large_Super_Cell_Precision(:,9,1)./All_Large_Super_Cell_Precision(:,3,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
Start=-0.9;
End=0.9;
Step=0.2;
for N=Start:Step:End
    D=Deep(Deep(:,1)>(N-Step/2) & Deep(:,1)<=(N+Step/2),2);
    S=Super(Super(:,1)>(N-Step/2) & Super(:,1)<=(N+Step/2),2);
    if ~isempty(D)
        plot([N-(Step/20)+(Step/10),N-(Step/20)-(Step/10)],[mean(D,'omitnan'),mean(D,'omitnan')],'LineWidth',8,'Color',[0.7 0 0]);
        if length(D)>1
            plot([N-(Step/20),N-(Step/20)],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'LineWidth',4,'Color',[0.7 0 0]);
        end
    end
    if ~isempty(S)
        plot([N+(Step/20)+(Step/10),N+(Step/20)-(Step/10)],[mean(S,'omitnan'),mean(S,'omitnan')],'LineWidth',8,'Color',[0 0 0.7]);
        if length(S)>1
            plot([N+(Step/20),N+(Step/20)],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'LineWidth',4,'Color',[0 0 0.7]);
        end
    end
end
set(gca,'XLim',[0 1])
set(gca,'XTick',[]);
set(gca,'YTick',[]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Precision_All_Corr_R,Large_Deep_Precision_All_Corr_P]=corr(Deep(Deep(:,1)>=0,1),Deep(Deep(:,1)>=0,2))
[Large_Super_Precision_All_Corr_R,Large_Super_Precision_All_Corr_P]=corr(Super(Super(:,1)>=0,1),Super(Super(:,1)>=0,2))

N=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=N),1)*1,Deep(Deep(:,1)<=N,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>N),1)*2,Deep(Deep(:,1)>N,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=N),1)*3,Super(Super(:,1)<=N,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>N),1)*4,Super(Super(:,1)>N,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 4.5]);
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 5],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''OnTask_Firing_Rate_Index_Vs_Precision_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Precision_Coherent_Lo_P=signrank(Deep(Deep(:,1)<=N,2))*4  %*4 for Bonferroni correction
Large_Deep_Precision_Coherent_Hi_P=signrank(Deep(Deep(:,1)>N,2))*4
Large_Super_Precision_Coherent_Lo_P=signrank(Super(Super(:,1)<=N,2))*4
Large_Super_Precision_Coherent_Hi_P=signrank(Super(Super(:,1)>N,2))*4

%--------------------------------------------------------------------------

cd ..
cd ..
cd ..


end

