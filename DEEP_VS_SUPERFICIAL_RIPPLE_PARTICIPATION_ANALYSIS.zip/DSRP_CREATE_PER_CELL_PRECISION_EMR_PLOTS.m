function DSRP_CREATE_PER_CELL_PRECISION_EMR_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot Cell Precision In Replay For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================

cd AllRatsCombined

load All_Cell_Precision_In_Replay

cd ..
cd _Figures
if ~isfolder('Cell_Precision')
    mkdir('Cell_Precision')
end
cd('Cell_Precision')
if ~isfolder('Large_Cell_Precision')
    mkdir('Large_Cell_Precision')
end
cd('Large_Cell_Precision')

% Per_Deep/Super/LargeDeep/LargeSuper_Cell_Firing_Precision (All values are measures of "precision" in SWRs: the distance between decoding peak and place field peak)
% Page 1 is Sleep and Wake Combined, Page 2 is Sleep Only, Page 3 is Wake Only
% |    1    |     2   |        3     |         4      |      5     |        6        |          7        |      8   |       9       |        10       ||
% | Cell ID | All Pre | Coherent Pre | Fragmented Pre | All OnTask | Coherent OnTask | Fragmented OnTask | All Post | Coherent Post | Fragmented Post ||

%--------------------------------------------------------------------------

%Precision for Large Cells for All Ripples

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,8,1)),8,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,2,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,8,1)),2,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,2,1)) & ~isnan(All_Large_Super_Cell_Precision(:,8,1)),8,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,2,1)) & ~isnan(All_Large_Super_Cell_Precision(:,8,1)),2,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_All_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_All_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_All_Precision_P=signrank(Super_Index)*2

%--------------------------------------------------------------------------

%Precision for Large Cells for Coherent Ripples

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,9,1)),9,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,3,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,9,1)),3,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,3,1)) & ~isnan(All_Large_Super_Cell_Precision(:,9,1)),9,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,3,1)) & ~isnan(All_Large_Super_Cell_Precision(:,9,1)),3,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Coherent_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Coherent_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Coherent_Precision_P=signrank(Super_Index)*2

%--------------------------------------------------------------------------

%Precision for Large Cells for Fragmented Ripples

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Index=log(All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,10,1)),10,1)./All_Large_Deep_Cell_Precision(~isnan(All_Large_Deep_Cell_Precision(:,4,1)) & ~isnan(All_Large_Deep_Cell_Precision(:,10,1)),4,1));
Deep_Index=Deep_Index(~isnan(Deep_Index));
Super_Index=log(All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,4,1)) & ~isnan(All_Large_Super_Cell_Precision(:,10,1)),10,1)./All_Large_Super_Cell_Precision(~isnan(All_Large_Super_Cell_Precision(:,4,1)) & ~isnan(All_Large_Super_Cell_Precision(:,10,1)),4,1));
Super_Index=Super_Index(~isnan(Super_Index));
plot([0 3],[0 0],'k--')
boxchart(ones(length(Deep_Index),1)*1,Deep_Index,'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(length(Super_Index),1)*2,Super_Index,'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
set(gca,'XLim',[0.5 2.5]);
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Cell_Precision_In_Fragmented_Ripples(Deep,Super,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Per_Large_Cell_Deep_Fragmented_Precision_P=signrank(Deep_Index)*2 %Times 2 for Bonferroni correction
Per_Large_Cell_Superficial_Fragmented_Precision_P=signrank(Super_Index)*2

cd ..
cd ..
cd ..


end

