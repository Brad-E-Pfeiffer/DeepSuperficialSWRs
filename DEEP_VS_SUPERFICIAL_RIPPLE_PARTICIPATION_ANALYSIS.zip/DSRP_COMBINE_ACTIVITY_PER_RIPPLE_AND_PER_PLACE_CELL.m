function DSRP_COMBINE_ACTIVITY_PER_RIPPLE_AND_PER_PLACE_CELL(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function pulls up Activity_Per_Ripple_Per_Place_Cell and combines
% those data across rats.  The data are combined on a per-cell and a
% per-session basis.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Activity_Per_Ripple_Per_Cell
% Each Row is a Ripple
% Each Column is a Cell
% Page 1 is participation (1 if it fired, 0 if it didn't)
% Page 2 is number of spikes
% Page 3 is firing rate (excluding SWRs in which the cell didn't fire)
% Page 4 is firing rate including zeros

% For all combined data (except X_Non_SWS):
% |           1           |                                     2                           |              3            |                               4                           ||
% | Participation Percent | Number of Spikes (including zeros from Non-Participating Cells) | Participating Firing Rate | Firing Rate (including zeros from Non-Participating Cells ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        load('Activity_Per_Ripple_Per_Place_Cell','Activity_Per_Ripple_Per_Place_Cell')
        load Deep_And_Superficial_Cell_Identities
        load Ripple_Categories
        load Firing_Properties_Per_Cell_During_Behavior

        %Deep/Super_Non_SWS (Column 1 is pre-rest mean non-SWS firing rate, Column 2 is post-rest mean non-SWS firing rate) 
        Deep_Non_SWS=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Deep_Cells),[7,11]);
        Super_Non_SWS=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Superficial_Cells),[7,11]);
        Large_Deep_Non_SWS=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Deep_Cells),[7,11]);
        Large_Super_Non_SWS=Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Superficial_Cells),[7,11]);

        Deep_Pre_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Deep_Cells,:);
        Super_Pre_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Superficial_Cells,:);
        Large_Deep_Pre_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Large_Deep_Cells,:);
        Large_Super_Pre_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Large_Superficial_Cells,:);

        Deep_Pre_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Deep_Cells,:);
        Super_Pre_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Superficial_Cells,:);
        Large_Deep_Pre_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Large_Deep_Cells,:);
        Large_Super_Pre_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Large_Superficial_Cells,:);

        Deep_Pre_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)~=1,Deep_Cells,:);
        Super_Pre_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)~=1,Superficial_Cells,:);
        Large_Deep_Pre_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)~=1,Large_Deep_Cells,:);
        Large_Super_Pre_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)~=1,Large_Superficial_Cells,:);

        Deep_Pre_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Deep_Cells,:);
        Super_Pre_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Superficial_Cells,:);
        Large_Deep_Pre_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Large_Deep_Cells,:);
        Large_Super_Pre_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==1 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Large_Superficial_Cells,:);

        Deep_Early_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Deep_Cells,:);
        Super_Early_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Superficial_Cells,:);
        Large_Deep_Early_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Large_Deep_Cells,:);
        Large_Super_Early_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Large_Superficial_Cells,:);

        Deep_Early_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Deep_Cells,:);
        Super_Early_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Superficial_Cells,:);
        Large_Deep_Early_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Large_Deep_Cells,:);
        Large_Super_Early_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Large_Superficial_Cells,:);

        Deep_Early_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Deep_Cells,:);
        Super_Early_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Superficial_Cells,:);
        Large_Deep_Early_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Large_Deep_Cells,:);
        Large_Super_Early_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Large_Superficial_Cells,:);

        Deep_Late_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Deep_Cells,:);
        Super_Late_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Superficial_Cells,:);
        Large_Deep_Late_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Large_Deep_Cells,:);
        Large_Super_Late_Task_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2),Large_Superficial_Cells,:);

        Deep_Late_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Deep_Cells,:);
        Super_Late_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Superficial_Cells,:);
        Large_Deep_Late_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Large_Deep_Cells,:);
        Large_Super_Late_Task_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==1,Large_Superficial_Cells,:);

        Deep_Late_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Deep_Cells,:);
        Super_Late_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Superficial_Cells,:);
        Large_Deep_Late_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Large_Deep_Cells,:);
        Large_Super_Late_Task_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==2 & Ripple_Categories(:,5)>Initial_Variables.Early_Late_Fraction(1,2) & Ripple_Categories(:,4)==2,Large_Superficial_Cells,:);

        Deep_Post_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Deep_Cells,:);
        Super_Post_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Superficial_Cells,:);
        Large_Deep_Post_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Large_Deep_Cells,:);
        Large_Super_Post_All=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1),Large_Superficial_Cells,:);

        Deep_Post_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Deep_Cells,:);
        Super_Post_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Superficial_Cells,:);
        Large_Deep_Post_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Large_Deep_Cells,:);
        Large_Super_Post_Coherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==1,Large_Superficial_Cells,:);

        Deep_Post_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)~=1,Deep_Cells,:);
        Super_Post_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)~=1,Superficial_Cells,:);
        Large_Deep_Post_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)~=1,Large_Deep_Cells,:);
        Large_Super_Post_Incoherent=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)~=1,Large_Superficial_Cells,:);

        Deep_Post_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Deep_Cells,:);
        Super_Post_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Superficial_Cells,:);
        Large_Deep_Post_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Large_Deep_Cells,:);
        Large_Super_Post_Fragmented=Activity_Per_Ripple_Per_Place_Cell(Ripple_Categories(:,2)==3 & Ripple_Categories(:,5)<Initial_Variables.Early_Late_Fraction(1,1) & Ripple_Categories(:,4)==2,Large_Superficial_Cells,:);

        %Average Across Ripples (Per Cell Analysis)
        Deep_Per_Cell_Pre_All=permute(mean(Deep_Pre_All,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Pre_All=permute(mean(Super_Pre_All,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Pre_All=permute(mean(Large_Deep_Pre_All,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Pre_All=permute(mean(Large_Super_Pre_All,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Pre_Coherent=permute(mean(Deep_Pre_Coherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Pre_Coherent=permute(mean(Super_Pre_Coherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Pre_Coherent=permute(mean(Large_Deep_Pre_Coherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Pre_Coherent=permute(mean(Large_Super_Pre_Coherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Pre_Incoherent=permute(mean(Deep_Pre_Incoherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Pre_Incoherent=permute(mean(Super_Pre_Incoherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Pre_Incoherent=permute(mean(Large_Deep_Pre_Incoherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Pre_Incoherent=permute(mean(Large_Super_Pre_Incoherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Pre_Fragmented=permute(mean(Deep_Pre_Fragmented,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Pre_Fragmented=permute(mean(Super_Pre_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Pre_Fragmented=permute(mean(Large_Deep_Pre_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Pre_Fragmented=permute(mean(Large_Super_Pre_Fragmented,1,'omitnan'),[2,3,1]);

        Deep_Per_Cell_Early_Task_All=permute(mean(Deep_Early_Task_All,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Early_Task_All=permute(mean(Super_Early_Task_All,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Early_Task_All=permute(mean(Large_Deep_Early_Task_All,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Early_Task_All=permute(mean(Large_Super_Early_Task_All,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Early_Task_Coherent=permute(mean(Deep_Early_Task_Coherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Early_Task_Coherent=permute(mean(Super_Early_Task_Coherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Early_Task_Coherent=permute(mean(Large_Deep_Early_Task_Coherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Early_Task_Coherent=permute(mean(Large_Super_Early_Task_Coherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Early_Task_Fragmented=permute(mean(Deep_Early_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Early_Task_Fragmented=permute(mean(Super_Early_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Early_Task_Fragmented=permute(mean(Large_Deep_Early_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Early_Task_Fragmented=permute(mean(Large_Super_Early_Task_Fragmented,1,'omitnan'),[2,3,1]);

        Deep_Per_Cell_Late_Task_All=permute(mean(Deep_Late_Task_All,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Late_Task_All=permute(mean(Super_Late_Task_All,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Late_Task_All=permute(mean(Large_Deep_Late_Task_All,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Late_Task_All=permute(mean(Large_Super_Late_Task_All,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Late_Task_Coherent=permute(mean(Deep_Late_Task_Coherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Late_Task_Coherent=permute(mean(Super_Late_Task_Coherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Late_Task_Coherent=permute(mean(Large_Deep_Late_Task_Coherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Late_Task_Coherent=permute(mean(Large_Super_Late_Task_Coherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Late_Task_Fragmented=permute(mean(Deep_Late_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Late_Task_Fragmented=permute(mean(Super_Late_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Late_Task_Fragmented=permute(mean(Large_Deep_Late_Task_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Late_Task_Fragmented=permute(mean(Large_Super_Late_Task_Fragmented,1,'omitnan'),[2,3,1]);

        Deep_Per_Cell_Post_All=permute(mean(Deep_Post_All,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Post_All=permute(mean(Super_Post_All,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Post_All=permute(mean(Large_Deep_Post_All,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Post_All=permute(mean(Large_Super_Post_All,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Post_Coherent=permute(mean(Deep_Post_Coherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Post_Coherent=permute(mean(Super_Post_Coherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Post_Coherent=permute(mean(Large_Deep_Post_Coherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Post_Coherent=permute(mean(Large_Super_Post_Coherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Post_Incoherent=permute(mean(Deep_Post_Incoherent,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Post_Incoherent=permute(mean(Super_Post_Incoherent,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Post_Incoherent=permute(mean(Large_Deep_Post_Incoherent,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Post_Incoherent=permute(mean(Large_Super_Post_Incoherent,1,'omitnan'),[2,3,1]);
        
        Deep_Per_Cell_Post_Fragmented=permute(mean(Deep_Post_Fragmented,1,'omitnan'),[2,3,1]);
        Super_Per_Cell_Post_Fragmented=permute(mean(Super_Post_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Deep_Per_Cell_Post_Fragmented=permute(mean(Large_Deep_Post_Fragmented,1,'omitnan'),[2,3,1]);
        Large_Super_Per_Cell_Post_Fragmented=permute(mean(Large_Super_Post_Fragmented,1,'omitnan'),[2,3,1]);

        %Combine Across Rats
        if exist('All_Deep_Per_Cell_Pre_All','var')
            All_Deep_Non_SWS=[All_Deep_Non_SWS;Deep_Non_SWS];
            All_Super_Non_SWS=[All_Super_Non_SWS;Super_Non_SWS];
            All_Large_Deep_Non_SWS=[All_Large_Deep_Non_SWS;Large_Deep_Non_SWS];
            All_Large_Super_Non_SWS=[All_Large_Super_Non_SWS;Large_Super_Non_SWS];

            All_Deep_Per_Cell_Pre_All=[All_Deep_Per_Cell_Pre_All;Deep_Per_Cell_Pre_All];
            All_Super_Per_Cell_Pre_All=[All_Super_Per_Cell_Pre_All;Super_Per_Cell_Pre_All];
            All_Large_Deep_Per_Cell_Pre_All=[All_Large_Deep_Per_Cell_Pre_All;Large_Deep_Per_Cell_Pre_All];
            All_Large_Super_Per_Cell_Pre_All=[All_Large_Super_Per_Cell_Pre_All;Large_Super_Per_Cell_Pre_All];

            All_Deep_Per_Cell_Pre_Coherent=[All_Deep_Per_Cell_Pre_Coherent;Deep_Per_Cell_Pre_Coherent];
            All_Super_Per_Cell_Pre_Coherent=[All_Super_Per_Cell_Pre_Coherent;Super_Per_Cell_Pre_Coherent];
            All_Large_Deep_Per_Cell_Pre_Coherent=[All_Large_Deep_Per_Cell_Pre_Coherent;Large_Deep_Per_Cell_Pre_Coherent];
            All_Large_Super_Per_Cell_Pre_Coherent=[All_Large_Super_Per_Cell_Pre_Coherent;Large_Super_Per_Cell_Pre_Coherent];

            All_Deep_Per_Cell_Pre_Incoherent=[All_Deep_Per_Cell_Pre_Incoherent;Deep_Per_Cell_Pre_Incoherent];
            All_Super_Per_Cell_Pre_Incoherent=[All_Super_Per_Cell_Pre_Incoherent;Super_Per_Cell_Pre_Incoherent];
            All_Large_Deep_Per_Cell_Pre_Incoherent=[All_Large_Deep_Per_Cell_Pre_Incoherent;Large_Deep_Per_Cell_Pre_Incoherent];
            All_Large_Super_Per_Cell_Pre_Incoherent=[All_Large_Super_Per_Cell_Pre_Incoherent;Large_Super_Per_Cell_Pre_Incoherent];

            All_Deep_Per_Cell_Pre_Fragmented=[All_Deep_Per_Cell_Pre_Fragmented;Deep_Per_Cell_Pre_Fragmented];
            All_Super_Per_Cell_Pre_Fragmented=[All_Super_Per_Cell_Pre_Fragmented;Super_Per_Cell_Pre_Fragmented];
            All_Large_Deep_Per_Cell_Pre_Fragmented=[All_Large_Deep_Per_Cell_Pre_Fragmented;Large_Deep_Per_Cell_Pre_Fragmented];
            All_Large_Super_Per_Cell_Pre_Fragmented=[All_Large_Super_Per_Cell_Pre_Fragmented;Large_Super_Per_Cell_Pre_Fragmented];

            All_Deep_Per_Cell_Early_Task_All=[All_Deep_Per_Cell_Early_Task_All;Deep_Per_Cell_Early_Task_All];
            All_Super_Per_Cell_Early_Task_All=[All_Super_Per_Cell_Early_Task_All;Super_Per_Cell_Early_Task_All];
            All_Large_Deep_Per_Cell_Early_Task_All=[All_Large_Deep_Per_Cell_Early_Task_All;Large_Deep_Per_Cell_Early_Task_All];
            All_Large_Super_Per_Cell_Early_Task_All=[All_Large_Super_Per_Cell_Early_Task_All;Large_Super_Per_Cell_Early_Task_All];

            All_Deep_Per_Cell_Early_Task_Coherent=[All_Deep_Per_Cell_Early_Task_Coherent;Deep_Per_Cell_Early_Task_Coherent];
            All_Super_Per_Cell_Early_Task_Coherent=[All_Super_Per_Cell_Early_Task_Coherent;Super_Per_Cell_Early_Task_Coherent];
            All_Large_Deep_Per_Cell_Early_Task_Coherent=[All_Large_Deep_Per_Cell_Early_Task_Coherent;Large_Deep_Per_Cell_Early_Task_Coherent];
            All_Large_Super_Per_Cell_Early_Task_Coherent=[All_Large_Super_Per_Cell_Early_Task_Coherent;Large_Super_Per_Cell_Early_Task_Coherent];

            All_Deep_Per_Cell_Early_Task_Fragmented=[All_Deep_Per_Cell_Early_Task_Fragmented;Deep_Per_Cell_Early_Task_Fragmented];
            All_Super_Per_Cell_Early_Task_Fragmented=[All_Super_Per_Cell_Early_Task_Fragmented;Super_Per_Cell_Early_Task_Fragmented];
            All_Large_Deep_Per_Cell_Early_Task_Fragmented=[All_Large_Deep_Per_Cell_Early_Task_Fragmented;Large_Deep_Per_Cell_Early_Task_Fragmented];
            All_Large_Super_Per_Cell_Early_Task_Fragmented=[All_Large_Super_Per_Cell_Early_Task_Fragmented;Large_Super_Per_Cell_Early_Task_Fragmented];

            All_Deep_Per_Cell_Late_Task_All=[All_Deep_Per_Cell_Late_Task_All;Deep_Per_Cell_Late_Task_All];
            All_Super_Per_Cell_Late_Task_All=[All_Super_Per_Cell_Late_Task_All;Super_Per_Cell_Late_Task_All];
            All_Large_Deep_Per_Cell_Late_Task_All=[All_Large_Deep_Per_Cell_Late_Task_All;Large_Deep_Per_Cell_Late_Task_All];
            All_Large_Super_Per_Cell_Late_Task_All=[All_Large_Super_Per_Cell_Late_Task_All;Large_Super_Per_Cell_Late_Task_All];

            All_Deep_Per_Cell_Late_Task_Coherent=[All_Deep_Per_Cell_Late_Task_Coherent;Deep_Per_Cell_Late_Task_Coherent];
            All_Super_Per_Cell_Late_Task_Coherent=[All_Super_Per_Cell_Late_Task_Coherent;Super_Per_Cell_Late_Task_Coherent];
            All_Large_Deep_Per_Cell_Late_Task_Coherent=[All_Large_Deep_Per_Cell_Late_Task_Coherent;Large_Deep_Per_Cell_Late_Task_Coherent];
            All_Large_Super_Per_Cell_Late_Task_Coherent=[All_Large_Super_Per_Cell_Late_Task_Coherent;Large_Super_Per_Cell_Late_Task_Coherent];

            All_Deep_Per_Cell_Late_Task_Fragmented=[All_Deep_Per_Cell_Late_Task_Fragmented;Deep_Per_Cell_Late_Task_Fragmented];
            All_Super_Per_Cell_Late_Task_Fragmented=[All_Super_Per_Cell_Late_Task_Fragmented;Super_Per_Cell_Late_Task_Fragmented];
            All_Large_Deep_Per_Cell_Late_Task_Fragmented=[All_Large_Deep_Per_Cell_Late_Task_Fragmented;Large_Deep_Per_Cell_Late_Task_Fragmented];
            All_Large_Super_Per_Cell_Late_Task_Fragmented=[All_Large_Super_Per_Cell_Late_Task_Fragmented;Large_Super_Per_Cell_Late_Task_Fragmented];

            All_Deep_Per_Cell_Post_All=[All_Deep_Per_Cell_Post_All;Deep_Per_Cell_Post_All];
            All_Super_Per_Cell_Post_All=[All_Super_Per_Cell_Post_All;Super_Per_Cell_Post_All];
            All_Large_Deep_Per_Cell_Post_All=[All_Large_Deep_Per_Cell_Post_All;Large_Deep_Per_Cell_Post_All];
            All_Large_Super_Per_Cell_Post_All=[All_Large_Super_Per_Cell_Post_All;Large_Super_Per_Cell_Post_All];

            All_Deep_Per_Cell_Post_Coherent=[All_Deep_Per_Cell_Post_Coherent;Deep_Per_Cell_Post_Coherent];
            All_Super_Per_Cell_Post_Coherent=[All_Super_Per_Cell_Post_Coherent;Super_Per_Cell_Post_Coherent];
            All_Large_Deep_Per_Cell_Post_Coherent=[All_Large_Deep_Per_Cell_Post_Coherent;Large_Deep_Per_Cell_Post_Coherent];
            All_Large_Super_Per_Cell_Post_Coherent=[All_Large_Super_Per_Cell_Post_Coherent;Large_Super_Per_Cell_Post_Coherent];

            All_Deep_Per_Cell_Post_Incoherent=[All_Deep_Per_Cell_Post_Incoherent;Deep_Per_Cell_Post_Incoherent];
            All_Super_Per_Cell_Post_Incoherent=[All_Super_Per_Cell_Post_Incoherent;Super_Per_Cell_Post_Incoherent];
            All_Large_Deep_Per_Cell_Post_Incoherent=[All_Large_Deep_Per_Cell_Post_Incoherent;Large_Deep_Per_Cell_Post_Incoherent];
            All_Large_Super_Per_Cell_Post_Incoherent=[All_Large_Super_Per_Cell_Post_Incoherent;Large_Super_Per_Cell_Post_Incoherent];

            All_Deep_Per_Cell_Post_Fragmented=[All_Deep_Per_Cell_Post_Fragmented;Deep_Per_Cell_Post_Fragmented];
            All_Super_Per_Cell_Post_Fragmented=[All_Super_Per_Cell_Post_Fragmented;Super_Per_Cell_Post_Fragmented];
            All_Large_Deep_Per_Cell_Post_Fragmented=[All_Large_Deep_Per_Cell_Post_Fragmented;Large_Deep_Per_Cell_Post_Fragmented];
            All_Large_Super_Per_Cell_Post_Fragmented=[All_Large_Super_Per_Cell_Post_Fragmented;Large_Super_Per_Cell_Post_Fragmented];

            Per_Session_Mean_All_Deep_Non_SWS=[Per_Session_Mean_All_Deep_Non_SWS;mean(Deep_Non_SWS,1,'omitnan')];
            Per_Session_Mean_All_Super_Non_SWS=[Per_Session_Mean_All_Super_Non_SWS;mean(Super_Non_SWS,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Non_SWS=[Per_Session_Mean_All_Large_Deep_Non_SWS;mean(Large_Deep_Non_SWS,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Non_SWS=[Per_Session_Mean_All_Large_Super_Non_SWS;mean(Large_Super_Non_SWS,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Pre_All=[Per_Session_Mean_All_Deep_Per_Cell_Pre_All;mean(Deep_Per_Cell_Pre_All,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Pre_All=[Per_Session_Mean_All_Super_Per_Cell_Pre_All;mean(Super_Per_Cell_Pre_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_All=[Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_All;mean(Large_Deep_Per_Cell_Pre_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_All=[Per_Session_Mean_All_Large_Super_Per_Cell_Pre_All;mean(Large_Super_Per_Cell_Pre_All,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent=[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent;mean(Deep_Per_Cell_Pre_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent=[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent;mean(Super_Per_Cell_Pre_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Coherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Coherent;mean(Large_Deep_Per_Cell_Pre_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Coherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Coherent;mean(Large_Super_Per_Cell_Pre_Coherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent=[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent;mean(Deep_Per_Cell_Pre_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent=[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent;mean(Super_Per_Cell_Pre_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Incoherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Incoherent;mean(Large_Deep_Per_Cell_Pre_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Incoherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Incoherent;mean(Large_Super_Per_Cell_Pre_Incoherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented=[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented;mean(Deep_Per_Cell_Pre_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented=[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented;mean(Super_Per_Cell_Pre_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Fragmented=[Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Fragmented;mean(Large_Deep_Per_Cell_Pre_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Fragmented=[Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Fragmented;mean(Large_Super_Per_Cell_Pre_Fragmented,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_All=[Per_Session_Mean_All_Deep_Per_Cell_Early_Task_All;mean(Deep_Per_Cell_Early_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_All=[Per_Session_Mean_All_Super_Per_Cell_Early_Task_All;mean(Super_Per_Cell_Early_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_All=[Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_All;mean(Large_Deep_Per_Cell_Early_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_All=[Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_All;mean(Large_Super_Per_Cell_Early_Task_All,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Coherent=[Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Coherent;mean(Deep_Per_Cell_Early_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_Coherent=[Per_Session_Mean_All_Super_Per_Cell_Early_Task_Coherent;mean(Super_Per_Cell_Early_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Coherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Coherent;mean(Large_Deep_Per_Cell_Early_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Coherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Coherent;mean(Large_Super_Per_Cell_Early_Task_Coherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Fragmented=[Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Fragmented;mean(Deep_Per_Cell_Early_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_Fragmented=[Per_Session_Mean_All_Super_Per_Cell_Early_Task_Fragmented;mean(Super_Per_Cell_Early_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Fragmented=[Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Fragmented;mean(Large_Deep_Per_Cell_Early_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Fragmented=[Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Fragmented;mean(Large_Super_Per_Cell_Early_Task_Fragmented,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_All=[Per_Session_Mean_All_Deep_Per_Cell_Late_Task_All;mean(Deep_Per_Cell_Late_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_All=[Per_Session_Mean_All_Super_Per_Cell_Late_Task_All;mean(Super_Per_Cell_Late_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_All=[Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_All;mean(Large_Deep_Per_Cell_Late_Task_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_All=[Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_All;mean(Large_Super_Per_Cell_Late_Task_All,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Coherent=[Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Coherent;mean(Deep_Per_Cell_Late_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_Coherent=[Per_Session_Mean_All_Super_Per_Cell_Late_Task_Coherent;mean(Super_Per_Cell_Late_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Coherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Coherent;mean(Large_Deep_Per_Cell_Late_Task_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Coherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Coherent;mean(Large_Super_Per_Cell_Late_Task_Coherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Fragmented=[Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Fragmented;mean(Deep_Per_Cell_Late_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_Fragmented=[Per_Session_Mean_All_Super_Per_Cell_Late_Task_Fragmented;mean(Super_Per_Cell_Late_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Fragmented=[Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Fragmented;mean(Large_Deep_Per_Cell_Late_Task_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Fragmented=[Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Fragmented;mean(Large_Super_Per_Cell_Late_Task_Fragmented,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Post_All=[Per_Session_Mean_All_Deep_Per_Cell_Post_All;mean(Deep_Per_Cell_Post_All,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Post_All=[Per_Session_Mean_All_Super_Per_Cell_Post_All;mean(Super_Per_Cell_Post_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_All=[Per_Session_Mean_All_Large_Deep_Per_Cell_Post_All;mean(Large_Deep_Per_Cell_Post_All,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_All=[Per_Session_Mean_All_Large_Super_Per_Cell_Post_All;mean(Large_Super_Per_Cell_Post_All,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent=[Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent;mean(Deep_Per_Cell_Post_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Post_Coherent=[Per_Session_Mean_All_Super_Per_Cell_Post_Coherent;mean(Super_Per_Cell_Post_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Coherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Coherent;mean(Large_Deep_Per_Cell_Post_Coherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Coherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Post_Coherent;mean(Large_Super_Per_Cell_Post_Coherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent=[Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent;mean(Deep_Per_Cell_Post_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent=[Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent;mean(Super_Per_Cell_Post_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Incoherent=[Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Incoherent;mean(Large_Deep_Per_Cell_Post_Incoherent,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Incoherent=[Per_Session_Mean_All_Large_Super_Per_Cell_Post_Incoherent;mean(Large_Super_Per_Cell_Post_Incoherent,1,'omitnan')];

            Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented=[Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented;mean(Deep_Per_Cell_Post_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented=[Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented;mean(Super_Per_Cell_Post_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Fragmented=[Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Fragmented;mean(Large_Deep_Per_Cell_Post_Fragmented,1,'omitnan')];
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Fragmented=[Per_Session_Mean_All_Large_Super_Per_Cell_Post_Fragmented;mean(Large_Super_Per_Cell_Post_Fragmented,1,'omitnan')];

        else

            All_Deep_Non_SWS=Deep_Non_SWS;
            All_Super_Non_SWS=Super_Non_SWS;
            All_Large_Deep_Non_SWS=Large_Deep_Non_SWS;
            All_Large_Super_Non_SWS=Large_Super_Non_SWS;

            All_Deep_Per_Cell_Pre_All=Deep_Per_Cell_Pre_All;
            All_Super_Per_Cell_Pre_All=Super_Per_Cell_Pre_All;
            All_Large_Deep_Per_Cell_Pre_All=Large_Deep_Per_Cell_Pre_All;
            All_Large_Super_Per_Cell_Pre_All=Large_Super_Per_Cell_Pre_All;

            All_Deep_Per_Cell_Pre_Coherent=Deep_Per_Cell_Pre_Coherent;
            All_Super_Per_Cell_Pre_Coherent=Super_Per_Cell_Pre_Coherent;
            All_Large_Deep_Per_Cell_Pre_Coherent=Large_Deep_Per_Cell_Pre_Coherent;
            All_Large_Super_Per_Cell_Pre_Coherent=Large_Super_Per_Cell_Pre_Coherent;

            All_Deep_Per_Cell_Pre_Incoherent=Deep_Per_Cell_Pre_Incoherent;
            All_Super_Per_Cell_Pre_Incoherent=Super_Per_Cell_Pre_Incoherent;
            All_Large_Deep_Per_Cell_Pre_Incoherent=Large_Deep_Per_Cell_Pre_Incoherent;
            All_Large_Super_Per_Cell_Pre_Incoherent=Large_Super_Per_Cell_Pre_Incoherent;

            All_Deep_Per_Cell_Pre_Fragmented=Deep_Per_Cell_Pre_Fragmented;
            All_Super_Per_Cell_Pre_Fragmented=Super_Per_Cell_Pre_Fragmented;
            All_Large_Deep_Per_Cell_Pre_Fragmented=Large_Deep_Per_Cell_Pre_Fragmented;
            All_Large_Super_Per_Cell_Pre_Fragmented=Large_Super_Per_Cell_Pre_Fragmented;

            All_Deep_Per_Cell_Early_Task_All=Deep_Per_Cell_Early_Task_All;
            All_Super_Per_Cell_Early_Task_All=Super_Per_Cell_Early_Task_All;
            All_Large_Deep_Per_Cell_Early_Task_All=Large_Deep_Per_Cell_Early_Task_All;
            All_Large_Super_Per_Cell_Early_Task_All=Large_Super_Per_Cell_Early_Task_All;

            All_Deep_Per_Cell_Early_Task_Coherent=Deep_Per_Cell_Early_Task_Coherent;
            All_Super_Per_Cell_Early_Task_Coherent=Super_Per_Cell_Early_Task_Coherent;
            All_Large_Deep_Per_Cell_Early_Task_Coherent=Large_Deep_Per_Cell_Early_Task_Coherent;
            All_Large_Super_Per_Cell_Early_Task_Coherent=Large_Super_Per_Cell_Early_Task_Coherent;

            All_Deep_Per_Cell_Early_Task_Fragmented=Deep_Per_Cell_Early_Task_Fragmented;
            All_Super_Per_Cell_Early_Task_Fragmented=Super_Per_Cell_Early_Task_Fragmented;
            All_Large_Deep_Per_Cell_Early_Task_Fragmented=Large_Deep_Per_Cell_Early_Task_Fragmented;
            All_Large_Super_Per_Cell_Early_Task_Fragmented=Large_Super_Per_Cell_Early_Task_Fragmented;

            All_Deep_Per_Cell_Late_Task_All=Deep_Per_Cell_Late_Task_All;
            All_Super_Per_Cell_Late_Task_All=Super_Per_Cell_Late_Task_All;
            All_Large_Deep_Per_Cell_Late_Task_All=Large_Deep_Per_Cell_Late_Task_All;
            All_Large_Super_Per_Cell_Late_Task_All=Large_Super_Per_Cell_Late_Task_All;

            All_Deep_Per_Cell_Late_Task_Coherent=Deep_Per_Cell_Late_Task_Coherent;
            All_Super_Per_Cell_Late_Task_Coherent=Super_Per_Cell_Late_Task_Coherent;
            All_Large_Deep_Per_Cell_Late_Task_Coherent=Large_Deep_Per_Cell_Late_Task_Coherent;
            All_Large_Super_Per_Cell_Late_Task_Coherent=Large_Super_Per_Cell_Late_Task_Coherent;

            All_Deep_Per_Cell_Late_Task_Fragmented=Deep_Per_Cell_Late_Task_Fragmented;
            All_Super_Per_Cell_Late_Task_Fragmented=Super_Per_Cell_Late_Task_Fragmented;
            All_Large_Deep_Per_Cell_Late_Task_Fragmented=Large_Deep_Per_Cell_Late_Task_Fragmented;
            All_Large_Super_Per_Cell_Late_Task_Fragmented=Large_Super_Per_Cell_Late_Task_Fragmented;

            All_Deep_Per_Cell_Post_All=Deep_Per_Cell_Post_All;
            All_Super_Per_Cell_Post_All=Super_Per_Cell_Post_All;
            All_Large_Deep_Per_Cell_Post_All=Large_Deep_Per_Cell_Post_All;
            All_Large_Super_Per_Cell_Post_All=Large_Super_Per_Cell_Post_All;

            All_Deep_Per_Cell_Post_Coherent=Deep_Per_Cell_Post_Coherent;
            All_Super_Per_Cell_Post_Coherent=Super_Per_Cell_Post_Coherent;
            All_Large_Deep_Per_Cell_Post_Coherent=Large_Deep_Per_Cell_Post_Coherent;
            All_Large_Super_Per_Cell_Post_Coherent=Large_Super_Per_Cell_Post_Coherent;

            All_Deep_Per_Cell_Post_Incoherent=Deep_Per_Cell_Post_Incoherent;
            All_Super_Per_Cell_Post_Incoherent=Super_Per_Cell_Post_Incoherent;
            All_Large_Deep_Per_Cell_Post_Incoherent=Large_Deep_Per_Cell_Post_Incoherent;
            All_Large_Super_Per_Cell_Post_Incoherent=Large_Super_Per_Cell_Post_Incoherent;

            All_Deep_Per_Cell_Post_Fragmented=Deep_Per_Cell_Post_Fragmented;
            All_Super_Per_Cell_Post_Fragmented=Super_Per_Cell_Post_Fragmented;
            All_Large_Deep_Per_Cell_Post_Fragmented=Large_Deep_Per_Cell_Post_Fragmented;
            All_Large_Super_Per_Cell_Post_Fragmented=Large_Super_Per_Cell_Post_Fragmented;

            Per_Session_Mean_All_Deep_Non_SWS=mean(Deep_Non_SWS,1,'omitnan');
            Per_Session_Mean_All_Super_Non_SWS=mean(Super_Non_SWS,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Non_SWS=mean(Large_Deep_Non_SWS,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Non_SWS=mean(Large_Super_Non_SWS,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Pre_All=mean(Deep_Per_Cell_Pre_All,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Pre_All=mean(Super_Per_Cell_Pre_All,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_All=mean(Large_Deep_Per_Cell_Pre_All,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_All=mean(Large_Super_Per_Cell_Pre_All,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent=mean(Deep_Per_Cell_Pre_Coherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent=mean(Super_Per_Cell_Pre_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Coherent=mean(Large_Deep_Per_Cell_Pre_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Coherent=mean(Large_Super_Per_Cell_Pre_Coherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent=mean(Deep_Per_Cell_Pre_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent=mean(Super_Per_Cell_Pre_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Incoherent=mean(Large_Deep_Per_Cell_Pre_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Incoherent=mean(Large_Super_Per_Cell_Pre_Incoherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented=mean(Deep_Per_Cell_Pre_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented=mean(Super_Per_Cell_Pre_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Pre_Fragmented=mean(Large_Deep_Per_Cell_Pre_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Pre_Fragmented=mean(Large_Super_Per_Cell_Pre_Fragmented,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_All=mean(Deep_Per_Cell_Early_Task_All,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_All=mean(Super_Per_Cell_Early_Task_All,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_All=mean(Large_Deep_Per_Cell_Early_Task_All,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_All=mean(Large_Super_Per_Cell_Early_Task_All,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Coherent=mean(Deep_Per_Cell_Early_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_Coherent=mean(Super_Per_Cell_Early_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Coherent=mean(Large_Deep_Per_Cell_Early_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Coherent=mean(Large_Super_Per_Cell_Early_Task_Coherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Early_Task_Fragmented=mean(Deep_Per_Cell_Early_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Early_Task_Fragmented=mean(Super_Per_Cell_Early_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Early_Task_Fragmented=mean(Large_Deep_Per_Cell_Early_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Early_Task_Fragmented=mean(Large_Super_Per_Cell_Early_Task_Fragmented,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_All=mean(Deep_Per_Cell_Late_Task_All,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_All=mean(Super_Per_Cell_Late_Task_All,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_All=mean(Large_Deep_Per_Cell_Late_Task_All,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_All=mean(Large_Super_Per_Cell_Late_Task_All,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Coherent=mean(Deep_Per_Cell_Late_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_Coherent=mean(Super_Per_Cell_Late_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Coherent=mean(Large_Deep_Per_Cell_Late_Task_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Coherent=mean(Large_Super_Per_Cell_Late_Task_Coherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Late_Task_Fragmented=mean(Deep_Per_Cell_Late_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Late_Task_Fragmented=mean(Super_Per_Cell_Late_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Late_Task_Fragmented=mean(Large_Deep_Per_Cell_Late_Task_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Late_Task_Fragmented=mean(Large_Super_Per_Cell_Late_Task_Fragmented,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Post_All=mean(Deep_Per_Cell_Post_All,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Post_All=mean(Super_Per_Cell_Post_All,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_All=mean(Large_Deep_Per_Cell_Post_All,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_All=mean(Large_Super_Per_Cell_Post_All,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent=mean(Deep_Per_Cell_Post_Coherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Post_Coherent=mean(Super_Per_Cell_Post_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Coherent=mean(Large_Deep_Per_Cell_Post_Coherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Coherent=mean(Large_Super_Per_Cell_Post_Coherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent=mean(Deep_Per_Cell_Post_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent=mean(Super_Per_Cell_Post_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Incoherent=mean(Large_Deep_Per_Cell_Post_Incoherent,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Incoherent=mean(Large_Super_Per_Cell_Post_Incoherent,1,'omitnan');

            Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented=mean(Deep_Per_Cell_Post_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented=mean(Super_Per_Cell_Post_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Deep_Per_Cell_Post_Fragmented=mean(Large_Deep_Per_Cell_Post_Fragmented,1,'omitnan');
            Per_Session_Mean_All_Large_Super_Per_Cell_Post_Fragmented=mean(Large_Super_Per_Cell_Post_Fragmented,1,'omitnan');

        end
        
        cd ..

    end
    
    clear Directory
    cd ..

end

clearvars -except Initial_Variables *All_*

cd AllRatsCombined

save('All_Per_Ripple_And_Per_Place_Cell_Analysis','*All_*')

cd ..

end