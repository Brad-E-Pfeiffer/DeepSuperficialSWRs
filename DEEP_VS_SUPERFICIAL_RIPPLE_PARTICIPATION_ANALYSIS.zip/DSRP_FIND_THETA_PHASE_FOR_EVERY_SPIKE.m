function DSRP_FIND_THETA_PHASE_FOR_EVERY_SPIKE(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the slow gamma phase of each spike in the
% recording. This is very slow because the gamma phase is determined by the
% local gamma recorded on the same tetrode as the spike, which means the
% program has to load the process the gamma LFP signal for each tetrode.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
Duration_To_Remove=Initial_Variables.Duration_To_Remove_Around_Bad_LFP;
load('Spike_Data','Spike_Data','Tetrode_Cell_IDs');

% Spike_Data
% |   1  |     2   |                                3                            ||
% | Time | Cell ID | Slow Gamma Phase (Will be NaN if Within 0.1 s of LFP error? ||

if ~isfile('Spike_Data_With_Theta_Phase.mat')
    disp('Finding Local Theta Phase For Each Spike.')
    Spike_Data(:,3)=1000;
    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    for Current_Tetrode=min(Tetrode_Cell_IDs(:,1)):max(Tetrode_Cell_IDs(:,1))
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2); %Only processes tetrodes with recorded cells on them
        if ~isempty(Cells_On_This_Tetrode)
            for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
                Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
                if isfile(Electrode_Name)
                    LFP_Frequency=Nlx2MatCSC(Electrode_Name,[0 0 1 0 0],0,3,1);
                    LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                    for Header_Line=1:length(LFP_Header)
                        Header_Info=cell2mat(LFP_Header(Header_Line));
                        if length(Header_Info)>12
                            if strcmp(Header_Info(1:11),'-ADMaxValue')
                                Max_Value=str2double(Header_Info(13:end));
                            end
                            if strcmp(Header_Info(1:11),'-InputRange')
                                Max_Range=str2double(Header_Info(13:end));
                            end
                        end
                    end
                    LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                    Times=zeros(512,size(LFP_Times,2));
                    for B=1:length(LFP_Times)-1
                        Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                    end
                    Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                    clear B;
                    clear LFP_Times;
                    Times=Times(:);
                    LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                    LFP_Samples=LFP_Samples(:)*-(Max_Range/Max_Value); %Multiply by -1 to correct for the fact that the raw LFP was recorded inverted (see Header info)
                    LFP_Data=[Times,LFP_Samples];
                    clear Times;
                    clear LFP_Samples;
                    clear Max_Value;
                    Theta_Filtered_LFP_Data=zeros(size(LFP_Data,1),5);
                    Theta_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Theta_Filtered_LFP_Data(:,2)=bandpass(LFP_Data(:,2),[6 12],LFP_Frequency);
                    Theta_Filtered_LFP_Data(:,3)=hilbert(Theta_Filtered_LFP_Data(:,2));
                    Theta_Filtered_LFP_Data(:,4)=(angle(Theta_Filtered_LFP_Data(:,3))*180/pi);
                    Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,4)<=0,4)=Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,4)<=0,4)+360;
                    %This identifies parts of the LFP that are beyond the recording parameters and for which a phase cannot be properly quantified -- the phase of these times and all within Duration_To_Remove seconds will be NaN 
                    Index_To_Remove=find(LFP_Data(:,2)==Max_Range | LFP_Data(:,2)==(-1*Max_Range));
                    for N=1:100000:length(Index_To_Remove)
                        Index_To_Remove2=(ones(length(N:min([N+99999,length(Index_To_Remove)])),1).*((-round(LFP_Frequency*Duration_To_Remove)):round(LFP_Frequency*Duration_To_Remove)))+Index_To_Remove(N:min([N+99999,length(Index_To_Remove)]));
                        Index_To_Remove2=Index_To_Remove2(:);
                        Index_To_Remove2=Index_To_Remove2(Index_To_Remove2>0 & Index_To_Remove2<=size(Theta_Filtered_LFP_Data,1));
                        Theta_Filtered_LFP_Data(Index_To_Remove2,5)=1;
                    end
                    Theta_Filtered_LFP_Data(Theta_Filtered_LFP_Data(:,5)==1,4)=NaN;
                    clear N;
                    clear LFP_Data;
                    clear Max_Range;
                    clear Index_To_Remove;
                    clear Index_To_Remove2;
                    
                    %This finds the phase for each spike recorded on this tetrode
                    for Cell=1:length(Cells_On_This_Tetrode)
                        Current_Cell=Cells_On_This_Tetrode(Cell);
                        Spike_Index=find(Spike_Data(:,2)==Current_Cell & Spike_Data(:,1)>=min(Theta_Filtered_LFP_Data(:,1)) & Spike_Data(:,1)<=max(Theta_Filtered_LFP_Data(:,1)));
                        This_Cell_Spike_Data=Spike_Data(Spike_Index,:);
                        This_Cell_Spike_Data(:,3)=interp1(Theta_Filtered_LFP_Data(:,1),Theta_Filtered_LFP_Data(:,4),This_Cell_Spike_Data(:,1),'nearest');
                        This_Cell_Spike_Data(This_Cell_Spike_Data(:,1)<min(Theta_Filtered_LFP_Data(:,1)),3)=NaN;
                        This_Cell_Spike_Data(This_Cell_Spike_Data(:,1)>max(Theta_Filtered_LFP_Data(:,1)),3)=NaN;
                        Spike_Data(Spike_Index,:)=This_Cell_Spike_Data;
                    end
                    clear Cell;
                end
            end
        end
        disp(sprintf('Finished quantifying local slow gamma for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    Spike_Data(Spike_Data(:,3)==1000,3)=NaN; %This removes any spikes where a phase couldn't be found (typically because they were before/after the first/last LFP data point)
    cd(Current_Working_Directory);
    clear Raw_LFP_Directory;
    clear Current_Directory;
    save('Spike_Data_With_Theta_Phase','Spike_Data');
end

end

