function DSRP_CREATE_PER_SESSION_FIRING_RATE_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
% 
% Plot Per-Session Averages for All Cells
% 
%==========================================================================
%==========================================================================

%==========================================================================
%
% Plot Firing Rate (Only for Participating Cells)
%
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Place_Cell_Analysis

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
    mkdir('Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis')
end
cd 'Experience_Modulation_Of_SWR_Activity_New_Early_Late_Analysis'


if ~isfolder('Per_Session')
    mkdir('Per_Session')
end
cd Per_Session

%Plot Per Session Firing Rate Of Participating Cells
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_All(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Per_Session_Deep_Participating_Firing_Rate_P,Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_All(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_All(:,3))
[Per_Session_Superficial_Participating_Firing_Rate_P,Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_All(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_All(:,3))


% Plot for only coherent ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate_In_Coherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Coherent_Per_Session_Deep_Participating_Firing_Rate_P,Coherent_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Coherent(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Coherent(:,3))
[Coherent_Per_Session_Superficial_Participating_Firing_Rate_P,Coherent_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Coherent(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_Coherent(:,3))


% Plot for only incoherent ripples (all non-replay SWRs, not only "fragmented" SWRs)  
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate_In_Incoherent_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Incoherent_Per_Session_Deep_Participating_Firing_Rate_P,Incoherent_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Incoherent(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Incoherent(:,3))
[Incoherent_Per_Session_Superficial_Participating_Firing_Rate_P,Incoherent_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Incoherent(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_Incoherent(:,3))


% Plot for only fragmented ripples 
figure;
hold on;
for N=1:10
    plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(N,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(N,3)])
    plot([1,2],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(N,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(N,3)])
end
Y_Lim=ylim;
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(1,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,3)],'ok','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(1,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(1,3)],'k--');
%Rat1,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(2,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,3)],'ob','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(2,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(2,3)],'b--');
%Rat1,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(3,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,3)],'or','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(3,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(3,3)],'r--');
%Rat1,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(4,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,3)],'og','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(4,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(4,3)],'g--');
%Rat1,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(5,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,3)],'^k','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(5,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(5,3)],'k--');
%Rat2,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(6,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,3)],'^b','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(6,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(6,3)],'b--');
%Rat2,Day3
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(7,3)],'r--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,3)],'^r','MarkerFaceColor','r','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(7,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(7,3)],'r--');
%Rat2,Day4
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(8,3)],'g--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,3)],'^g','MarkerFaceColor','g','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(8,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(8,3)],'g--');
%Rat3,Day1
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(9,3)],'k--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,3)],'sk','MarkerFaceColor','k','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(9,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(9,3)],'k--');
%Rat3,Day2
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([1,2],[Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(10,3)],'b--');
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,3)],'sb','MarkerFaceColor','b','MarkerSize',10);
plot([4,5],[Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(10,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(10,3)],'b--');
%Mean
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([0.75,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))],'k','LineWidth',3);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))],'ok','MarkerFaceColor','k','MarkerSize',15);
plot([3.75,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([0.75,0.75],[mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))+(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([2.25,2.25],[mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))-(std(Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([3.75,3.75],[mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))+(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
plot([5.25,5.25],[mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3)),mean(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))-(std(Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))/sqrt(10))],'k','LineWidth',3);
set(gca,'YLim',[Y_Lim(1),Y_Lim(2)]);
set(gca,'XLim',[0 6.25]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Per_Session_Participating_Cell_Firing_Rate_In_Fragmented_Ripples(DeepPre,DeepPost,SuperPre,SuperPost,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Fragmented_Per_Session_Deep_Participating_Firing_Rate_P,Fragmented_Per_Session_Deep_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Deep_Per_Cell_Pre_Fragmented(:,3),Per_Session_Mean_All_Deep_Per_Cell_Post_Fragmented(:,3))
[Fragmented_Per_Session_Superficial_Participating_Firing_Rate_P,Fragmented_Per_Session_Superficial_Participating_Firing_Rate_H]=signrank(Per_Session_Mean_All_Super_Per_Cell_Pre_Fragmented(:,3),Per_Session_Mean_All_Super_Per_Cell_Post_Fragmented(:,3))

cd ..
cd ..
cd ..


end

