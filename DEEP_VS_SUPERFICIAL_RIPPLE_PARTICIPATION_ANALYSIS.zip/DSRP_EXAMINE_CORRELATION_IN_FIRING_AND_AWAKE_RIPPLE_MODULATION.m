function DSRP_EXAMINE_CORRELATION_IN_FIRING_AND_AWAKE_RIPPLE_MODULATION(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the effect of on-task firing with pre- to
% post-task SWR firing
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Firing_Properties_Per_Cell_During_Behavior
% |    1    |              2                  |                    3                     |              4             |              5            |         6        |                 7                 |                   8                 |              9            |             10            |                 11                 |                  12                  |              13            |           14         ||
% | Cell ID | Peak Firing Rate of Place Field | Mean non-SWR Firing Rate During Behavior | Number Of Spikes In Bursts | Spikes Per On-Task Bursts | Burstiness Index | Pre-Task Rest Non-SWR Firing Rate | Number of Spikes in Pre-Task Bursts | Spikes Per Pre-Task Burst | Pre-Task Burstiness Index | Post-Task Rest Non-SWR Firing Rate | Number of Spikes in Post-Task Bursts | Spikes Per Post-Task Burst | Post-Task Burstiness ||

% Per_Cell_Firing_Across_Ripples
% |    1    |                      2                     |                    3                |                    4                  |               5              |                  6               |                7              |                   8                  |                     9                   |                   10                  ||
% | Cell ID | Mean Firing Rate in Pre-Experience Ripples | Mean Firing Rate In On-Task Ripples | Mean Firing Rate In Post-Task Ripples | Participation In Pre Ripples | Participation in On-Task Ripples | Participation in Post Ripples | Mean Participating FR in Pre Ripples | Mean Participating FR in OnTask Ripples | Mean Participating FR in Post Ripples ||

% Per_Non_Place_Cell_Firing_Across_Ripples (page 1 is all ripples, page 2 is only coherent ripples, page 3 is only fragmented ripples 
% |    1    |                      2                     |                    3                |                    4                  |               5              |                  6               |                7              |                   8                  |                     9                   |                   10                  ||
% | Cell ID | Mean Firing Rate in Pre-Experience Ripples | Mean Firing Rate In On-Task Ripples | Mean Firing Rate In Post-Task Ripples | Participation In Pre Ripples | Participation in On-Task Ripples | Participation in Post Ripples | Mean Participating FR in Pre Ripples | Mean Participating FR in OnTask Ripples | Mean Participating FR in Post Ripples ||

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Effect of On-Task Firing on Pre- to Post-Task SWR Firing for %s Day %d.'')',Rat_Name,Experiment)); 

        load Deep_And_Superficial_Cell_Identities.mat;
        load Firing_Properties_Per_Cell_During_Behavior.mat;
        Non_Place_Firing_Properties_Per_Cell_During_Behavior=Firing_Properties_Per_Cell_During_Behavior(1,:);
        load Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples.mat;
        load Per_Cell_Firing_Across_Awake_Only_Ripples.mat;
        load('Spike_Data','Inhibitory_Neurons');
        load Field_Data;
        for N=1:max(Firing_Properties_Per_Cell_During_Behavior(:,1))
            if max(max(Field_Data(:,:,N)))==0 && sum(Inhibitory_Neurons==N)==0
                Non_Place_Firing_Properties_Per_Cell_During_Behavior=[Non_Place_Firing_Properties_Per_Cell_During_Behavior;Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)==N,:)];
            end
            if max(max(Field_Data(:,:,N)))==0 || max(max(Field_Data(:,:,N)))>80 || sum(Inhibitory_Neurons==N)>0
                Firing_Properties_Per_Cell_During_Behavior=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)~=N,:);
            end
        end
        Non_Place_Firing_Properties_Per_Cell_During_Behavior=Non_Place_Firing_Properties_Per_Cell_During_Behavior(2:end,:);
        Firing_Properties_Per_Cell_During_Behavior(:,15:16)=0;
        Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,15:16)=0;
        for N=1:size(Deep_Cells,1)
            Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)==Deep_Cells(N),15)=2;
            Non_Place_Firing_Properties_Per_Cell_During_Behavior(Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,1)==Deep_Cells(N),15)=2;
        end
        for N=1:size(Superficial_Cells,1)
            Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)==Superficial_Cells(N),15)=1;
            Non_Place_Firing_Properties_Per_Cell_During_Behavior(Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,1)==Superficial_Cells(N),15)=1;
        end
        for N=1:size(Large_Deep_Cells,1)
            Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)==Large_Deep_Cells(N),16)=2;
            Non_Place_Firing_Properties_Per_Cell_During_Behavior(Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,1)==Large_Deep_Cells(N),16)=2;
        end
        for N=1:size(Large_Superficial_Cells,1)
            Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)==Large_Superficial_Cells(N),16)=1;
            Non_Place_Firing_Properties_Per_Cell_During_Behavior(Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,1)==Large_Superficial_Cells(N),16)=1;
        end
        
        % Combined
        % |    1    |           2       |           3        |      4     |       5     |         6      |           7         |          8         |        9        |      10     |         11        |     12      |     13     |           14          |           15         |        16        ||
        % | Cell ID | Pre Participation | Post Participation | Pre SWR FR | Post SWR FR | OnTask Mean FR | Pre Mean Non-SWR FR | OnTask Burst Index | Pre Burst Index | Deep/Super? | Large Deep/Super? | Non SWR FRI | SWR FR EMI | SWR Participation EMI | Post Mean Non-SWR FR | Post Burst Index ||
        Combined=[Per_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],1),Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Cell_Firing_Across_Awake_Only_Ripples,1),3),Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined_Coherent=[Per_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],2),Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Cell_Firing_Across_Awake_Only_Ripples,1),3),Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined_Fragmented=[Per_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],3),Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Cell_Firing_Across_Awake_Only_Ripples,1),3),Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined_NonPlace=[Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],1),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples,1),3),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined_NonPlace_Coherent=[Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],2),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples,1),3),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined_NonPlace_Fragmented=[Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples(:,[1,5,7,8,10],3),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[3,7,6,10,15,16]),zeros(size(Per_Non_Place_Cell_Firing_Across_Awake_Only_Ripples,1),3),Non_Place_Firing_Properties_Per_Cell_During_Behavior(:,[11,14])];
        Combined(:,12)=(Combined(:,6)-Combined(:,7))./(Combined(:,6)+Combined(:,7));
        Combined(:,13)=(Combined(:,5)-Combined(:,4))./(Combined(:,5)+Combined(:,4));
        Combined(:,14)=(Combined(:,3)-Combined(:,2))./(Combined(:,3)+Combined(:,2));
        Combined_Coherent(:,12)=(Combined_Coherent(:,6)-Combined_Coherent(:,7))./(Combined_Coherent(:,6)+Combined_Coherent(:,7));
        Combined_Coherent(:,13)=(Combined_Coherent(:,5)-Combined_Coherent(:,4))./(Combined_Coherent(:,5)+Combined_Coherent(:,4));
        Combined_Coherent(:,14)=(Combined_Coherent(:,3)-Combined_Coherent(:,2))./(Combined_Coherent(:,3)+Combined_Coherent(:,2));
        Combined_Fragmented(:,12)=(Combined_Fragmented(:,6)-Combined_Fragmented(:,7))./(Combined_Fragmented(:,6)+Combined_Fragmented(:,7));
        Combined_Fragmented(:,13)=(Combined_Fragmented(:,5)-Combined_Fragmented(:,4))./(Combined_Fragmented(:,5)+Combined_Fragmented(:,4));
        Combined_Fragmented(:,14)=(Combined_Fragmented(:,3)-Combined_Fragmented(:,2))./(Combined_Fragmented(:,3)+Combined_Fragmented(:,2));
        Combined_NonPlace(:,12)=(Combined_NonPlace(:,6)-Combined_NonPlace(:,7))./(Combined_NonPlace(:,6)+Combined_NonPlace(:,7));
        Combined_NonPlace(:,13)=(Combined_NonPlace(:,5)-Combined_NonPlace(:,4))./(Combined_NonPlace(:,5)+Combined_NonPlace(:,4));
        Combined_NonPlace(:,14)=(Combined_NonPlace(:,3)-Combined_NonPlace(:,2))./(Combined_NonPlace(:,3)+Combined_NonPlace(:,2));
        Combined_NonPlace_Coherent(:,12)=(Combined_NonPlace_Coherent(:,6)-Combined_NonPlace_Coherent(:,7))./(Combined_NonPlace_Coherent(:,6)+Combined_NonPlace_Coherent(:,7));
        Combined_NonPlace_Coherent(:,13)=(Combined_NonPlace_Coherent(:,5)-Combined_NonPlace_Coherent(:,4))./(Combined_NonPlace_Coherent(:,5)+Combined_NonPlace_Coherent(:,4));
        Combined_NonPlace_Coherent(:,14)=(Combined_NonPlace_Coherent(:,3)-Combined_NonPlace_Coherent(:,2))./(Combined_NonPlace_Coherent(:,3)+Combined_NonPlace_Coherent(:,2));
        Combined_NonPlace_Fragmented(:,12)=(Combined_NonPlace_Fragmented(:,6)-Combined_NonPlace_Fragmented(:,7))./(Combined_NonPlace_Fragmented(:,6)+Combined_NonPlace_Fragmented(:,7));
        Combined_NonPlace_Fragmented(:,13)=(Combined_NonPlace_Fragmented(:,5)-Combined_NonPlace_Fragmented(:,4))./(Combined_NonPlace_Fragmented(:,5)+Combined_NonPlace_Fragmented(:,4));
        Combined_NonPlace_Fragmented(:,14)=(Combined_NonPlace_Fragmented(:,3)-Combined_NonPlace_Fragmented(:,2))./(Combined_NonPlace_Fragmented(:,3)+Combined_NonPlace_Fragmented(:,2));

        if exist('All_Combined','var')
            All_Combined=[All_Combined;Combined];
            All_Combined_Coherent=[All_Combined_Coherent;Combined_Coherent];
            All_Combined_Fragmented=[All_Combined_Fragmented;Combined_Fragmented];
            All_Combined_NonPlace=[All_Combined_NonPlace;Combined_NonPlace];
            All_Combined_NonPlace_Coherent=[All_Combined_NonPlace_Coherent;Combined_NonPlace_Coherent];
            All_Combined_NonPlace_Fragmented=[All_Combined_NonPlace_Fragmented;Combined_NonPlace_Fragmented];
        else
            All_Combined=Combined;
            All_Combined_Coherent=Combined_Coherent;
            All_Combined_Fragmented=Combined_Fragmented;
            All_Combined_NonPlace=Combined_NonPlace;
            All_Combined_NonPlace_Coherent=Combined_NonPlace_Coherent;
            All_Combined_NonPlace_Fragmented=Combined_NonPlace_Fragmented;
        end

% 
%         Per_Cell_Firing_Across_Ripples(ismember(Per_Cell_Firing_Across_Ripples(:,1,1),Deep_Cells),11,:)=2;
%         Per_Cell_Firing_Across_Ripples(ismember(Per_Cell_Firing_Across_Ripples(:,1,1),Superficial_Cells),11,:)=1;
%         Per_Cell_Firing_Across_Ripples(ismember(Per_Cell_Firing_Across_Ripples(:,1,1),Large_Deep_Cells),12,:)=2;
%         Per_Cell_Firing_Across_Ripples(ismember(Per_Cell_Firing_Across_Ripples(:,1,1),Large_Superficial_Cells),12,:)=1;
% 
%         Per_Cell_Firing_Across_Ripples(:,13,:)=Per_Cell_Firing_Across_Ripples(:,7,:)./Per_Cell_Firing_Across_Ripples(:,5,:); %Percent increase in cell participation
%         Per_Cell_Firing_Across_Ripples(:,14,:)=Per_Cell_Firing_Across_Ripples(:,10,:)./Per_Cell_Firing_Across_Ripples(:,8,:); %Percent increase in participating firing rate
%         Firing_Properties_Per_Cell_During_Behavior(:,13)=(Firing_Properties_Per_Cell_During_Behavior(:,3)-Firing_Properties_Per_Cell_During_Behavior(:,7))./(Firing_Properties_Per_Cell_During_Behavior(:,3)+Firing_Properties_Per_Cell_During_Behavior(:,7)); %On-task firing rate index (on-pre)/(on+pre)
%         %Firing_Properties_Per_Cell_During_Behavior(:,13)=Firing_Properties_Per_Cell_During_Behavior(:,10)./Firing_Properties_Per_Cell_During_Behavior(:,6); 
% 
%         % Deep/Superficial/Large_Deep/Large_Superficial
%         %|                  1                |                  2              |                   3                |         4       |             5            |               6              |             7             |         8        ||
%         %| Percent Increase In Participation | Percent Increase In Firing Rate | On-Task Firing Rate Index (On/Pre) | Peak Field Rate | Mean Firing Rate On-Task | Total Number of Burst Spikes | Spikes Per On-Task Bursts | Burstiness Index ||
%         Deep=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==2,13:14,1),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==2,[13,2:6])];
%         Superficial=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==1,13:14,1),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==1,[13,2:6])];
%         Large_Deep=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==2,13:14,1),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==2,[13,2:6])];
%         Large_Superficial=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==1,13:14,1),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==1,[13,2:6])];
% 
%         Deep_Coherent=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==2,13:14,2),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==2,[13,2:6])];
%         Superficial_Coherent=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==1,13:14,2),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==1,[13,2:6])];
%         Large_Deep_Coherent=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==2,13:14,2),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==2,[13,2:6])];
%         Large_Superficial_Coherent=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==1,13:14,2),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==1,[13,2:6])];
% 
%         Deep_Fragmented=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==2,13:14,3),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==2,[13,2:6])];
%         Superficial_Fragmented=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,11)==1,13:14,3),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,11)==1,[13,2:6])];
%         Large_Deep_Fragmented=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==2,13:14,3),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==2,[13,2:6])];
%         Large_Superficial_Fragmented=[Per_Cell_Firing_Across_Ripples(Per_Cell_Firing_Across_Ripples(:,12)==1,13:14,3),Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,12)==1,[13,2:6])];
% 
%         if exist('All_Deep','var')
%             All_Deep=[All_Deep;Deep];
%             All_Superficial=[All_Superficial;Superficial];
%             All_Large_Deep=[All_Large_Deep;Large_Deep];
%             All_Large_Superficial=[All_Large_Superficial;Large_Superficial];
%             All_Deep_Coherent=[All_Deep_Coherent;Deep_Coherent];
%             All_Superficial_Coherent=[All_Superficial_Coherent;Superficial_Coherent];
%             All_Large_Deep_Coherent=[All_Large_Deep_Coherent;Large_Deep_Coherent];
%             All_Large_Superficial_Coherent=[All_Large_Superficial_Coherent;Large_Superficial_Coherent];
%             All_Deep_Fragmented=[All_Deep_Fragmented;Deep_Fragmented];
%             All_Superficial_Fragmented=[All_Superficial_Fragmented;Superficial_Fragmented];
%             All_Large_Deep_Fragmented=[All_Large_Deep_Fragmented;Large_Deep_Fragmented];
%             All_Large_Superficial_Fragmented=[All_Large_Superficial_Fragmented;Large_Superficial_Fragmented];
%         else
%             All_Deep=Deep;
%             All_Superficial=Superficial;
%             All_Large_Deep=Large_Deep;
%             All_Large_Superficial=Large_Superficial;
%             All_Deep_Coherent=Deep_Coherent;
%             All_Superficial_Coherent=Superficial_Coherent;
%             All_Large_Deep_Coherent=Large_Deep_Coherent;
%             All_Large_Superficial_Coherent=Large_Superficial_Coherent;
%             All_Deep_Fragmented=Deep_Fragmented;
%             All_Superficial_Fragmented=Superficial_Fragmented;
%             All_Large_Deep_Fragmented=Large_Deep_Fragmented;
%             All_Large_Superficial_Fragmented=Large_Superficial_Fragmented;
%         end
        cd ..

    end
    
    clear Directory
    cd ..

end

Deep=All_Combined(All_Combined(:,10)==2,:);
Super=All_Combined(All_Combined(:,10)==1,:);
Large_Deep=All_Combined(All_Combined(:,11)==2,:);
Large_Super=All_Combined(All_Combined(:,11)==1,:);
Coherent_Deep=All_Combined_Coherent(All_Combined_Coherent(:,10)==2,:);
Coherent_Super=All_Combined_Coherent(All_Combined_Coherent(:,10)==1,:);
Coherent_Large_Deep=All_Combined_Coherent(All_Combined_Coherent(:,11)==2,:);
Coherent_Large_Super=All_Combined_Coherent(All_Combined_Coherent(:,11)==1,:);
Fragmented_Deep=All_Combined_Fragmented(All_Combined_Fragmented(:,10)==2,:);
Fragmented_Super=All_Combined_Fragmented(All_Combined_Fragmented(:,10)==1,:);
Fragmented_Large_Deep=All_Combined_Fragmented(All_Combined_Fragmented(:,11)==2,:);
Fragmented_Large_Super=All_Combined_Fragmented(All_Combined_Fragmented(:,11)==1,:);

Deep_NonPlace=All_Combined_NonPlace(All_Combined_NonPlace(:,10)==2,:);
Super_NonPlace=All_Combined_NonPlace(All_Combined_NonPlace(:,10)==1,:);
Large_NonPlace_Deep=All_Combined_NonPlace(All_Combined_NonPlace(:,11)==2,:);
Large_NonPlace_Super=All_Combined_NonPlace(All_Combined_NonPlace(:,11)==1,:);
Coherent_NonPlace_Deep=All_Combined_NonPlace_Coherent(All_Combined_NonPlace_Coherent(:,10)==2,:);
Coherent_NonPlace_Super=All_Combined_NonPlace_Coherent(All_Combined_NonPlace_Coherent(:,10)==1,:);
Coherent_NonPlace_Large_Deep=All_Combined_NonPlace_Coherent(All_Combined_NonPlace_Coherent(:,11)==2,:);
Coherent_NonPlace_Large_Super=All_Combined_NonPlace_Coherent(All_Combined_NonPlace_Coherent(:,11)==1,:);
Fragmented_NonPlace_Deep=All_Combined_NonPlace_Fragmented(All_Combined_NonPlace_Fragmented(:,10)==2,:);
Fragmented_NonPlace_Super=All_Combined_NonPlace_Fragmented(All_Combined_NonPlace_Fragmented(:,10)==1,:);
Fragmented_NonPlace_Large_Deep=All_Combined_NonPlace_Fragmented(All_Combined_NonPlace_Fragmented(:,11)==2,:);
Fragmented_NonPlace_Large_Super=All_Combined_NonPlace_Fragmented(All_Combined_NonPlace_Fragmented(:,11)==1,:);

cd _Figures
cd Awake_Only

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Coherent_Deep(:,12),Coherent_Deep(:,13),'.r');
plot(Coherent_Super(:,12),Coherent_Super(:,13),'.k');

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Fragmented_Deep(:,12),Fragmented_Deep(:,13),'.r');
plot(Fragmented_Super(:,12),Fragmented_Super(:,13),'.k');

Start=-0.9;
Step=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([-1 1],[0 0],'k--');
for N=Start:Step:1
    D=Fragmented_Large_Deep(Fragmented_Large_Deep(:,12)>(N-Step/2) & Fragmented_Large_Deep(:,12)<=(N+Step/2),14);
    S=Fragmented_Large_Super(Fragmented_Large_Super(:,12)>(N-Step/2) & Fragmented_Large_Super(:,12)<=(N+Step/2),14);
    plot(N+0.05,mean(D,'omitnan'),'or','MarkerFaceColor','r');
    plot([N+0.05,N+0.05],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'r');
    plot(N-0.05,mean(S,'omitnan'),'sk','MarkerFaceColor','k');
    plot([N-0.05,N-0.05],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'k');
end

Start=-0.9;
Step=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([-1 1],[0 0],'k--');
for N=Start:Step:1
    D=Fragmented_Large_Deep(Fragmented_Large_Deep(:,12)>(N-Step/2) & Fragmented_Large_Deep(:,12)<=(N+Step/2),13);
    S=Fragmented_Large_Super(Fragmented_Large_Super(:,12)>(N-Step/2) & Fragmented_Large_Super(:,12)<=(N+Step/2),13);
    plot(N+0.05,mean(D,'omitnan'),'or','MarkerFaceColor','r');
    plot([N+0.05,N+0.05],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'r');
    plot(N-0.05,mean(S,'omitnan'),'sk','MarkerFaceColor','k');
    plot([N-0.05,N-0.05],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'k');
end

Start=-0.9;
Step=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([-1 1],[0 0],'k--');
for N=Start:Step:1
    D=Coherent_Large_Deep(Coherent_Large_Deep(:,12)>(N-Step/2) & Coherent_Large_Deep(:,12)<=(N+Step/2),14);
    S=Coherent_Large_Super(Coherent_Large_Super(:,12)>(N-Step/2) & Coherent_Large_Super(:,12)<=(N+Step/2),14);
    plot(N+0.05,mean(D,'omitnan'),'or','MarkerFaceColor','r');
    plot([N+0.05,N+0.05],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'r');
    plot(N-0.05,mean(S,'omitnan'),'sk','MarkerFaceColor','k');
    plot([N-0.05,N-0.05],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'k');
end

Start=-0.9;
Step=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot([-1 1],[0 0],'k--');
for N=Start:Step:1
    D=Coherent_Large_Deep(Coherent_Large_Deep(:,12)>(N-Step/2) & Coherent_Large_Deep(:,12)<=(N+Step/2),13);
    S=Coherent_Large_Super(Coherent_Large_Super(:,12)>(N-Step/2) & Coherent_Large_Super(:,12)<=(N+Step/2),13);
    plot(N+0.05,mean(D,'omitnan'),'or','MarkerFaceColor','r');
    plot([N+0.05,N+0.05],[mean(D,'omitnan')+(std(D,'omitnan')/sqrt(sum(~isnan(D)))),mean(D,'omitnan')-(std(D,'omitnan')/sqrt(sum(~isnan(D))))],'r');
    plot(N-0.05,mean(S,'omitnan'),'sk','MarkerFaceColor','k');
    plot([N-0.05,N-0.05],[mean(S,'omitnan')+(std(S,'omitnan')/sqrt(sum(~isnan(S)))),mean(S,'omitnan')-(std(S,'omitnan')/sqrt(sum(~isnan(S))))],'k');
end














figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Deep_Coherent(:,3),All_Deep_Coherent(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Superficial_Coherent(:,3),All_Superficial_Coherent(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([-1 1],[1 1],'k--');

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Large_Deep_Coherent(:,3),All_Large_Deep_Coherent(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Large_Superficial_Coherent(:,3),All_Large_Superficial_Coherent(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([-1 1],[1 1],'k--');

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Deep_Fragmented(:,3),All_Deep_Fragmented(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Superficial_Fragmented(:,3),All_Superficial_Fragmented(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([-1 1],[1 1],'k--');

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Large_Deep_Coherent(:,3),All_Large_Deep_Coherent(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Large_Superficial_Coherent(:,3),All_Large_Superficial_Coherent(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([-1 1],[1 1],'k--');





%Burstiness is correlated to increased post SWR FR
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Deep(:,8),All_Deep(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Superficial(:,8),All_Superficial(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([0 1],[1 1],'k--');

%Burstiness is correlated to increased post SWR FR
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(All_Large_Deep(:,8),All_Large_Deep(:,2),'or','MarkerFaceColor','r','MarkerSize',5)
plot(All_Large_Superficial(:,8),All_Large_Superficial(:,2),'ok','MarkerFaceColor','k','MarkerSize',5)
plot([0 1],[1 1],'k--');



%Superficial are more bursty, but this shows that even when you control for burstiness, superficial cells still show an increase in postSWR FR compared to deep cells 
X=0.33;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
G=zeros(1,6);
Index=0;
for N=0:X:(1-X)
    Index=Index+1;
    G(Index,1)=mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan');
    G(Index,2)=std(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan');
    G(Index,3)=sum(~isnan(All_Deep(:,8)) & All_Deep(:,8)>=N & All_Deep(:,8)<(N+X));
    plot(N+(X/2)+(X/10),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan'),'sr','MarkerSize',10,'MarkerFaceColor','r');
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan')+std(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,8)) & All_Deep(:,8)>=N & All_Deep(:,8)<(N+X)))],'r','LineWidth',3);
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan')-std(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,8)) & All_Deep(:,8)>=N & All_Deep(:,8)<(N+X)))],'r','LineWidth',3);
    G(Index,4)=mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan');
    G(Index,5)=std(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan');
    G(Index,6)=sum(~isnan(All_Superficial(:,8)) & All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X));
    plot(N+(X/2),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan'),'sk','MarkerSize',10,'MarkerFaceColor','k');
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan')+std(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,8)) & All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X)))],'k','LineWidth',3);
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan')-std(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,8)) & All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X)))],'k','LineWidth',3);
end
plot([0 1],[1 1],'k--');

%Superficial are more bursty, but this shows that even when you control for burstiness, superficial and cells still show a similar increase in postSWR participation (no it doesn't because there is no statistical difference) 
X=0.33;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=0:X:(1-X)
    plot(N+(X/2)+(X/10),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan'),'sr','MarkerSize',10,'MarkerFaceColor','r');
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan'),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan')+std(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan')/sqrt(sum(~isnan(All_Deep(:,8)) & All_Deep(:,8)>=N & All_Deep(:,8)<(N+X)))],'r','LineWidth',3);
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan'),mean(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan')-std(All_Deep(All_Deep(:,8)>=N & All_Deep(:,8)<(N+X),1),'omitnan')/sqrt(sum(~isnan(All_Deep(:,8)) & All_Deep(:,8)>=N & All_Deep(:,8)<(N+X)))],'r','LineWidth',3);
    plot(N+(X/2),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan'),'sk','MarkerSize',10,'MarkerFaceColor','k');
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan'),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan')+std(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,8)) & All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X)))],'k','LineWidth',3);
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan'),mean(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan')-std(All_Superficial(All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X),1),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,8)) & All_Superficial(:,8)>=N & All_Superficial(:,8)<(N+X)))],'k','LineWidth',3);
end
plot([0 1],[1 1],'k--');


X=0.2;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=-1:X:(1-X)
    plot(N+(X/2)+(X/10),mean(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan'),'sr','MarkerSize',10,'MarkerFaceColor','r');
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan')+std(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,3)) & All_Deep(:,3)>=N & All_Deep(:,3)<(N+X)))],'r','LineWidth',3);
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan')-std(All_Deep(All_Deep(:,3)>=N & All_Deep(:,3)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,3)) & All_Deep(:,3)>=N & All_Deep(:,3)<(N+X)))],'r','LineWidth',3);
    plot(N+(X/2),mean(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan'),'sk','MarkerSize',10,'MarkerFaceColor','k');
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan')+std(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,3)) & All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X)))],'k','LineWidth',3);
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan')-std(All_Superficial(All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,3)) & All_Superficial(:,3)>=N & All_Superficial(:,3)<(N+X)))],'k','LineWidth',3);
end
plot([-1 1],[1 1],'k--');


C=5;
X=1;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=0:X:10
    plot(N+(X/2)+(X/10),mean(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan'),'sr','MarkerSize',10,'MarkerFaceColor','r');
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan')+std(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,C)) & All_Deep(:,C)>=N & All_Deep(:,C)<(N+X)))],'r','LineWidth',3);
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan'),mean(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan')-std(All_Deep(All_Deep(:,C)>=N & All_Deep(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Deep(:,C)) & All_Deep(:,C)>=N & All_Deep(:,C)<(N+X)))],'r','LineWidth',3);
    plot(N+(X/2),mean(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan'),'sk','MarkerSize',10,'MarkerFaceColor','k');
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan')+std(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,C)) & All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X)))],'k','LineWidth',3);
    plot([N+(X/2),N+(X/2)],[mean(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan'),mean(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan')-std(All_Superficial(All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Superficial(:,C)) & All_Superficial(:,C)>=N & All_Superficial(:,C)<(N+X)))],'k','LineWidth',3);
end
plot([-1 1],[1 1],'k--');





C=5;
All_Bursty_Deep=All_Deep(All_Deep(:,8)>=0.4,:);
All_Bursty_Superficial=All_Superficial(All_Superficial(:,4)>=0.5,:);
X=1;
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=0:X:(9-X)
    plot(N+(X/2)+(X/10),mean(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan'),'sr','MarkerSize',10,'MarkerFaceColor','r');
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan'),mean(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan')+std(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Bursty_Deep(:,C)) & All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X)))],'r','LineWidth',3);
    plot([N+(X/2)+(X/10),N+(X/2)+(X/10)],[mean(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan'),mean(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan')-std(All_Bursty_Deep(All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Bursty_Deep(:,C)) & All_Bursty_Deep(:,C)>=N & All_Bursty_Deep(:,C)<(N+X)))],'r','LineWidth',3);
    plot(N+(X/2),mean(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan'),'sk','MarkerSize',10,'MarkerFaceColor','k');
    plot([N+(X/2),N+(X/2)],[mean(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan'),mean(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan')+std(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Bursty_Superficial(:,C)) & All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X)))],'k','LineWidth',3);
    plot([N+(X/2),N+(X/2)],[mean(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan'),mean(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan')-std(All_Bursty_Superficial(All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X),2),'omitnan')/sqrt(sum(~isnan(All_Bursty_Superficial(:,C)) & All_Bursty_Superficial(:,C)>=N & All_Bursty_Superficial(:,C)<(N+X)))],'k','LineWidth',3);
end
plot([0 1],[1 1],'k--');



figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
for N=0:X:0.9
end
plot([0 1],[1 1],'k--');



figure;
hold on;
plot(All_Superficial(:,8),All_Superficial(:,2),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
[r,p]=corr(All_Superficial(:,3),All_Superficial(:,2))

figure;
hold on;
plot(All_Deep(:,8),All_Deep(:,2),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
[r,p]=corr(All_Deep(:,3),All_Deep(:,2))

figure;
hold on;
plot(All_Superficial(:,3),All_Superficial(:,1),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
plot([0 0],[0 2.5],'k--');
[r,p]=corr(All_Superficial(:,3),All_Superficial(:,2))

figure;
hold on;
plot(All_Deep(:,3),All_Deep(:,1),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
plot([0 0],[0 2.5],'k--');
[r,p]=corr(All_Deep(:,3),All_Deep(:,2))


figure;
hold on;
plot(All_Large_Superficial(:,3),All_Large_Superficial(:,2),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
plot([0 0],[0 2.5],'k--');
[r,p]=corr(All_Large_Superficial(:,3),All_Large_Superficial(:,2))

figure;
hold on;
plot(All_Large_Deep(:,3),All_Large_Deep(:,2),'ok','MarkerSize',5,'MarkerFaceColor','k');
plot([-1 1],[1 1],'k--');
plot([0 0],[0 2.5],'k--');
[r,p]=corr(All_Large_Deep(:,3),All_Large_Deep(:,2))


cd ..
cd ..

end