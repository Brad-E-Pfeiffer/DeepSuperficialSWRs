function DSRP_FIND_RIPPLE_EVENTS(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the raw LFP data for each tetrode with identified
% units, filters it in the ripple frequency band, and finds changes in
% ripple power that meet the criteria for a ripple.  After finding ripples
% for every tetrode, it then combines ripples found across multiple
% tetrodes.  These ripples are saved in the variable Ripple_Events.
% 
% It also sums the raw z-scores across all electrodes and finds ripples on
% that average.  These ripples are saved in the variable All_Ripple_Events.
%
% Ripple_Events
% |     1      |    2     |     3     |        4       |              5             |                    6                     |
% | Start Time | End Time | Peak Time | Peak Raw Power | Peak Global Z-Scored Power | Peak Z-Scored Power From That Epoch Only |
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

load Epochs
load('Spike_Data','Tetrode_Cell_IDs','Spike_Data');
load('Position_Data','Position_Data');
Duration_To_Remove=Initial_Variables.Duration_To_Remove_Around_Bad_LFP;
if Rat==1
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==3
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==4
        eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Initial_Variables.Raw_LFP_Root_Directory));
    end
elseif Rat==2
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==3
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==4
        eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Initial_Variables.Raw_LFP_Root_Directory));
    end
elseif Rat==3
    if Experiment==1
        eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Initial_Variables.Raw_LFP_Root_Directory));
    elseif Experiment==2
        eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Initial_Variables.Raw_LFP_Root_Directory));
    end
end
Current_Working_Directory=pwd;
cd(Raw_LFP_Directory);
Directory_List=dir;
for N=1:size(Directory_List,1)
    for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if there are more channels, increase this number accordingly
        Comparison_String=sprintf('CSC%d.ncs',M);
        if strcmp(Directory_List(N).name,Comparison_String)
            if exist('LFP_Electrodes','var')
                LFP_Electrodes=[LFP_Electrodes,M];
            else
                LFP_Electrodes=M;
            end
        end
        clear Comparison_String;
    end
end
if ~exist('LFP_Electrodes','var')
    error('ERROR! No CSC files were identified in the listed load directory.')
end
LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
clear M;
clear N;
clear Directory_List;
clear LFP_Electrodes;
clear LFP_Filename;
Ripple_Stop_Low=130;
Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
Ripple_Pass_High=250;
Ripple_Stop_High=275;
Stop_Band_Attenuation_One=60;
Pass_Band=1;
Stop_Band_Attenuation_Two=80;
Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results

for Current_Tetrode=min(Tetrode_Cell_IDs(:,1)):max(Tetrode_Cell_IDs(:,1))
    Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2); %Only processes tetrodes with recorded cells on them
    if ~isempty(Cells_On_This_Tetrode)
        Found_Electrode=0;
        for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
            Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
            if exist(Electrode_Name,'file')==2 && Found_Electrode==0
                Found_Electrode=1;
                LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                for Header_Line=1:length(LFP_Header)
                    Header_Info=cell2mat(LFP_Header(Header_Line));
                    if length(Header_Info)>12
                        if strcmp(Header_Info(1:11),'-ADMaxValue')
                            Max_Value=str2num(Header_Info(13:end));
                        end
                        if strcmp(Header_Info(1:11),'-InputRange')
                            Max_Range=str2num(Header_Info(13:end));
                        end
                    end
                end
                
                LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                Times=zeros(512,size(LFP_Times,2));
                for B=1:length(LFP_Times)-1
                    Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                end
                Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                clear B;
                clear LFP_Times;
                Times=Times(:);
                LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                LFP_Samples=LFP_Samples(:)*(Max_Range/Max_Value);
                LFP_Data=[Times,LFP_Samples];
                LFP_Data=LFP_Data(LFP_Data(:,1)>=(min(Spike_Data(:,1))-10) & LFP_Data(:,1)<=(max(Spike_Data(:,1))+10),:); %Limit looking for ripples to where I actually have spikes clustered
                if ~exist('All_Ripple_LFP_Data','var')
                    All_Ripple_LFP_Data=Times;
                end
                clear Times;
                clear LFP_Samples;
                clear Max_Value;
                
                Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),4);
                Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
                Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
                Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
                Ripple_Filtered_LFP_Data(:,3)=abs(hilbert(Ripple_Filtered_LFP_Data(:,2)));
                Ripple_Gaussian_Filter=fspecial('gaussian',[round(7*(12.5/((1/LFP_Frequency)*1000))),1],round(12.5/((1/LFP_Frequency)*1000)));  %sigma of 12.5 ms
                Ripple_Filtered_LFP_Data(:,3)=filtfilt(Ripple_Gaussian_Filter,1,Ripple_Filtered_LFP_Data(:,3));
                
                %This identifies parts of the LFP that are beyond the recording parameters and for which the true ripple power cannot be properly quantified -- the ripple power of these times and all within Duration_To_Remove seconds will be NaN
                Index_To_Remove=find(LFP_Data(:,2)==Max_Range | LFP_Data(:,2)==(-1*Max_Range));
                for N=1:100000:length(Index_To_Remove)
                    Index_To_Remove2=(ones(length(N:min([N+99999,length(Index_To_Remove)])),1).*((-round(LFP_Frequency*Duration_To_Remove)):round(LFP_Frequency*Duration_To_Remove)))+Index_To_Remove(N:min([N+99999,length(Index_To_Remove)]));
                    Index_To_Remove2=Index_To_Remove2(:);
                    Index_To_Remove2=Index_To_Remove2(Index_To_Remove2>0 & Index_To_Remove2<=size(Ripple_Filtered_LFP_Data,1));
                    Ripple_Filtered_LFP_Data(Index_To_Remove2,4)=1;
                end
                Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,4)==1,3)=NaN;
%                 eval(sprintf('Ripple_Filtered_LFP_Data_Tetrode_%d=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,4)==0,1:2);',Current_Tetrode));
                clear N;
                clear LFP_Data;
                clear Max_Range;
                clear Index_To_Remove;
                clear Index_To_Remove2;
                
                %This adds the ripple power from all tetrodes together so an average power across all tetrodes can be calculated later 
                All_Ripple_LFP_Data(:,end+1)=NaN;
                Integration_Index=round(interp1(Ripple_Filtered_LFP_Data(:,1),1:size(Ripple_Filtered_LFP_Data,1),All_Ripple_LFP_Data(:,1),'nearest'));
                Integration_Index(Integration_Index==0)=1;
                Integration_Index(Integration_Index>size(Ripple_Filtered_LFP_Data,1))=size(Ripple_Filtered_LFP_Data,1);
                All_Ripple_LFP_Data(~isnan(Integration_Index),end)=Ripple_Filtered_LFP_Data(Integration_Index(~isnan(Integration_Index)),3);
                All_Ripple_LFP_Data(isnan(Integration_Index),end)=NaN;
                clear Integration_Index;
                
            end
        end
    end
    disp(sprintf('Finished quantifying ripple data for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
end

All_Ripple_LFP_Data=[All_Ripple_LFP_Data(:,1),mean(All_Ripple_LFP_Data(:,2:end),2,'omitnan')];

cd(Current_Working_Directory);

%Ripple power can be different between wake and sleep, so the program
%processes each behavioral state seperately.

%First, it finds the ripple-filtered LFP during immobility in the
%environment, during SWS in the sleep box, and during awake immobility in
%the sleep box.

%==================================================================================
%This finds ripples based on the mean power across all tetrodes with recorded cells
%================================================================================== 
%This finds periods of immobility in the environment exploration portion of the experiment
Position_Data(:,5)=SRS_CALCULATE_VELOCITY(Position_Data);
Stopped_Times=zeros(1,2);
if Position_Data(1,5)<=Initial_Variables.Velocity_Cutoff
    Stopped_Times(end+1,:)=[Position_Data(1,1),Position_Data(find(Position_Data(:,5)>Initial_Variables.Velocity_Cutoff,1,'first')-1,1)];
end
for N=2:size(Position_Data,1)
    if Position_Data(N-1,5)>Initial_Variables.Velocity_Cutoff && Position_Data(N,5)<=Initial_Variables.Velocity_Cutoff
        L=N;
        while L<size(Position_Data,1) && Position_Data(L,5)<=Initial_Variables.Velocity_Cutoff
            L=L+1;
        end
        Stopped_Times(end+1,:)=[Position_Data(N,1),Position_Data(L,1)];
    end
end
Stopped_Times=Stopped_Times(2:end,:);

%This isolates the ripple LFP data for only periods of immobility in the environment
Stopped_Run_Ripple_LFP_Data=All_Ripple_LFP_Data(1,:);
for N=1:size(Stopped_Times,1)
    Stopped_Run_Ripple_LFP_Data=[Stopped_Run_Ripple_LFP_Data;All_Ripple_LFP_Data(All_Ripple_LFP_Data(:,1)>=Stopped_Times(N,1) & All_Ripple_LFP_Data(:,1)<=Stopped_Times(N,2),:)];
end
Stopped_Run_Ripple_LFP_Data=Stopped_Run_Ripple_LFP_Data(2:end,:);
Stopped_Run_Ripple_LFP_Data=sortrows(Stopped_Run_Ripple_LFP_Data,1);

%This isolates the ripple LFP data for only periods of slow-wave sleep in the sleep box
SWS_Ripple_LFP_Data=All_Ripple_LFP_Data(1,:);
for N=1:size(SWS_Times)
    SWS_Ripple_LFP_Data=[SWS_Ripple_LFP_Data;All_Ripple_LFP_Data(All_Ripple_LFP_Data(:,1)>=SWS_Times(N,1) & All_Ripple_LFP_Data(:,1)<=SWS_Times(N,2),:)];
end
SWS_Ripple_LFP_Data=SWS_Ripple_LFP_Data(2:end,:);
SWS_Ripple_LFP_Data=sortrows(SWS_Ripple_LFP_Data,1);

%This isolates the ripple LFP data for only periods of non-sleep immobility in the sleep box
Immobile_Ripple_LFP_Data=All_Ripple_LFP_Data(1,:);
for N=1:size(Sleep_Box_Awake_Immobile_Times,1)
    Immobile_Ripple_LFP_Data=[Immobile_Ripple_LFP_Data;All_Ripple_LFP_Data(All_Ripple_LFP_Data(:,1)>Sleep_Box_Awake_Immobile_Times(N,1) & All_Ripple_LFP_Data(:,1)<Sleep_Box_Awake_Immobile_Times(N,2),:)];
end
Immobile_Ripple_LFP_Data=Immobile_Ripple_LFP_Data(2:end,:);
Immobile_Ripple_LFP_Data=sortrows(Immobile_Ripple_LFP_Data,1);

All_Immobile_Ripple_LFP=sortrows([Stopped_Run_Ripple_LFP_Data;SWS_Ripple_LFP_Data;Immobile_Ripple_LFP_Data],1);

%This calculates the mean z-scored ripple power across all tetrodes that had recorded cells
Mean_Stopped_Ripple_Power=Stopped_Run_Ripple_LFP_Data;
Mean_Stopped_Ripple_Power=Mean_Stopped_Ripple_Power(~isnan(Mean_Stopped_Ripple_Power(:,2)),:);
Mean_Stopped_Ripple_Power(:,3)=Mean_Stopped_Ripple_Power(:,2);
Mean_Stopped_Ripple_Power(:,2)=zscore(Mean_Stopped_Ripple_Power(:,2));
Mean_Stopped_Ripple_Power(:,4)=0;

Mean_SWS_Ripple_Power=SWS_Ripple_LFP_Data;
Mean_SWS_Ripple_Power=Mean_SWS_Ripple_Power(~isnan(Mean_SWS_Ripple_Power(:,2)),:);
Mean_SWS_Ripple_Power(:,3)=Mean_SWS_Ripple_Power(:,2);
Mean_SWS_Ripple_Power(:,2)=zscore(Mean_SWS_Ripple_Power(:,2));
Mean_SWS_Ripple_Power(:,4)=0;

Mean_Immobile_Ripple_Power=Immobile_Ripple_LFP_Data;
Mean_Immobile_Ripple_Power=Mean_Immobile_Ripple_Power(~isnan(Mean_Immobile_Ripple_Power(:,2)),:);
Mean_Immobile_Ripple_Power(:,3)=Mean_Immobile_Ripple_Power(:,2);
Mean_Immobile_Ripple_Power(:,2)=zscore(Mean_Immobile_Ripple_Power(:,2));
Mean_Immobile_Ripple_Power(:,4)=0;

%This calculates the z-score ripple power across ALL periods of immobility, not just within SWS or awake immobility 
All_Immobile_Ripple_Power=All_Immobile_Ripple_LFP;
All_Immobile_Ripple_Power=All_Immobile_Ripple_Power(~isnan(All_Immobile_Ripple_Power(:,2)),:);
All_Immobile_Ripple_Power(:,3)=All_Immobile_Ripple_Power(:,2);
All_Immobile_Ripple_Power(:,2)=zscore(All_Immobile_Ripple_Power(:,2));
[~,Stopped_Intersect_A,Stopped_Intersect_B]=intersect(All_Immobile_Ripple_Power(:,1),Mean_Stopped_Ripple_Power(:,1));
Mean_Stopped_Ripple_Power(Stopped_Intersect_B,4)=All_Immobile_Ripple_Power(Stopped_Intersect_A,2);
[~,SWS_Intersect_A,SWS_Intersect_B]=intersect(All_Immobile_Ripple_Power(:,1),Mean_SWS_Ripple_Power(:,1));
Mean_SWS_Ripple_Power(SWS_Intersect_B,4)=All_Immobile_Ripple_Power(SWS_Intersect_A,2);
[~,Immobile_Intersect_A,Immobile_Intersect_B]=intersect(All_Immobile_Ripple_Power(:,1),Mean_Immobile_Ripple_Power(:,1));
Mean_Immobile_Ripple_Power(Immobile_Intersect_B,4)=All_Immobile_Ripple_Power(Immobile_Intersect_A,2);

%This finds ripple events in the environment
[Peak_Z_Score_Power,Peak_Locations]=findpeaks(Mean_Stopped_Ripple_Power(:,2),'minpeakheight',Initial_Variables.Ripple_Power_Threshold_Multiplier);  %Finds all ripple amplitude peaks above the threshold
Peak_Raw_Power=Mean_Stopped_Ripple_Power(Peak_Locations,3);
Peak_Global_Z_Score_Power=Mean_Stopped_Ripple_Power(Peak_Locations,4);
%This finds start and end of each ripple
Ripple_Events=zeros(length(Peak_Locations),6);
Ripple_Events(:,3:6)=[Mean_Stopped_Ripple_Power(Peak_Locations,1),Peak_Raw_Power,Peak_Global_Z_Score_Power,Peak_Z_Score_Power];
for N=1:size(Ripple_Events,1)
    L=Peak_Locations(N);
    while Mean_Stopped_Ripple_Power(L,2)>0 && L>1 %this finds the closest timepoint prior to the current peak that crosses the mean
        L=L-1;
    end
    Ripple_Events(N,1)=Mean_Stopped_Ripple_Power(L,1);
    L=Peak_Locations(N);
    while Mean_Stopped_Ripple_Power(L,2)>0 && L<size(Mean_Stopped_Ripple_Power,1) %this finds the closest timepoint after the current peak that crosses the mean
        L=L+1;
    end
    Ripple_Events(N,2)=Mean_Stopped_Ripple_Power(L,1);
end
%This concatenates ripples
for N=2:size(Ripple_Events,1)
    if Ripple_Events(N,1)-Ripple_Events(N-1,2)<=Initial_Variables.Ripple_Concatenation_Distance  %Combine ripples that are likely concatenated ripples
        Ripple_Events(N,1)=Ripple_Events(N-1,1);
        Ripple_Events(N-1,1)=0;
        if Ripple_Events(N-1,5)>Ripple_Events(N,5)
            Ripple_Events(N,3:5)=Ripple_Events(N-1,3:5);
        end
    end
end
Ripple_Events=Ripple_Events(Ripple_Events(:,1)>0,:);
Ripple_Events=Ripple_Events((Ripple_Events(:,2)-Ripple_Events(:,1))<=Initial_Variables.Ripple_Maximum_Duration & (Ripple_Events(:,2)-Ripple_Events(:,1))>=Initial_Variables.Ripple_Minimum_Duration,:); %Remove all ripples that are too long or too short
All_Ripple_Events=Ripple_Events;
clear Ripple_Events;

%This finds ripple events during SWS
[Peak_Z_Score_Power,Peak_Locations]=findpeaks(Mean_SWS_Ripple_Power(:,2),'minpeakheight',Initial_Variables.Ripple_Power_Threshold_Multiplier);  %Finds all ripple amplitude peaks above the threshold
Peak_Raw_Power=Mean_SWS_Ripple_Power(Peak_Locations,3);
Peak_Global_Z_Score_Power=Mean_SWS_Ripple_Power(Peak_Locations,4);
%This finds start and end of each ripple
Ripple_Events=zeros(length(Peak_Locations),6);
Ripple_Events(:,3:6)=[Mean_SWS_Ripple_Power(Peak_Locations,1),Peak_Raw_Power,Peak_Global_Z_Score_Power,Peak_Z_Score_Power];
for N=1:size(Ripple_Events,1)
    L=Peak_Locations(N);
    while Mean_SWS_Ripple_Power(L,2)>0 && L>1 %this finds the closest timepoint prior to the current peak that crosses the mean
        L=L-1;
    end
    Ripple_Events(N,1)=Mean_SWS_Ripple_Power(L,1);
    L=Peak_Locations(N);
    while Mean_SWS_Ripple_Power(L,2)>0 && L<size(Mean_SWS_Ripple_Power,1) %this finds the closest timepoint after the current peak that crosses the mean
        L=L+1;
    end
    Ripple_Events(N,2)=Mean_SWS_Ripple_Power(L,1);
end
%This concatenates ripples
for N=2:size(Ripple_Events,1)
    if Ripple_Events(N,1)-Ripple_Events(N-1,2)<=Initial_Variables.Ripple_Concatenation_Distance  %Combine ripples that are likely concatenated ripples
        Ripple_Events(N,1)=Ripple_Events(N-1,1);
        Ripple_Events(N-1,1)=0;
        if Ripple_Events(N-1,5)>Ripple_Events(N,5)
            Ripple_Events(N,3:5)=Ripple_Events(N-1,3:5);
        end
    end
end
Ripple_Events=Ripple_Events(Ripple_Events(:,1)>0,:);
Ripple_Events=Ripple_Events((Ripple_Events(:,2)-Ripple_Events(:,1))<=Initial_Variables.Ripple_Maximum_Duration & (Ripple_Events(:,2)-Ripple_Events(:,1))>=Initial_Variables.Ripple_Minimum_Duration,:); %Remove all ripples that are too long or too short
All_Ripple_Events=[All_Ripple_Events;Ripple_Events];
clear Ripple_Events;

%This finds ripple events during non-sleep immobility in the sleep box
[Peak_Z_Score_Power,Peak_Locations]=findpeaks(Mean_Immobile_Ripple_Power(:,2),'minpeakheight',Initial_Variables.Ripple_Power_Threshold_Multiplier);  %Finds all ripple amplitude peaks above the threshold
Peak_Raw_Power=Mean_Immobile_Ripple_Power(Peak_Locations,3);
Peak_Global_Z_Score_Power=Mean_Immobile_Ripple_Power(Peak_Locations,4);
%This finds start and end of each ripple
Ripple_Events=zeros(length(Peak_Locations),6);
Ripple_Events(:,3:6)=[Mean_Immobile_Ripple_Power(Peak_Locations,1),Peak_Raw_Power,Peak_Global_Z_Score_Power,Peak_Z_Score_Power];
for N=1:size(Ripple_Events,1)
    L=Peak_Locations(N);
    while Mean_Immobile_Ripple_Power(L,2)>0 && L>1 %this finds the closest timepoint prior to the current peak that crosses the mean
        L=L-1;
    end
    Ripple_Events(N,1)=Mean_Immobile_Ripple_Power(L,1);
    L=Peak_Locations(N);
    while Mean_Immobile_Ripple_Power(L,2)>0 && L<size(Mean_Immobile_Ripple_Power,1) %this finds the closest timepoint after the current peak that crosses the mean
        L=L+1;
    end
    Ripple_Events(N,2)=Mean_Immobile_Ripple_Power(L,1);
end
%This concatenates ripples
for N=2:size(Ripple_Events,1)
    if Ripple_Events(N,1)-Ripple_Events(N-1,2)<=Initial_Variables.Ripple_Concatenation_Distance  %Combine ripples that are likely concatenated ripples
        Ripple_Events(N,1)=Ripple_Events(N-1,1);
        Ripple_Events(N-1,1)=0;
        if Ripple_Events(N-1,5)>Ripple_Events(N,5)
            Ripple_Events(N,3:5)=Ripple_Events(N-1,3:5);
        end
    end
end
Ripple_Events=Ripple_Events(Ripple_Events(:,1)>0,:);
Ripple_Events=Ripple_Events((Ripple_Events(:,2)-Ripple_Events(:,1))<=Initial_Variables.Ripple_Maximum_Duration & (Ripple_Events(:,2)-Ripple_Events(:,1))>=Initial_Variables.Ripple_Minimum_Duration,:); %Remove all ripples that are too long or too short
All_Ripple_Events=[All_Ripple_Events;Ripple_Events];
clear Ripple_Events;

All_Ripple_Events=sortrows(All_Ripple_Events,1);
Ripple_Events=All_Ripple_Events;

cd(Current_Working_Directory)
save('Ripple_Events','Ripple_Events');

end