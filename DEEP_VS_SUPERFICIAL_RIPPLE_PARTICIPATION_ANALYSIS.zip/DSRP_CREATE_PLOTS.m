function DSRP_CREATE_PLOTS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function creates many of the figures for Berndt, Trusel et al.
% A few of the panels are plotted by prior functions, including panels A-D,
% which are plotted by the function DSRP_PLOT_DEPTH_MEASUREMENTS.  There
% are many more plots here than are used in the manuscript.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

DSRP_CREATE_PER_SESSION_PARTICIPATION_PLOTS(Initial_Variables);

DSRP_CREATE_PER_SESSION_FIRING_RATE_PLOTS(Initial_Variables);

DSRP_CREATE_PER_CELL_PARTICIPATION_EMR_PLOTS(Initial_Variables);

DSRP_CREATE_PER_CELL_FIRING_RATE_EMR_PLOTS(Initial_Variables);

DSRP_CREATE_PER_CELL_PARTICIPATION_EMR_PLOTS_ALL_CELLS(Initial_Variables);

DSRP_CREATE_PER_CELL_FIRING_RATE_EMR_PLOTS_ALL_CELLS(Initial_Variables);

DSRP_CREATE_RAW_PER_CELL_PARTICIPATION_AND_FIRING_RATE_PLOTS(Initial_Variables);

DSRP_CREATE_PEAK_FR_VS_EMR_PLOTS(Initial_Variables);

DSRP_CREATE_ON_TASK_INDEX_VS_EMR_PLOTS(Initial_Variables);

DSRP_CREATE_ON_TASK_BURSTINESS_VS_EMR_PLOTS(Initial_Variables);

DSRP_CREATE_PEAK_FR_VS_PRECISION_PLOTS(Initial_Variables);

DSRP_CREATE_ON_TASK_INDEX_VS_PRECISION_PLOTS(Initial_Variables);
DSRP_CREATE_ON_TASK_INDEX_VS_PRECISION_PLOTS_MINUS_CURRENT_CELL(Initial_Variables);


end

