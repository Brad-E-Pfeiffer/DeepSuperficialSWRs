function DSRP_FIND_RIPPLE_PHASE_FOR_EVERY_SPIKE(Initial_Variables,Rat,Experiment)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function quantifies the ripple phase and power of each spike in the
% recording. This is very slow because the ripple phase is determined by the
% local ripple recorded on the same tetrode as the spike, which means the
% program has to load the process the ripple LFP signal for each tetrode.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Raw_LFP_Root_Directory=Initial_Variables.Raw_LFP_Root_Directory;
Duration_To_Remove=Initial_Variables.Duration_To_Remove_Around_Bad_LFP;
load('Spike_Data','Spike_Data','Tetrode_Cell_IDs');

% Spike_Data
% |   1  |     2   |                           3                             |                             4                           ||
% | Time | Cell ID | Ripple Phase (Will be NaN if Within 0.1 s of LFP error) | Ripple Power (Will be NaN if Within 0.1 s of LFP error) ||

if ~isfile('Spike_Data_With_Ripple_Phase.mat')
    disp('Finding Local Ripple Phase and Power For Each Spike.')
    Spike_Data(:,3)=1000;
    Spike_Data(:,4)=NaN;
    if Rat==1
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-13_LinearTrack_BigReward_SameRun\\2010-04-13_14-12-01'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-12_LinearTrack_NoReward_SameRun\\2010-04-12_15-51-58'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-10_LinearTrack_BigReward_DifferentRun\\2010-04-10_12-24-11'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Janni\\2010-04-08_LinearTrack_NoReward_DifferentRun\\2010-04-08_16-14-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==2
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-15 Linear_Track_BigReward_DuringRun\\2010-01-15_16-36-30'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-14 Linear_Track_NoReward_DuringRun\\2010-01-14_16-12-24'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==3
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-19 Linear_Track_BigReward_DifferentRuns\\2010-01-19_15-45-54'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==4
            eval(sprintf('Raw_LFP_Directory=''%s\\Harpy\\2010-01-20 Linear_Track_NoReward_DifferentRuns\\2010-01-20_16-01-25'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    elseif Rat==3
        if Experiment==1
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090616_FirstExp_PlusMinusReward\\2009-06-16_10-22-20'';',Initial_Variables.Raw_LFP_Root_Directory));
        elseif Experiment==2
            eval(sprintf('Raw_LFP_Directory=''%s\\Ettin\\20090618_SecondExp_RewardBigReward\\2009-06-18_10-41-37'';',Initial_Variables.Raw_LFP_Root_Directory));
        end
    end
    Current_Working_Directory=pwd;
    cd(Raw_LFP_Directory);
    Directory_List=dir;
    for N=1:size(Directory_List,1)
        for M=1:160 %This program assumes a maximum of 40 tetrodes, thus a maximum of 160 channels -- if there are more channels, increase this number accordingly
            Comparison_String=sprintf('CSC%d.ncs',M);
            if strcmp(Directory_List(N).name,Comparison_String)
                if exist('LFP_Electrodes','var')
                    LFP_Electrodes=[LFP_Electrodes,M];
                else
                    LFP_Electrodes=M;
                end
            end
            clear Comparison_String;
        end
    end
    if ~exist('LFP_Electrodes','var')
        error('ERROR! No CSC files were identified in the listed load directory.')
    end
    LFP_Filename=sprintf('CSC%d.ncs',LFP_Electrodes(1));
    LFP_Frequency=Nlx2MatCSC(LFP_Filename,[0 0 1 0 0],0,3,1);  %This assumes that the recording frequency is the same for all LFPs, so it just grabs the frequency from the first LFP trace
    clear M;
    clear N;
    clear Directory_List;
    clear LFP_Electrodes;
    clear LFP_Filename;
    
    Ripple_Stop_Low=130;
    Ripple_Pass_Low=150;             % Most papers use between 150 and 250 Hz to identify ripples
    Ripple_Pass_High=250;
    Ripple_Stop_High=275;
    Stop_Band_Attenuation_One=60;
    Pass_Band=1;
    Stop_Band_Attenuation_Two=80;
    Filter_Design_For_Ripple=fdesign.bandpass(Ripple_Stop_Low, Ripple_Pass_Low, Ripple_Pass_High, Ripple_Stop_High, Stop_Band_Attenuation_One, Pass_Band, Stop_Band_Attenuation_Two, LFP_Frequency);
    Ripple_Filter=design(Filter_Design_For_Ripple,'butter');  %'equiripple' and 'cheby1' and 'cheby2' also work, but 'butter' was generally faster and gave similar results
    
    for Current_Tetrode=min(Tetrode_Cell_IDs(:,1)):max(Tetrode_Cell_IDs(:,1))
        Cells_On_This_Tetrode=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Current_Tetrode,2); %Only processes tetrodes with recorded cells on them
        if ~isempty(Cells_On_This_Tetrode)
            Found_Electrode=0;
            for Current_Electrode=((Current_Tetrode*4)-3):(Current_Tetrode*4) %Only one electrode from the tetrode had LFP recorded on it -- this part finds that electrode
                Electrode_Name=sprintf('CSC%d.ncs',Current_Electrode);
                if isfile(Electrode_Name) && Found_Electrode==0
                    Found_Electrode=1;
                    LFP_Header=Nlx2MatCSC(Electrode_Name,[0 0 0 0 0],1,1,0);
                    for Header_Line=1:length(LFP_Header)
                        Header_Info=cell2mat(LFP_Header(Header_Line));
                        if length(Header_Info)>12
                            if strcmp(Header_Info(1:11),'-ADMaxValue')
                                Max_Value=str2num(Header_Info(13:end));
                            end
                            if strcmp(Header_Info(1:11),'-InputRange')
                                Max_Range=str2num(Header_Info(13:end));
                            end
                        end
                    end
                    LFP_Times=Nlx2MatCSC(Electrode_Name,[1 0 0 0 0],0,1)/1000000;
                    Times=zeros(512,size(LFP_Times,2));
                    for B=1:length(LFP_Times)-1
                        Times(:,B)=LFP_Times(B)+((0:(511))*((LFP_Times(B+1)-LFP_Times(B))/(512)))';
                    end
                    Times(:,end)=LFP_Times(end)+((0:(511))*((LFP_Times(end)-LFP_Times(end-1))/(512)))';
                    clear B;
                    clear LFP_Times;
                    Times=Times(:);
                    LFP_Samples=Nlx2MatCSC(Electrode_Name,[0 0 0 0 1],0,1);
                    LFP_Samples=LFP_Samples(:)*-(Max_Range/Max_Value); %Multiply by -1 to correct for the fact that the raw LFP was recorded inverted (see Header info)
                    LFP_Data=[Times,LFP_Samples];
                    Index_To_Remove=find(LFP_Data(:,2)==Max_Range | LFP_Data(:,2)==(-1*Max_Range));
                    clear Times;
                    clear LFP_Samples;
                    clear Max_Value;
                    
                    Ripple_Filtered_LFP_Data=zeros(size(LFP_Data,1),5);
                    Ripple_Filtered_LFP_Data(:,1)=LFP_Data(:,1);
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);    % filtfilt doesn't work for these band-pass filters, so I have to manually filter, flip the resultant dataset, and filter again in the opposite direction to get a zero-phase distortion
                    Ripple_Filtered_LFP_Data(:,2)=filter(Ripple_Filter,Ripple_Filtered_LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,2)=Ripple_Filtered_LFP_Data(end:-1:1,2);
                    Ripple_Filtered_LFP_Data(:,3)=hilbert(Ripple_Filtered_LFP_Data(:,2));
                    Ripple_Filtered_LFP_Data(:,4)=(angle(Ripple_Filtered_LFP_Data(:,3))*180/pi);
                    Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,4)<=0,4)=Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,4)<=0,4)+360;
                    clear LFP_Data;
                    
                    %This identifies parts of the LFP that are beyond the recording parameters and for which a phase cannot be properly quantified -- the phase of these times and all within Duration_To_Remove seconds will be NaN 
                    for N=1:100000:length(Index_To_Remove)
                        Index_To_Remove2=(ones(length(N:min([N+99999,length(Index_To_Remove)])),1).*((-round(LFP_Frequency*Duration_To_Remove)):round(LFP_Frequency*Duration_To_Remove)))+Index_To_Remove(N:min([N+99999,length(Index_To_Remove)]));
                        Index_To_Remove2=Index_To_Remove2(:);
                        Index_To_Remove2=Index_To_Remove2(Index_To_Remove2>0 & Index_To_Remove2<=size(Ripple_Filtered_LFP_Data,1));
                        Ripple_Filtered_LFP_Data(Index_To_Remove2,5)=1;
                    end
                    Ripple_Filtered_LFP_Data(Ripple_Filtered_LFP_Data(:,5)==1,3:4)=NaN;
                    
                    clear N;
                    clear Max_Range;
                    clear Index_To_Remove;
                    clear Index_To_Remove2;
                    
                    %This finds the phase for each spike recorded on this tetrode
                    for Cell=1:length(Cells_On_This_Tetrode)
                        Current_Cell=Cells_On_This_Tetrode(Cell);
                        Spike_Index=find(Spike_Data(:,2)==Current_Cell & Spike_Data(:,1)>=min(Ripple_Filtered_LFP_Data(:,1)) & Spike_Data(:,1)<=max(Ripple_Filtered_LFP_Data(:,1)));
                        This_Cell_Spike_Data=Spike_Data(Spike_Index,:);
                        This_Cell_Spike_Data(:,3)=interp1(Ripple_Filtered_LFP_Data(:,1),Ripple_Filtered_LFP_Data(:,4),This_Cell_Spike_Data(:,1),'nearest');
                        This_Cell_Spike_Data(This_Cell_Spike_Data(:,1)<min(Ripple_Filtered_LFP_Data(:,1)),3)=NaN;
                        This_Cell_Spike_Data(This_Cell_Spike_Data(:,1)>max(Ripple_Filtered_LFP_Data(:,1)),3)=NaN;
                        Spike_Data(Spike_Index,:)=This_Cell_Spike_Data;
                    end
                    clear Cell;
                end
            end
        end
        disp(sprintf('Finished quantifying ripple phase and power for tetrode %d of %d.',Current_Tetrode,max(Tetrode_Cell_IDs(:,1))));
    end
    Spike_Data=Spike_Data(Spike_Data(:,3)~=1000,:); %This removes any spikes where a phase couldn't be found (typically because they were before/after the first/last LFP data point)
    cd(Current_Working_Directory);
    clear Raw_LFP_Directory;
    clear Current_Directory;
    save('Spike_Data_With_Ripple_Phase','Spike_Data');
end

end

