function DSRP_IDENTIFY_DEEP_AND_SUPERFICIAL_NEURONS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function identifies the mean sharp-wave deflection at each tetrode
% and uses that to assign each tetrode to deep or superficial sublayers.
% This label is then applied to all cells recorded on that tetrode.
% "Large" cells are those with large-amplitude waveforms, which would be
% the cells closest to those recording sites.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

if ~isfile('Deep_And_Superficial_Cell_Identities.mat')
    load('Sharp_Wave_Deflection_Per_Tetrode','Ripple_Events_Sharp_Wave_Deflections')
    load('Combined_Ripple_LFP_Data','Combined_All_Ripple_LFP_Data');
    Sharp_Wave_Deflection_Per_Tetrode=permute(mean(Ripple_Events_Sharp_Wave_Deflections(:,3,:)),[3,2,1]);
    load('Spike_Data','Tetrode_Cell_IDs','Spike_Data','Inhibitory_Neurons')
    for N=1:length(Inhibitory_Neurons)
        Spike_Data=Spike_Data(Spike_Data(:,2)~=Inhibitory_Neurons(N),:);
    end
    load('Tetrode_Cell_Spike_Amplitudes','Tetrode_Cell_Spike_Amplitudes');
    % Spike_Data
    % |         1         |     2   |      3     |                 4                |            5            ||
    % | Time of Spike (s) | Cell ID | Tetrode ID | Sharp-wave Deflection of Tetrode | Largest Spike Amplitude ||
    Spike_Data(:,3:5)=0;
    for N=1:max(Spike_Data(:,2))
        Spike_Data(Spike_Data(:,2)==N,3)=Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,2)==N,1);
        Spike_Data(Spike_Data(:,2)==N,4)=Sharp_Wave_Deflection_Per_Tetrode(Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,2)==N,1));
        Spike_Data(Spike_Data(:,2)==N,5)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==N,3);
    end
    Unique_Tetrodes=unique(Tetrode_Cell_IDs(:,1));
    Deep_Tetrodes=find(Sharp_Wave_Deflection_Per_Tetrode>50);
    Deep_Tetrodes(:,2)=0;
    for N=1:size(Deep_Tetrodes,1)
        if min(Combined_All_Ripple_LFP_Data(:,find(Unique_Tetrodes==Deep_Tetrodes(N))+1))>-150
            Deep_Tetrodes(N,2)=1;
        end
    end
    Deep_Tetrodes=Deep_Tetrodes(Deep_Tetrodes(:,2)==1,1);
    Superficial_Tetrodes=find(Sharp_Wave_Deflection_Per_Tetrode<-50);
    Deep_Cells=0;
    for N=1:length(Deep_Tetrodes)
        Deep_Cells=[Deep_Cells;Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Deep_Tetrodes(N),2)];
    end
    Deep_Cells=Deep_Cells(2:end,:);
    for N=1:length(Inhibitory_Neurons)
        Deep_Cells=Deep_Cells(Deep_Cells~=Inhibitory_Neurons(N));
    end
    Large_Deep_Cells=[Deep_Cells,zeros(length(Deep_Cells),1)];
    for N=1:size(Large_Deep_Cells,1)
        Large_Deep_Cells(N,2)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==Large_Deep_Cells(N,1),3);
    end
    Large_Deep_Cells=Large_Deep_Cells(Large_Deep_Cells(:,2)>Initial_Variables.Spike_Amplitude_Cutoff,1);
    Superficial_Cells=0;
    for N=1:length(Superficial_Tetrodes)
        Superficial_Cells=[Superficial_Cells;Tetrode_Cell_IDs(Tetrode_Cell_IDs(:,1)==Superficial_Tetrodes(N),2)];
    end
    Superficial_Cells=Superficial_Cells(2:end,:);
    for N=1:length(Inhibitory_Neurons)
        Superficial_Cells=Superficial_Cells(Superficial_Cells~=Inhibitory_Neurons(N));
    end
    Large_Superficial_Cells=[Superficial_Cells,zeros(length(Superficial_Cells),1)];
    for N=1:size(Large_Superficial_Cells,1)
        Large_Superficial_Cells(N,2)=Tetrode_Cell_Spike_Amplitudes(Tetrode_Cell_Spike_Amplitudes(:,2)==Large_Superficial_Cells(N,1),3);
    end
    Large_Superficial_Cells=Large_Superficial_Cells(Large_Superficial_Cells(:,2)>Initial_Variables.Spike_Amplitude_Cutoff,1);
    save('Deep_And_Superficial_Cell_Identities','Deep_Cells','Superficial_Cells','Large_Deep_Cells','Large_Superficial_Cells');
end

end