function DSRP_COMPARE_DEEP_AND_SUPERFICIAL_CELLS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function compares properties of identified deep and superficial
% cells to confirm this categorization matches prior literature.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Rats(1).name='Janni';
Rats(2).name='Harpy';
for Rat=1:2
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    end
    for Experiment=1:length(Directory)
        
        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));
        
        if 1%~isfile('Completed_Compare_Deep_Superficial.mat')
                       
            disp('==========================================================================');
            disp(sprintf('Starting Deep-Superficial Comparison Analysis for Rat: %s, Session: %s.',Rat_Name,Directory_Name));
            
            disp('Comparing Place Field And Spiking Properties Between Deep and Superficial Cells.');
            DSRP_COMPARE_PLACE_FIELD_PROPERTIES(Initial_Variables)
            
            Completed_Compare_Deep_Superficial=1;
            save('Completed_Compare_Deep_Superficial','Completed_Compare_Deep_Superficial');
            
            clearvars -except Rat Experiment Initial_Variables Rats Directory Rat_Name
            
        end
            
        cd ..
        
    end
    
    clear Directory
    
    cd ..
    
end

clear Rat
clear Experiment
clear Rats
clearvars -except Initial_Variables

DSRP_PLOT_PLACE_FIELD_PROPERTIES                

end
