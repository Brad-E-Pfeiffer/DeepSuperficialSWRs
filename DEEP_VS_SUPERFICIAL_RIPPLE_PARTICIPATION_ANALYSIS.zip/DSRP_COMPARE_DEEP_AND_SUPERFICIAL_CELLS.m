function DSRP_COMPARE_DEEP_AND_SUPERFICIAL_CELLS(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function compares properties of identified deep and superficial
% cells to confirm this categorization matches prior literature.
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

% Firing_Properties_Per_Cell_During_Behavior
% |    1    |              2                  |                    3                     |              4             |              5            |         6        |                 7                 |                   8                 |              9            |             10            |                 11                 |                  12                  |              13            |           14         ||
% | Cell ID | Peak Firing Rate of Place Field | Mean non-SWR Firing Rate During Behavior | Number Of Spikes In Bursts | Spikes Per On-Task Bursts | Burstiness Index | Pre-Task Rest Non-SWR Firing Rate | Number of Spikes in Pre-Task Bursts | Spikes Per Pre-Task Burst | Pre-Task Burstiness Index | Post-Task Rest Non-SWR Firing Rate | Number of Spikes in Post-Task Bursts | Spikes Per Post-Task Burst | Post-Task Burstiness ||

Deep_Cell_Theta_Phases=zeros(1,1);
Large_Deep_Cell_Theta_Phases=zeros(1,1);
Superficial_Cell_Theta_Phases=zeros(1,1);
Large_Superficial_Cell_Theta_Phases=zeros(1,1);

Rats(1).name='Janni';
Rats(2).name='Harpy';
Rats(3).name='Ettin';
for Rat=1:3
    Rat_Name=Rats(Rat).name;
    eval(sprintf('cd %s',Rat_Name));
    if Rat==1 %Janni
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==2 %Harpy
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
        Directory(3).name='Linear3';
        Directory(4).name='Linear4';
    elseif Rat==3 %Ettin
        Directory(1).name='Linear1';
        Directory(2).name='Linear2';
    end
    for Experiment=1:length(Directory)

        Directory_Name=Directory(Experiment).name;
        eval(sprintf('cd %s',Directory_Name));

        eval(sprintf('disp(''Quantifying Effect of On-Task Firing on Pre- to Post-Task SWR Firing for %s Day %d.'')',Rat_Name,Experiment)); 

        load Deep_And_Superficial_Cell_Identities.mat;
        load Spike_Data_With_Theta_Phase;
        load Epochs;
        Spike_Data(:,4)=0;
        if ~isempty(REM_Times)
            REM_Spike_Data=Spike_Data(1,:);
            for N=1:size(REM_Times,1)
                REM_Spike_Data=[REM_Spike_Data;Spike_Data(Spike_Data(:,1)>=REM_Times(N,1) & Spike_Data(:,1)<=REM_Times(N,2),:)];
            end
            REM_Spike_Data=REM_Spike_Data(2:end,:);
            for Cell=1:max(Spike_Data(:,2))
                Cell_Spike_Data=REM_Spike_Data(REM_Spike_Data(:,2)==Cell,:);
                if ~isempty(Cell_Spike_Data)
                    Mean_Theta_Phase=circ_rad2ang(circ_mean(circ_ang2rad(Cell_Spike_Data(~isnan(Cell_Spike_Data(:,3)),3))));
                    if sum(Deep_Cells==Cell)>0
                        Deep_Cell_Theta_Phases=[Deep_Cell_Theta_Phases;Mean_Theta_Phase];
                        Cell_Spike_Data(:,4)=-1;
                    end
                    if sum(Large_Deep_Cells==Cell)>0
                        Large_Deep_Cell_Theta_Phases=[Large_Deep_Cell_Theta_Phases;Mean_Theta_Phase];
                        Cell_Spike_Data(:,4)=-2;
                    end
                    if sum(Superficial_Cells==Cell)>0
                        Superficial_Cell_Theta_Phases=[Superficial_Cell_Theta_Phases;Mean_Theta_Phase];
                        Cell_Spike_Data(:,4)=1;
                    end
                    if sum(Large_Superficial_Cells==Cell)>0
                        Large_Superficial_Cell_Theta_Phases=[Large_Superficial_Cell_Theta_Phases;Mean_Theta_Phase];
                        Cell_Spike_Data(:,4)=2;
                    end
                end
            end
        end
                        
        for N=1:size(Deep_Cells,1)
            Spike_Data(Spike_Data(:,2)==Deep_Cells(N),4)=-1;
        end
        for N=1:size(Large_Deep_Cells,1)
            Spike_Data(Spike_Data(:,2)==Large_Deep_Cells(N),4)=-1;
        end
        for N=1:size(Superficial_Cells,1)
            Spike_Data(Spike_Data(:,2)==Superficial_Cells(N),4)=-1;
        end
        for N=1:size(Large_Superficial_Cells,1)
            Spike_Data(Spike_Data(:,2)==Large_Superficial_Cells(N),4)=-1;
        end
        load Firing_Properties_Per_Cell_During_Behavior.mat;
        load('Spike_Data','Inhibitory_Neurons');
        load Field_Data;
        for N=1:max(Firing_Properties_Per_Cell_During_Behavior(:,1))
            if sum(Inhibitory_Neurons==N)>0 %|| max(max(Field_Data(:,:,N)))==0 || max(max(Field_Data(:,:,N)))>80
                Firing_Properties_Per_Cell_During_Behavior=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,1)~=N,:);
            end
        end

        Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Deep_Cells),15)=2;
        Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Superficial_Cells),15)=1;
        Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Deep_Cells),16)=2;
        Firing_Properties_Per_Cell_During_Behavior(ismember(Firing_Properties_Per_Cell_During_Behavior(:,1),Large_Superficial_Cells),16)=1;

        Deep=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,15)==2,:);
        Superficial=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,15)==1,:);
        Large_Deep=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,16)==2,:);
        Large_Superficial=Firing_Properties_Per_Cell_During_Behavior(Firing_Properties_Per_Cell_During_Behavior(:,16)==1,:);

        if exist('All_Deep','var')
            All_Deep=[All_Deep;Deep];
            All_Superficial=[All_Superficial;Superficial];
            All_Large_Deep=[All_Large_Deep;Large_Deep];
            All_Large_Superficial=[All_Large_Superficial;Large_Superficial];
        else
            All_Deep=Deep;
            All_Superficial=Superficial;
            All_Large_Deep=Large_Deep;
            All_Large_Superficial=Large_Superficial;
        end
        cd ..

    end
    
    clear Directory
    cd ..

end

Deep_Cell_Theta_Phases=Deep_Cell_Theta_Phases(2:end,:);
Large_Deep_Cell_Theta_Phases=Large_Deep_Cell_Theta_Phases(2:end,:);
Superficial_Cell_Theta_Phases=Superficial_Cell_Theta_Phases(2:end,:);
Large_Superficial_Cell_Theta_Phases=Large_Superficial_Cell_Theta_Phases(2:end,:);

cd _Figures

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
Deep_Theta_Histogram=histcounts(Deep_Cell_Theta_Phases,-180:20:180);
Superficial_Theta_Histogram=histcounts(Superficial_Cell_Theta_Phases,-180:20:180);
plot([Deep_Theta_Histogram,Deep_Theta_Histogram]/sum(Deep_Theta_Histogram),'r','LineWidth',3);
plot([Superficial_Theta_Histogram,Superficial_Theta_Histogram]/sum(Superficial_Theta_Histogram),'b','LineWidth',3);
Y_Lim=ylim;
set(gca,'XLim',[1 36]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
eval(sprintf('print(''-djpeg'',''Deep_Vs_Superficial_Per_Cell_Preferred_Theta_Phase_During_REM(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close


Deep_Burst_Histogram=histcounts(All_Deep(:,10),[0:0.05:1]);
Superficial_Burst_Histogram=histcounts(All_Superficial(:,10),[0:0.05:1]);
Large_Deep_Burst_Histogram=histcounts(All_Large_Deep(:,10),[0:0.05:1]);
Large_Superficial_Burst_Histogram=histcounts(All_Large_Superficial(:,10),[0:0.05:1]);

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(0.025:0.05:1,Superficial_Burst_Histogram/sum(Superficial_Burst_Histogram),'r','LineWidth',3);
plot(0.025:0.05:1,Deep_Burst_Histogram/sum(Deep_Burst_Histogram),'b','LineWidth',3);
set(gca,'XLim',[0 1]);
set(gca,'XTick',[]);
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Deep_Vs_Superficial_Cell_Burst_Index_Proportion(X=0to1,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Burst_Index_Deep_Vs_Superficial_H,Burst_Index_Deep_Vs_Superficial_P]=kstest2(All_Deep(:,10),All_Superficial(:,10))

Bins=10.^(-2.15:0.15:1.3);
Deep_Firing_Rate_Histogram=histcounts(All_Deep(:,7),Bins);
Superficial_Firing_Rate_Histogram=histcounts(All_Superficial(:,7),Bins);
Large_Deep_Firing_Rate_Histogram=histcounts(All_Large_Deep(:,7),Bins);
Large_Superficial_Firing_Rate_Histogram=histcounts(All_Large_Superficial(:,7),Bins);

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Bins(2:end),Superficial_Firing_Rate_Histogram/sum(Superficial_Firing_Rate_Histogram),'r','LineWidth',3);
plot(Bins(2:end),Deep_Firing_Rate_Histogram/sum(Deep_Firing_Rate_Histogram),'b','LineWidth',3);
set(gca,'XLim',[0.01 20]);
set(gca,'XScale','log');
set(gca,'YTick',[]);
Y_Lim=ylim;
eval(sprintf('print(''-djpeg'',''Deep_Vs_Superficial_Cell_Firing_Rate_ProportionWithXTick(X=0to20Log,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
set(gca,'XTick',[]);
eval(sprintf('print(''-djpeg'',''Deep_Vs_Superficial_Cell_Firing_Rate_Proportion(X=0to20Log,Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close

[Firing_Rate_Deep_Vs_Superficial_H,Firing_Rate_Deep_Vs_Superficial_P]=kstest2(All_Deep(:,7),All_Superficial(:,7))


Deep_Experience_Index_Non_SWR_Firing_Rate_Index=(All_Deep(:,11)-All_Deep(:,7))./(All_Deep(:,11)+All_Deep(:,7));
Super_Experience_Index_Non_SWR_Firing_Rate_Index=(All_Superficial(:,11)-All_Superficial(:,7))./(All_Superficial(:,11)+All_Superficial(:,7));
Large_Deep_Experience_Index_Non_SWR_Firing_Rate_Index=(All_Large_Deep(:,11)-All_Large_Deep(:,7))./(All_Large_Deep(:,11)+All_Large_Deep(:,7));
Large_Super_Experience_Index_Non_SWR_Firing_Rate_Index=(All_Large_Superficial(:,11)-All_Large_Superficial(:,7))./(All_Large_Superficial(:,11)+All_Large_Superficial(:,7));
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxplot(Large_Deep_Experience_Index_Non_SWR_Firing_Rate_Index);
set(gca,'YLim',[-1 1]);
print('-djpeg','Deep_Cell_Non_SWR_Firing_Rate_Index(Y=-1to1).jpg');
close
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxplot(Large_Super_Experience_Index_Non_SWR_Firing_Rate_Index);
set(gca,'YLim',[-1 1]);
print('-djpeg','Superficial_Cell_Non_SWR_Firing_Rate_Index(Y=-1to1).jpg');
close
[Deep_Cell_Non_SWR_Firing_Rate_Index_P,Deep_Cell_Non_SWR_Firing_Rate_Index_H]=signrank(Large_Deep_Experience_Index_Non_SWR_Firing_Rate_Index)
[Superficial_Cell_Non_SWR_Firing_Rate_Index_P,Superficial_Cell_Non_SWR_Firing_Rate_Index_H]=signrank(Large_Super_Experience_Index_Non_SWR_Firing_Rate_Index)
[Non_SWR_Firing_Rate_Index_H,Non_SWR_Firing_Rate_Index_P]=ranksum(Large_Deep_Experience_Index_Non_SWR_Firing_Rate_Index,Large_Super_Experience_Index_Non_SWR_Firing_Rate_Index)


cd ..



end
