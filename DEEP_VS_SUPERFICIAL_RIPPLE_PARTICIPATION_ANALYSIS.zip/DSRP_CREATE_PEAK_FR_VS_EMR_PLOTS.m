function DSRP_CREATE_PEAK_FR_VS_EMR_PLOTS(Initial_Variables)

%==========================================================================
%==========================================================================
%
% Plot On-Task Peak Firing Rate Vs. Experience Modulation of Ripple Firing For Large-Amplitude Spike Cells
%
%==========================================================================
%==========================================================================

cd AllRatsCombined

load All_Per_Ripple_And_Per_Cell_Analysis
load All_Firing_Properties_During_Behavior

cd ..
cd _Figures
if ~isfolder('Experience_Modulation_Of_SWR_Activity')
    mkdir('Experience_Modulation_Of_SWR_Activity')
end
cd 'Experience_Modulation_Of_SWR_Activity'

if ~isfolder('Correlation_Peak_In_Firing_And_Ripple_Modulation')
    mkdir('Correlation_In_Peak_Firing_And_Ripple_Modulation')
end
cd('Correlation_In_Peak_Firing_And_Ripple_Modulation')

%--------------------------------------------------------------------------

%Participation for Large Cells for All Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_All(:,1)./All_Large_Deep_Per_Cell_Pre_All(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_All(:,1)./All_Large_Super_Per_Cell_Pre_All(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>=1,1),Deep(Deep(:,1)>=1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>=1,1),Super(Super(:,1)>=1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_All_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_All_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_All_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_All_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_All_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Participation_All_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Participation_All_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Participation_All_Hi_P=signrank(Super(Super(:,1)>5,2))*6

%--------------------------------------------------------------------------

%Participation for Large Cells for Coherent Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,1)./All_Large_Deep_Per_Cell_Pre_Coherent(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_Coherent(:,1)./All_Large_Super_Per_Cell_Pre_Coherent(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>=1,1),Deep(Deep(:,1)>=1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>=1,1),Super(Super(:,1)>=1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Coherent_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_Coherent_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_Coherent_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Participation_Coherent_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Participation_Coherent_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Participation_Coherent_Hi_P=signrank(Super(Super(:,1)>5,2))*6

%--------------------------------------------------------------------------

%Participation for Large Cells for Fragmented Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,1)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,1))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,1)./All_Large_Super_Per_Cell_Pre_Fragmented(:,1))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>1,1),Deep(Deep(:,1)>1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>1,1),Super(Super(:,1)>1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Fragmented_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Participation_EMR_Large_Cells_Fragmented_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Participation_Fragmented_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_Fragmented_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Participation_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Participation_Fragmented_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Participation_Fragmented_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Participation_Fragmented_Hi_P=signrank(Super(Super(:,1)>5,2))*6


%--------------------------------------------------------------------------
%==========================================================================
%--------------------------------------------------------------------------


%Firing Rate for Large Cells for All Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_All(:,3)./All_Large_Deep_Per_Cell_Pre_All(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_All(:,3)./All_Large_Super_Per_Cell_Pre_All(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_All_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>=1,1),Deep(Deep(:,1)>=1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>=1,1),Super(Super(:,1)>=1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_All_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_All_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_All_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Firing_Rate_All_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Firing_Rate_All_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Firing_Rate_All_Hi_P=signrank(Super(Super(:,1)>5,2))*6

%--------------------------------------------------------------------------

%Firing Rate for Large Cells for Coherent Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_Coherent(:,3)./All_Large_Deep_Per_Cell_Pre_Coherent(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_Coherent(:,3)./All_Large_Super_Per_Cell_Pre_Coherent(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>1,1),Deep(Deep(:,1)>1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>1,1),Super(Super(:,1)>1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Coherent_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Coherent_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_Coherent_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_Coherent_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Firing_Rate_Coherent_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Firing_Rate_Coherent_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Firing_Rate_Coherent_Hi_P=signrank(Super(Super(:,1)>5,2))*6

%--------------------------------------------------------------------------

%Firing Rate for Large Cells for Fragmented Ripples

Deep=[(All_Large_Deep_Firing_Properties_During_Behavior(:,10)),log(All_Large_Deep_Per_Cell_Post_Fragmented(:,3)./All_Large_Deep_Per_Cell_Pre_Fragmented(:,3))];
Deep=Deep(~isnan(Deep(:,1)) & ~isnan(Deep(:,2)) & ~isinf(abs(Deep(:,1))) & ~isinf(abs(Deep(:,2))),:);
Super=[(All_Large_Super_Firing_Properties_During_Behavior(:,10)),log(All_Large_Super_Per_Cell_Post_Fragmented(:,3)./All_Large_Super_Per_Cell_Pre_Fragmented(:,3))];
Super=Super(~isnan(Super(:,1)) & ~isnan(Super(:,2)) & ~isinf(abs(Super(:,1))) & ~isinf(abs(Super(:,2))),:);
figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
plot(Deep(:,1),Deep(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0.7 0 0],'MarkerFaceColor',[0.7 0 0]);
plot(Super(:,1),Super(:,2),'.','MarkerSize',15,'MarkerEdgeColor',[0 0 0.7],'MarkerFaceColor',[0 0 0.7]);
X_Lim=xlim;
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[-1 X_Lim(2)]);
X_Lim=xlim;
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
plot([X_Lim(1) X_Lim(2)],[0 0],'k--');
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_Dot_Plot_WithLines(Y=%dto%d)(X=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2),X_Lim(1),X_Lim(2)));
close
[Large_Deep_Firing_Rate_All_Corr_R,Large_Deep_Firing_Rate_All_Corr_P]=corr(Deep(Deep(:,1)>1,1),Deep(Deep(:,1)>1,2))
[Large_Super_Firing_Rate_All_Corr_R,Large_Super_Firing_Rate_All_Corr_P]=corr(Super(Super(:,1)>1,1),Super(Super(:,1)>1,2))

figure;
hold on;
subplot('Position',[0 0 1 1]);
hold on;
boxchart(ones(sum(Deep(:,1)<=0),1)*1,Deep(Deep(:,1)<=0,2),'Notch','on','BoxFaceColor',[1 0 0],'WhiskerLineColor',[1 0 0],'MarkerColor',[1 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>0 & Deep(:,1)<=5),1)*2,Deep(Deep(:,1)>0 & Deep(:,1)<=5,2),'Notch','on','BoxFaceColor',[0.7 0 0],'WhiskerLineColor',[0.7 0 0],'MarkerColor',[0.7 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Deep(:,1)>5),1)*3,Deep(Deep(:,1)>5,2),'Notch','on','BoxFaceColor',[0.5 0 0],'WhiskerLineColor',[0.5 0 0],'MarkerColor',[0.5 0 0],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)<=0),1)*4,Super(Super(:,1)<=0,2),'Notch','on','BoxFaceColor',[0 0 1],'WhiskerLineColor',[0 0 1],'MarkerColor',[0 0 1],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>0 & Super(:,1)<=5),1)*5,Super(Super(:,1)>0 & Super(:,1)<=5,2),'Notch','on','BoxFaceColor',[0 0 0.7],'WhiskerLineColor',[0 0 0.7],'MarkerColor',[0 0 0.7],'linew',3,'MarkerStyle','+');
boxchart(ones(sum(Super(:,1)>5),1)*6,Super(Super(:,1)>5,2),'Notch','on','BoxFaceColor',[0 0 0.5],'WhiskerLineColor',[0 0 0.5],'MarkerColor',[0 0 0.5],'linew',3,'MarkerStyle','+');
Y_Lim=ylim;
set(gca,'XTick',[]);
set(gca,'YTick',[]);
set(gca,'XLim',[0.5 6.5]);
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_3Way_Bar_Graph_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
plot([0 7],[0 0],'k--')
eval(sprintf('print(''-djpeg'',''Peak_InField_Firing_Rate_Vs_Firing_Rate_EMR_Large_Cells_Fragmented_Ripples_3Way_Bar_Graph_WithLine_(Y=%dto%d).jpg'');',Y_Lim(1),Y_Lim(2)));
close
Large_Deep_Firing_Rate_Fragmented_NP_P=signrank(Deep(Deep(:,1)<=0,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_Fragmented_Lo_P=signrank(Deep(Deep(:,1)>0 & Deep(:,1)<=5,2))*6  %*6 for Bonferroni correction
Large_Deep_Firing_Rate_Fragmented_Hi_P=signrank(Deep(Deep(:,1)>5,2))*6
Large_Super_Firing_Rate_Fragmented_NP_P=signrank(Super(Super(:,1)<=0,2))*6
Large_Super_Firing_Rate_Fragmented_Lo_P=signrank(Super(Super(:,1)>0 & Super(:,1)<=5,2))*6
Large_Super_Firing_Rate_Fragmented_Hi_P=signrank(Super(Super(:,1)>5,2))*6

cd ..
cd ..
cd ..


end

