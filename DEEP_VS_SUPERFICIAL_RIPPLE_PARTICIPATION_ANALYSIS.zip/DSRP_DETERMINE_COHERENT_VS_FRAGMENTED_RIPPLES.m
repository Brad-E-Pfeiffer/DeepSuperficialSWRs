function DSRP_DETERMINE_COHERENT_VS_FRAGMENTED_RIPPLES(Initial_Variables)

% -------------------------------------------------------------------------
% -------------------------------------------------------------------------
%
% This function loads the decoded ripple data and identifies "coherent"
% ripples as those in which greater than 60% of the decoded windows are
% part of a coherent spatial representation (5 or more consecutive windows
% in which the peak posterior probability was over 0.05 and the spatial
% step size was less than 20 bins (40 cm)).  For spike timing and field
% position shuffles, these criteria are only observed in ~5% of shuffles.
% 
% It then identifies "fragmented" ripples as those in which less than 15%
% of the decoded windows meet the above criteria.  
%
% -------------------------------------------------------------------------
% -------------------------------------------------------------------------

Max_Step_Size=20;
Min_Probability=0.05;

if ~isfile('Coherent_Fragmented_Ripples.mat')
    load Decoded_Linear_Ripple_Events
    load Ripple_Events

    Coherent_Fragmented_Ripples=zeros(size(Ripple_Events,1),3);
    Coherent_Fragmented_Ripples(:,1)=1:size(Ripple_Events,1);

    for Current_Ripple=1:size(Ripple_Events,1)
        if eval(sprintf('isfield(Decoded_Linear_Ripple_Events,''Ripple_%d_Linear_Data'')',Current_Ripple))
            eval(sprintf('Decoded_Data=Decoded_Linear_Ripple_Events.Ripple_%d_Linear_Data;',Current_Ripple));
            [Max_Posterior_Probability,Peak_Location]=max(Decoded_Data);
            Step_Sizes=abs(diff(Peak_Location(:)));
            Max_Posterior_Probability=Max_Posterior_Probability(:);
            Step_Probabilities=mean([Max_Posterior_Probability(1:end-1),Max_Posterior_Probability(2:end)],2); %mean probability across both frames of each step
            Coherent_Parts=(Step_Sizes<=Max_Step_Size & Step_Probabilities>=Min_Probability);
            Consecutive_Coherent_Step_Starts_And_Ends=find(diff([0;Coherent_Parts;0]));
            Consecutive_Coherent_Steps_Starts=Consecutive_Coherent_Step_Starts_And_Ends(1:2:end-1);
            Consecutive_Coherent_Steps_Ends=Consecutive_Coherent_Step_Starts_And_Ends(2:2:end);
            Consecutive_Coherent_Step_Durations=Consecutive_Coherent_Steps_Ends-Consecutive_Coherent_Steps_Starts;
            Fraction_Of_Ripple_Encoding_Coherent_Spatial_Information=sum(Consecutive_Coherent_Step_Durations(Consecutive_Coherent_Step_Durations>=5))/length(Coherent_Parts);
            if Fraction_Of_Ripple_Encoding_Coherent_Spatial_Information>=0.6
                Coherent_Fragmented_Ripples(Current_Ripple,2)=1;
            elseif Fraction_Of_Ripple_Encoding_Coherent_Spatial_Information<0.20
                Coherent_Fragmented_Ripples(Current_Ripple,3)=1;
            end
        end
    end
    save('Coherent_Fragmented_Ripples','Coherent_Fragmented_Ripples');
end

end